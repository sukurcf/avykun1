package com.optum.qa.pages;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Optional;

import com.optum.qa.eesFunctionalApp.EesAppBase;
import com.optum.qa.eesFunctionalApp.EesWorkFlows;

public class AssignPlansPage extends EesWorkFlows {

	private WebDriver driver;

	// ******medical***********//

	@FindBy(xpath = "//*[@id='chevron-large-medical']")
	private WebElement Medical;

	@FindBy(xpath = ".//*[@id='empMedicalCoverageDate']")
	private WebElement MedicalDateInput;

	// medical CDB MEDICA

	@FindBy(xpath = "//a[@id='chevron-large-Med']")
	private WebElement MEDICAL_CDB_MEDICA;

	@FindBy(xpath = ".//*[@id='applyCoverageToAllButton-Med']")
	private WebElement ApplyCovrgetoAll_cdb_btn;

	@FindBy(xpath = ".//*[@id='planSelection-Med-0-00']")
	private WebElement MedicalPlanSelectioncheckox;

	// medical prime
	@FindBy(xpath = "//*[@id='mcheck1']")
	private WebElement Medical_prime_PlanSelectioncheckox;

	@FindBy(xpath = ".//*[@id='policyNumber-Med-0-00']")
	private WebElement PolicyNumberdrpdwn;

	@FindBy(xpath = ".//*[@id='coverage-Med-0-00']")
	private WebElement Coveragedrpdwn;

	@FindBy(xpath = ".//*[@id='preExisting-Med-0-00']")
	private WebElement PreExistingdrpdwn;

	// ******Medicare******//

	@FindBy(xpath = ".//*[@id='chevron-large-medicare']")
	private WebElement Medicare;

	@FindBy(xpath = ".//*[(@id='medicarePlanCovered')and(@value='Y')]")
	private WebElement MedicareYesRadio;

	@FindBy(xpath = ".//*[(@id='medicarePlanCovered')and(@value='N')]")
	private WebElement MedicareNoRadio;

	@FindBy(xpath = ".//*[(@id='medicarePlanCovered-00')and(@value='N')]")
	private WebElement Medicare_CDB_MEDICA_NoRadio;

	@FindBy(xpath = ".//*[@id='medicarePlanCoveredN']")
	private WebElement Medicare_prime_NoRadio;

	@FindBy(xpath = ".//*[(@id='medicarePlanCovered-99')and(@value='N')]")
	private WebElement Medicare_Dep_CDB_MEDICA_NoRadio;

	@FindBy(xpath = "//*[@id='empMedicareHicNum']")
	private WebElement HicNumbr_input;

	@FindBy(xpath = ".//*[@id='empMedicareEffDate']")
	private WebElement effectiveDate_input;

	// other insurance

	@FindBy(xpath = "//*[@id='chevron-large-other']")
	private WebElement otherInsurance;

	@FindBy(xpath = ".//*[(@id='otherInsurancePlanCovered')and(@value='Y')]")
	private WebElement otherInsuranceYesRadio;

	@FindBy(xpath = ".//*[(@id='otherInsurancePlanCovered') and (@value='N')]")
	private WebElement otherInsuranceNoRadio;


	@FindBy(xpath = "//*[(@id='medicarePlanCovered-00')and(@value='N')]")
	private WebElement Medicare_covered_no_radioBtn;

	@FindBy(xpath = "//*[(@id='medicarePlanCovered-00')and(@value='Y')]")
	private WebElement Medicare_covered_yes_radioBtn;


	//edit
	@FindBy(xpath = ".//*[@id='coverageDatePeriod']")
	private WebElement changeEffectiveDate_input;

	@FindBy(xpath = ".//*[@id='getCoveragePeriodDate']")
	private WebElement getCoveragePeriodBtn;

	@FindBy(xpath = ".//*[@id='edit-member-refresh']")
	private WebElement getCoveragePeriod_alert_ok;

	@FindBy(xpath = ".//*[@id='editInquireEmpPlans']")
	private WebElement EditPlansBtn;

	@FindBy(xpath = ".//*[@id='editInquireEmpDemo']")
	private WebElement EditDemographicsBtn;

	//edit dependent
	@FindBy(xpath = ".//*[@id='editInquireDepPlans-0']")
	private WebElement EditDependentPlansBtn;
	//expand all
	@FindBy(xpath = "//*[contains(text(),'Expand All')]")
	private WebElement expandAllLnk;

	//pcp

	@FindBy(xpath = ".//*[@id='provider-Med-0-00']/div[3]/div/div[1]/div/label/a")
	private WebElement searchLnk_CdbMedical;

	@FindBy(xpath = "//*[contains(text(),'Assign Physician')]")
	private WebElement AssignPhysicianBtn;


     //COSMOS
	@FindBy(xpath = ".//*[@id='empMedicalClassCode']")
	private WebElement empMedicalClasscode;
	
	@FindBy(xpath = ".//*[@id='pcpSearchAdd-00']")
	private WebElement assignProviderBtn;
	
	@FindBy(xpath = ".//*[@id='pcpFirstName']")
	private WebElement PCPFirstNameInput;
	
	@FindBy(xpath = ".//*[@id='pcpSearchButton']")
	private WebElement PCPSearchBtn;
	
	@FindBy(xpath = ".//*[@id='manageEmployees-Page']/div[5]/div[3]/div/button")
	private WebElement SelectAssignProviderBtn;
	
	@FindBy(xpath = ".//*[@id='applyCoverageToAllButton-Medical']")
	private WebElement ApplyCoveragetoAllBtn;
	
	@FindBy(xpath = ".//*[@id='pcpSearchAdd-99']")
	private WebElement DepAssignProviderBtn;

	//medco pharmacy

	@FindBy(xpath = ".//*[@id='planSelection-Med-1-002001']")
	private WebElement planSelectionMedcopharmacychkbx;


	@FindBy(xpath = ".//*[@id='policyNumber-Med-1-002001']")
	private WebElement policynumber_Medcopharmacy_drpdwn;

	@FindBy(xpath = ".//*[@id='coverage-Med-1-002001']")
	private WebElement coverage_Medcopharmacy_drpdwn;


	@FindBy(xpath = ".//*[@id='planSelection-Med-1-00']")
	private WebElement planSelectionMedcopharmacy_member_chkbx;


	@FindBy(xpath = ".//*[@id='policyNumber-Med-1-00']")
	private WebElement policynumber_Medcopharmacy_member_drpdwn;

	@FindBy(xpath = ".//*[@id='coverage-Med-1-00']")
	private WebElement coverage_Medcopharmacy_member_drpdwn;




	// buttons

	// page end
	@FindBy(xpath = "//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a[1]")
	private WebElement nextBtn_end;

	@FindBy(xpath = "//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a[2]")
	private WebElement previousBtn_end;

	@FindBy(xpath="//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a[1]")
	private WebElement SubmitEndBtn;


	@FindBy(xpath = ".//*[@id='middleInitial']")
	private WebElement middleIntial;

	//optum Rx
	@FindBy(xpath = ".//*[@id='planSelection-Med-2-002001']")
	private WebElement planSelection_Optumrx_chkbx;


	@FindBy(xpath = ".//*[@id='policyNumber-Med-2-002001']")
	private WebElement policynumber_Optumrx_drpdwn;

	@FindBy(xpath = ".//*[@id='coverage-Med-2-002001']")
	private WebElement coverage_Optumrx_drpdwn;
	//tick mark
	@FindBy(xpath = ".//img[@alt='Transaction Successful']")
	private WebElement tickMark;


	@FindBy(xpath=".//*[@id='productAccordionConfig.coverageSelected.errors']")
	private WebElement errorTxt;

	public AssignPlansPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void plans_cosmos() throws Exception {

		expandAllLnk.click();
		MedicareNoRadio.click();

		Thread.sleep(2000);
		nextBtn_end.click();
		fnWaitForPageLoad(driver);

	}
	public void plans_cosmos_medicare_YES() throws Exception {
		expandAllLnk.click();
		Medicare.click();

		MedicareYesRadio.click();
		HicNumbr_input.clear();
		HicNumbr_input.sendKeys("123456789000");
		effectiveDate_input.sendKeys(selectDate());
		Thread.sleep(2000);


	}
	
	public void plans_pcpcosmos() throws Exception {

		fnSelectByText("class code 1", empMedicalClasscode);
		

		String parentHandle = driver.getWindowHandle();
		assignProviderBtn.click();
		Thread.sleep(10000);
		fnWaitForPageLoad(driver);
		
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			PCPFirstNameInput.sendKeys("esse*");		
			PCPSearchBtn.click();
			Thread.sleep(2000);
			SelectAssignProviderBtn.click();
			Thread.sleep(4000);
					
		}
		driver.switchTo().window(parentHandle);
		fnWaitAndSwitchToFrame("ff-iframe", driver);
				   	
	
	}
	
	public void plans_Dependent_pcpcosmos() throws Exception {

		ApplyCoveragetoAllBtn.click();

		String parentHandle = driver.getWindowHandle();

		DepAssignProviderBtn.click();
		Thread.sleep(10000);
		fnWaitForPageLoad(driver);
		
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			PCPFirstNameInput.sendKeys("esse*");		
			PCPSearchBtn.click();
			Thread.sleep(2000);
			SelectAssignProviderBtn.click();
			Thread.sleep(4000);
					
		}
		driver.switchTo().window(parentHandle);
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		
		nextBtn_end.click();
	
	    	
	
	}
	
	
	

	public void plans_prime() throws Exception {

		// Medicare.click();
		Medicare_prime_NoRadio.click();
		Medical.click();
		Medical_prime_PlanSelectioncheckox.click();
		Thread.sleep(2000);
		nextBtn_end.click();
		fnWaitForPageLoad(driver);

	}

	public void plans_CDB_MEDICA() throws Exception {
		
		Medicare_CDB_MEDICA_NoRadio.click();
		MEDICAL_CDB_MEDICA.click();
		log.info("medical expand button is clicked");
		MedicalPlanSelectioncheckox.click();
		// app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("medical plan checkbox is selected");
		fnSelectByText("0712926", PolicyNumberdrpdwn);
		app_SpinnerInvisible(driver);
		Thread.sleep(6000);
		log.info("policy is selected");
		// fnSelectByText("0021 0021 GISMY 12/01/2008-", Coveragedrpdwn);
		fnSelectByValue("0021~0021~GISMY", Coveragedrpdwn);
		Thread.sleep(6000);
		log.info("coverage is selected");
		fnSelectByText("No", PreExistingdrpdwn);
		Thread.sleep(6000);
		log.info("PreExisting condition is selected");
		nextBtn_end.click();
		fnWaitForPageLoad(driver);

	}

	public void plans_CDB() throws Exception {
		
		Medicare_CDB_MEDICA_NoRadio.click();
		MEDICAL_CDB_MEDICA.click();
		log.info("medical expand button is clicked");
		MedicalPlanSelectioncheckox.click();
		// app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("medical plan checkbox is selected");
		fnSelectByText("1800727", PolicyNumberdrpdwn);

		app_SpinnerInvisible(driver);
		// Thread.sleep(6000);
		log.info("policy is selected");

		fnSelectByValue("0001~0001~POS", Coveragedrpdwn);
		Thread.sleep(6000);
		log.info("coverage is selected");
		nextBtn_end.click();
		fnWaitForPageLoad(driver);

	}

	public void plans_CDB_dependent() throws Exception {
		
		Medicare_Dep_CDB_MEDICA_NoRadio.click();
		Medicare_CDB_MEDICA_NoRadio.click();
		MEDICAL_CDB_MEDICA.click();
		log.info("medical expand button is clicked");
		MedicalPlanSelectioncheckox.click();
		// app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("medical plan checkbox is selected");
		fnSelectByText("1800727", PolicyNumberdrpdwn);
		app_SpinnerInvisible(driver);

		// Thread.sleep(6000);
		log.info("policy is selected");

		fnSelectByValue("0001~0001~POS", Coveragedrpdwn);
		ApplyCovrgetoAll_cdb_btn.click();

		app_SpinnerInvisible(driver);
		Thread.sleep(6000);
		log.info("coverage is selected");
		nextBtn_end.click();
		fnWaitForPageLoad(driver);

	}
	public void edit_pcp_member_cdb() throws Exception
	{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditPlansBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		changeEffectiveDate_input.clear();
		changeEffectiveDate_input.sendKeys("11112017");
		getCoveragePeriodBtn.click();
		app_SpinnerInvisible(driver);
		expandAllLnk.click();
		driver.switchTo().defaultContent();
		getCoveragePeriod_alert_ok.click();


	}
	public void plans_CDB_pcp() throws Exception {

		expandAllLnk.click();
		Medicare_CDB_MEDICA_NoRadio.click();
		//MEDICAL_CDB_MEDICA.click();
		//log.info("medical expand button is clicked");
		MedicalPlanSelectioncheckox.click();
		// app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("medical plan checkbox is selected");
		fnSelectByText("1800727", PolicyNumberdrpdwn);

		app_SpinnerInvisible(driver);
		// Thread.sleep(6000);
		log.info("policy is selected");

		fnSelectByValue("0001~0001~POS", Coveragedrpdwn);
		Thread.sleep(6000);
		log.info("coverage is selected");
		//driver.switchTo().defaultContent();
		Thread.sleep(2000);
		searchLnk_CdbMedical.click();
		driver.switchTo().defaultContent();
		AssignPhysicianBtn.click();
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		nextBtn_end.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);

	}
	public void plans_CDB_dependent_pcp() throws Exception {
		
		expandAllLnk.click();
		Medicare_Dep_CDB_MEDICA_NoRadio.click();
		Thread.sleep(1000);
		Medicare_CDB_MEDICA_NoRadio.click();
		log.info("medicare selected");

		//MEDICAL_CDB_MEDICA.click();
		//log.info("medical expand button is clicked");
		MedicalPlanSelectioncheckox.click();
		// app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("medical plan checkbox is selected");
		fnSelectByText("1800727", PolicyNumberdrpdwn);
		app_SpinnerInvisible(driver);

		// Thread.sleep(6000);
		log.info("policy is selected");

		fnSelectByValue("0001~0001~POS", Coveragedrpdwn);
		ApplyCovrgetoAll_cdb_btn.click();

		app_SpinnerInvisible(driver);
		Thread.sleep(6000);
		log.info("coverage is selected");
		/*nextBtn_end.click();
		fnWaitForPageLoad(driver);*/
		Thread.sleep(2000);
		searchLnk_CdbMedical.click();
		driver.switchTo().defaultContent();
		AssignPhysicianBtn.click();
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		nextBtn_end.click();
		fnWaitForPageLoad(driver);

	}
	//working
	public void edit_plans_dependent_cdb_otherInsurance_yes_no() throws Exception
	{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditDependentPlansBtn.click();

		app_SpinnerInvisible(driver);

		fnWaitForPageLoad(driver);
		changeEffectiveDate_input.clear();
		changeEffectiveDate_input.sendKeys("11112017");
		getCoveragePeriodBtn.click();
		app_SpinnerInvisible(driver);
		expandAllLnk.click();
		driver.findElement(By.xpath(".//*[(@id='otherInsuranceCovered-001001')and(@value='Y')]")).click();
		fnSelectByText("TYPE B", driver.findElement(By.xpath(".//*[@id='selectedCustodyType-001001']")));
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='otherEffectiveDate-001001']")).clear();
		driver.findElement(By.xpath(".//*[@id='otherEffectiveDate-001001']")).sendKeys(selectDate());
		//otherEffectiveDate-001001
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		try{
			String text=errorTxt.getText();
			if(text.equalsIgnoreCase("No Changes have been found"))
			{
				expandAllLnk.click();
				driver.findElement(By.xpath(".//*[(@id='otherInsuranceCovered-001001')and(@value='N')]")).click();
				SubmitEndBtn.click();
				app_SpinnerInvisible(driver);
				fnWaitForPageLoad(driver);
			}
		} catch(NoSuchElementException e){
			log.info(e.getMessage());
		}


		
		fnWaitForElement(driver, tickMark, shortTimeout);
		log.info("completed edit");


	}
	public void edit_plans_dependent_cdb() throws Exception
	{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditDependentPlansBtn.click();

		app_SpinnerInvisible(driver);

		fnWaitForPageLoad(driver);
		changeEffectiveDate_input.clear();
		changeEffectiveDate_input.sendKeys("11112017");
		getCoveragePeriodBtn.click();
		app_SpinnerInvisible(driver);

		driver.switchTo().defaultContent();
		try{

			getCoveragePeriod_alert_ok.click();
			app_SpinnerInvisible(driver);

		}catch(NoSuchElementException e)
		{
			e.getCause();
		}
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		expandAllLnk.click();


		planSelectionMedcopharmacychkbx.click();
		fnSelectByText("1800727", policynumber_Medcopharmacy_drpdwn);
		app_SpinnerInvisible(driver);

		fnSelectByValue("0160~0160~PS1", coverage_Medcopharmacy_drpdwn);
		planSelection_Optumrx_chkbx.click();
		fnSelectByText("1800727", policynumber_Optumrx_drpdwn);
		app_SpinnerInvisible(driver);
		fnSelectByValue("0060~0060~PS1MO", coverage_Optumrx_drpdwn);


		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);

	}
	public void edit_member_demo_cdb() throws Exception
	{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditDemographicsBtn.click();

		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);

		middleIntial.clear();
		middleIntial.sendKeys(generateRandomchar());
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver,tickMark, shortTimeout);
		//Thread.sleep(6000);



	}

	public void edit_member_plans_cdb() throws Exception
	{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditPlansBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		changeEffectiveDate_input.clear();
		changeEffectiveDate_input.sendKeys("11112017");
		getCoveragePeriodBtn.click();
		app_SpinnerInvisible(driver);

		driver.switchTo().defaultContent();
		getCoveragePeriod_alert_ok.click();
		app_SpinnerInvisible(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		expandAllLnk.click();
		fnWaitForElement(driver, MedicalPlanSelectioncheckox, shortTimeout);
		planSelectionMedcopharmacy_member_chkbx.click();
		fnWaitForPageLoad(driver);
		fnSelectByText("1800727", policynumber_Medcopharmacy_member_drpdwn);
		app_SpinnerInvisible(driver);

		fnSelectByValue("0000~0000~POS", coverage_Medcopharmacy_member_drpdwn);
		/*planSelection_Optumrx_chkbx.click();
		fnSelectByText("1800727", policynumber_Optumrx_drpdwn);
		app_SpinnerInvisible(driver);
		fnSelectByValue("0000~0000~POS", coverage_Optumrx_;*/
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver, tickMark, shortTimeout);


	}
	public void edit_medicare_coverage_NO_to_YES() throws Exception
	{
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditPlansBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		changeEffectiveDate_input.clear();
		changeEffectiveDate_input.sendKeys(selectDate());
		getCoveragePeriodBtn.click();
		log.info("clicked on get coverage period");
		app_SpinnerInvisible(driver);
		driver.switchTo().defaultContent();
		try{

			getCoveragePeriod_alert_ok.click();
			app_SpinnerInvisible(driver);

		}catch(NoSuchElementException e)
		{
			e.getCause();
		}


		fnWaitAndSwitchToFrame("ff-iframe", driver);
		expandAllLnk.click();
		log.info("clicked on expand all link");
		Medicare_covered_yes_radioBtn.click();
		log.info("medicare yes radio button");
		Thread.sleep(6000);
		driver.findElement(By.id("medicarePart-A-00")).click();
		Thread.sleep(6000);
		driver.findElement(By.id("medicarePartEffDate-A-00")).clear();
		Thread.sleep(6000);

		driver.findElement(By.id("medicarePartEffDate-A-00")).sendKeys(selectDate());
		Thread.sleep(6000);
		fnSelectByText("Disability", driver.findElement(By.id("selectedEligibilityForMedicare-00")));
		SubmitEndBtn.click();
		Thread.sleep(6000);
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver, tickMark, shortTimeout);
		//	TODO:need to validate 
		//	fnWaitForElement(driver,driver.findElement(By.xpath("")), shortTimeout);



	}
	public void edit_medicare_coverage_YES_to_NO() throws Exception
	{
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EditPlansBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		changeEffectiveDate_input.clear();
		changeEffectiveDate_input.sendKeys(selectDate());
		getCoveragePeriodBtn.click();
		app_SpinnerInvisible(driver);

		driver.switchTo().defaultContent();
		getCoveragePeriod_alert_ok.click();
		app_SpinnerInvisible(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		expandAllLnk.click();
		Medicare_covered_no_radioBtn.click();
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		//	TODO:need to validate 
		//	fnWaitForElement(driver,driver.findElement(By.xpath("")), shortTimeout);



	}


}
