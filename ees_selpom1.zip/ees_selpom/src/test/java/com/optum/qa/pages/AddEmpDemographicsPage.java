package com.optum.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.optum.qa.eesFunctionalApp.EesAppBase;

public class AddEmpDemographicsPage extends EesAppBase {

	private WebDriver driver;



	//effective date
	@FindBy(id="effectiveDate")
	private WebElement OroginalEffectveDate ;

	@FindBy(xpath="//*[@id='continue']")
	private WebElement ContinueBtn ;

	@FindBy(xpath=".//*[@class='ui-datepicker-trigger']")
	private WebElement calenderimg;

	@FindBy(xpath="//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[5]/a")
	private WebElement dateimg;


	//demographics employee
	@FindBy(xpath="//*[@id='firstName']")
	private WebElement firstNameInput;

	@FindBy(xpath=".//*[@id='employeeInfo.demographicInfo.lastName']")
	private WebElement lastNameInput;

	@FindBy(xpath=".//*[@id='lastName']")
	private WebElement lastNameCDBInput;

	@FindBy(xpath=".//*[@id='employeeId']")
	private WebElement EmpidInput;

	@FindBy(xpath=".//*[@id='enrollmentReason']")
	private WebElement LateEnrolleeDrpdwn;

	@FindBy(xpath=".//*[@id='relationShip']")
	private WebElement RelationshpDrpdwn;


	@FindBy(xpath="//*[@id='ssn']")
	private WebElement SsnInput;

	@FindBy(xpath="//*[@id='gender']")
	private WebElement GenderDrpdwn;


	@FindBy(xpath="//*[@id='dateOfBirth']")
	private WebElement DobInput;



	@FindBy(xpath="//*[@id='dateOfHire']")
	private WebElement DateofHireInput;

	@FindBy(xpath="//*[@id='maritalStatus']")
	private WebElement maritalStatusdrpdwn;

	@FindBy(xpath=".//*[@id='language']")
	private WebElement language_drpdwn;

	@FindBy(xpath="//*[@id='waitPeriod-e']")
	private WebElement waitperiod_drpdwn;
	
	@FindBy(xpath=".//*[@id='department']")
	private WebElement pcpdepartment_drpdwn;
	
	@FindBy(xpath = ".//img[@alt='Transaction Successful']")
	private WebElement tickMark;


	//CDB MEDICA
	/*
		@FindBy(xpath=".//*[@id='addressZipCode']")
		private WebElement CDBMEDICAAddressZipcodeInput;

		@FindBy(xpath="//select[@id='addressState']")
		private WebElement AddressStatedrpdwn;*/


	//address and phone
	@FindBy(xpath=".//*[@id='addressCountry']")
	private WebElement CountryDrpdwn;
	
	@FindBy(xpath="//*[@id='addressLineOne']")
	private WebElement Adrssline1Input;

	@FindBy(xpath="//*[@id='addressCity']")
	private WebElement CityInput;

	@FindBy(xpath=".//*[@id='states']")
	private WebElement Statedrpdwn;

	@FindBy(xpath=".//*[@id='addressState']")
	private WebElement StateCDB_CDBMEDICAdrpdwn;

	@FindBy(xpath="//*[@id='empzip']")
	private WebElement ZipcodeInput;

	@FindBy(xpath="//*[@id='addressZipCode']")
	private WebElement ZipcodeCDB_CDBMEDICA_Input;

	@FindBy(xpath="//*[@id='docmailreference']")
	private WebElement DocMailingPreferenceDrpDwn;
	
	//dependent adress
	@FindBy(xpath=".//*[@id='depAddressCity0']")
	private WebElement CityDepInput;
	
	@FindBy(xpath=".//*[@id='depAddressState0']")
	private WebElement StateDepDrpdwn;
	
	@FindBy(xpath=".//*[@id='depAddressZipCode0']")
	private WebElement ZipcodeDepInput;
	
	
	//canada cdb

	@FindBy(xpath=".//*[@id='addressMunicipality']")
	private WebElement MunicipalityInput;
	
	@FindBy(xpath=".//*[@id='addressProvince']")
	private WebElement Provincedrpdwn;
	
	@FindBy(xpath=".//*[@id='addressPostalCode']")
	private WebElement postalcodeInput;
	//page end
	@FindBy(xpath="//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a")
	private WebElement nextBtn_end;

	@FindBy(xpath="//*[@id='firstAddDependent']")
	private WebElement AddDependentsBtn;

	@FindBy(xpath=".//*[@class='app-validation-error-wrap']")
	private WebElement ErrorMsg;

	@FindBy(xpath="//*[@id='add-new-employee-widget']")
	private WebElement addNewemp_demographics;
	//dependent adress
	@FindBy(xpath=".//*[@id='editInquireDepDemo-0']")
	private WebElement edit_demo_dpndntBtn;
	
	@FindBy(xpath=".//*[@id='depAddressLineOne0']")
	private WebElement adrssline1dep;
	//dependent
	@FindBy(xpath=".//*[@id='depFirstName0']")
	private WebElement firstNameDep_Input;

	@FindBy(xpath=".//*[@id='depRelationShip0']")
	private WebElement RelatinshpDep_drpdwn;


	@FindBy(xpath="//*[@id='depGender0']")
	private WebElement GenderDep_drpdwn;

	@FindBy(xpath=".//*[@id='depDateofBirth0']")
	private WebElement Dob_dep_Input;


	@FindBy(xpath=".//*[@id='inquireAddAnotherDep']")
	private WebElement AddanotherDependent;

	@FindBy(xpath=".//*[@id='dependentBeans0.dependentInfo.demographicInfo.firstName']")
	private WebElement dependentfirstNameInput;

	@FindBy(xpath=".//*[@id='depRelationShip']")
	private WebElement relationship_drpdwn;

	@FindBy(xpath=".//*[@id='depGender0']")
	private WebElement gender_drpdwn;

	@FindBy(xpath=".//*[@id='depDateofBirth0']")
	private WebElement dependentDobInput;

	@FindBy(xpath=".//*[@id='department']")
	private WebElement department_drpdwn;

	@FindBy(xpath="//*[@id='firstAddDependent']")
	private WebElement AddDependents;

	@FindBy(xpath=".//*[@id='addNewDependent']")
	private WebElement AddNewDependent;

	@FindBy(xpath=".//*[@id='addDependent']")
	private WebElement AddmoreDependentsBtn;

	@FindBy(xpath=".//*[@id='dependentBeans1.dependentInfo.demographicInfo.firstName']")
	private WebElement seconddependentfirstNameInput;

	@FindBy(xpath=".//*[@name='dependentBeans[1].dependentInfo.relationship']")
	private WebElement seconddeprelationship_drpdwn;


	@FindBy(xpath=".//*[@id='depGender1']")
	private WebElement seconddepgender_drpdwn;

	@FindBy(xpath=".//*[@id='depDateofBirth1']")
	private WebElement seconddependentDobInput;
	
	@FindBy(xpath=".//*[@id='depAddressLineOne0']")
	private WebElement addrssLin1depInput;

	@FindBy(xpath=".//*[@id='depAddressCountry-0']")
	private WebElement CountryDepDrpdwn;

	@FindBy(xpath=".//*[@id='depAddressProvince0']")
	private WebElement ProvinceDepDrpdwn;

	@FindBy(xpath=".//*[@id='depAddressMunicipality0']")
	private WebElement MunicipalityDepInput;

	@FindBy(xpath=".//*[@id='depAddressPostalCode0']")
	private WebElement PostalcodeDepInput;

	@FindBy(xpath=".//*[@id='depDifferentAddressCheck-0']")
	private WebElement addrsAndPhDiffnt_chkbx;

	
	@FindBy(xpath = ".//*[@id='editInquireEmpDemo']")
	private WebElement Edit_Emp_DemographicsBtn;
	
	@FindBy(xpath="//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a[1]")
	private WebElement SubmitEndBtn;

	public AddEmpDemographicsPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void demographics_details_prime() throws Exception
	{  

		addNewemp_demographics.click();
		fnWaitForAlertPresent(driver);
		fnAlertAccept(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		OroginalEffectveDate.sendKeys("12122016");

		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);

		//demographics
		firstNameInput.sendKeys("harry");
		lastNameInput.sendKeys("HE");
		SsnInput.sendKeys(generateSSN());
		fnSelectByText("MALE", GenderDrpdwn);
		Thread.sleep(2000);
		DobInput.clear();
		DobInput.sendKeys("01011990");
		DateofHireInput.clear();
		DateofHireInput.sendKeys("11112016");

		//address
		Adrssline1Input.sendKeys("near temple");

		CityInput.sendKeys("amaravathi");
		Thread.sleep(6000);
		fnSelectByText("Wisconsin", Statedrpdwn);
		fnWaitForPageLoad(driver);
		//Thread.sleep(4000);
		ZipcodeInput.clear();
		ZipcodeInput.sendKeys("54001");
		Thread.sleep(6000);
		/*nextBtn_end.click();
		log.info("clicked on next button");*/



	}


	public void demographics_details_cosmos() throws Exception
	{  
		addNewemp_demographics.click();
		fnWaitForAlertPresent(driver);
		fnAlertAccept(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);

		log.info("Current date "+selectDate());
		OroginalEffectveDate.sendKeys(selectDate());

		Thread.sleep(6000);
		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);


		//details
		firstNameInput.sendKeys("JOHN");
		lastNameInput.sendKeys("TURNER");
		EmpidInput.sendKeys(generateEmpid());
		fnSelectByText("MALE", GenderDrpdwn);
		Thread.sleep(2000);
		DobInput.clear();
		DobInput.sendKeys("01011990");
		fnSelectByText("Married", maritalStatusdrpdwn);
		Thread.sleep(2000);
		DateofHireInput.clear();
		DateofHireInput.sendKeys("11112016");
		Thread.sleep(2000);

		fnSelectByText("ACA", department_drpdwn);
		Thread.sleep(4000);

		fnSelectByText("English", language_drpdwn);
		Thread.sleep(4000);
		fnSelectByText("No", waitperiod_drpdwn);

		Thread.sleep(4000);

		//address
		Adrssline1Input.sendKeys("near temple");
		Thread.sleep(1000);
		CityInput.sendKeys("amaravathi");
		Thread.sleep(1000);
		fnSelectByText("Wisconsin", Statedrpdwn);
		Thread.sleep(4000);
		ZipcodeInput.clear();
		ZipcodeInput.sendKeys("54001");
		Thread.sleep(6000);
		//nextBtn_end.click();
		//log.info("clicked on next button");
		//fnWaitForPageLoad(driver);



	}

	public void dependent_demographics_details_cosmos() throws Exception

	{
		//demographics_details_cosmos();
		AddDependents.click();
		dependentfirstNameInput.sendKeys("TESTDEP");
		fnSelectByText("Spouse", relationship_drpdwn);
		fnSelectByText("FEMALE", gender_drpdwn);
		dependentDobInput.clear();
		dependentDobInput.sendKeys("01011991");
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);


	}
	//suresh
	public void demographics_details_cosmos_with_Dependent() throws Exception
	{
		demographics_details_cosmos();
		AddDependents.click();
		dependentfirstNameInput.sendKeys("TESTDEP");
		fnSelectByText("Spouse", relationship_drpdwn);
		fnSelectByText("FEMALE", gender_drpdwn);
		dependentDobInput.clear();
		dependentDobInput.sendKeys("01011991");

	}
	public void demographics_details_cosmos_with_add_another_Dependent() throws Exception
	{
		demographics_details_cosmos_with_Dependent();
		AddmoreDependentsBtn.click();
		seconddependentfirstNameInput.sendKeys("SECOND DEPENDENT");
		fnSelectByText("Child", seconddeprelationship_drpdwn);
		fnSelectByText("FEMALE", seconddepgender_drpdwn);
		seconddependentDobInput.clear();
		seconddependentDobInput.sendKeys("01012001");
		Thread.sleep(6000);


	}


	public void AddEmoployee_NextButton_cosmos() throws Exception

	{  
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);

	}

	public void Addmoredependents_demographics_details_cosmos() throws Exception

	{
		AddDependents.click();
		dependentfirstNameInput.sendKeys("TESTDEP");
		fnSelectByText("Spouse", relationship_drpdwn);
		fnSelectByText("FEMALE", gender_drpdwn);
		dependentDobInput.clear();
		dependentDobInput.sendKeys("01011991");
		Thread.sleep(6000);
		AddmoreDependentsBtn.click();
		seconddependentfirstNameInput.sendKeys("SECOND DEPENDENT");
		fnSelectByText("Child", seconddeprelationship_drpdwn);
		fnSelectByText("FEMALE", seconddepgender_drpdwn);
		seconddependentDobInput.clear();
		seconddependentDobInput.sendKeys("01012001");
		Thread.sleep(6000);
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);


	}

	public void Add_Newdependent_demographics_details_cosmos() throws Exception

	{

		AddNewDependent.click();
		OroginalEffectveDate.sendKeys(selectDate());
		Thread.sleep(6000);
		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);
		dependentfirstNameInput.sendKeys("TESTDEP");
		fnSelectByText("Spouse", relationship_drpdwn);
		fnSelectByText("FEMALE", gender_drpdwn);
		dependentDobInput.clear();
		dependentDobInput.sendKeys("01011991");
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);


	}
	public void Addanotherdependent_demographics_details_cosmos() throws Exception

	{

		AddanotherDependent.click();
		fnWaitForAlertPresent(driver);
		fnAlertAccept(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		OroginalEffectveDate.sendKeys("12122016");
		Thread.sleep(6000);
		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);
		dependentfirstNameInput.sendKeys("NANCY");
		fnSelectByText("Spouse", relationship_drpdwn);
		fnSelectByText("MALE", gender_drpdwn);
		dependentDobInput.clear();
		dependentDobInput.sendKeys("01011995");
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);


	}
	
	public void demographics_details_pcpcosmos() throws Exception
	{  
		addNewemp_demographics.click();
		fnWaitForAlertPresent(driver);
		fnAlertAccept(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);

		log.info("Current date "+selectDate());
		OroginalEffectveDate.sendKeys(selectDate());
		
		Thread.sleep(6000);
		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);


		//details
		firstNameInput.sendKeys("JOHN");
		lastNameInput.sendKeys("TURNER");
		EmpidInput.sendKeys(generateEmpid());
		fnSelectByText("MALE", GenderDrpdwn);
		
		DobInput.clear();
		DobInput.sendKeys("01011990");
		fnSelectByText("Married", maritalStatusdrpdwn);
		
		DateofHireInput.clear();
		DateofHireInput.sendKeys("11112016");
		Thread.sleep(2000);
		
			
		fnSelectByText("TEST DEPT 1", pcpdepartment_drpdwn);
		Thread.sleep(4000);
		
		
		fnSelectByText("English", language_drpdwn);
		
		fnSelectByText("No", waitperiod_drpdwn);

		//address
		Adrssline1Input.sendKeys("near temple");
		
		CityInput.sendKeys("amaravathi");
		
		fnSelectByText("Wisconsin", Statedrpdwn);
		
		ZipcodeInput.clear();
		ZipcodeInput.sendKeys("54001");
		Thread.sleep(2000);
	}
	
	public void demographics_details_CDB() throws Exception
	{  
		addNewemp_demographics.click();
		fnWaitForAlertPresent(driver);
		fnAlertAccept(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);

		OroginalEffectveDate.sendKeys("12122016");

		Thread.sleep(6000);
		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);

		//details
		firstNameInput.sendKeys("harry");
		lastNameCDBInput.sendKeys("HE");
		EmpidInput.sendKeys(generateEmpid());
		fnSelectByText("MALE", GenderDrpdwn);
		Thread.sleep(2000);


		fnSelectByText("Employee", RelationshpDrpdwn);
		DobInput.clear();
		DobInput.sendKeys("01011990");

		Thread.sleep(1000);
		fnSelectByText("Timely New Hire", LateEnrolleeDrpdwn);
		DateofHireInput.clear();
		DateofHireInput.sendKeys("11112016");
		Thread.sleep(1000);

		//address
		Adrssline1Input.sendKeys("near temple");
		Thread.sleep(1000);
		CityInput.sendKeys("amaravathi");
		Thread.sleep(1000);
		fnSelectByText("Wisconsin", StateCDB_CDBMEDICAdrpdwn);
		Thread.sleep(2000);
		ZipcodeCDB_CDBMEDICA_Input.clear();

		ZipcodeCDB_CDBMEDICA_Input.sendKeys("54001");
		fnSelectByText("No Preference Selected", DocMailingPreferenceDrpDwn);
		Thread.sleep(6000);






	}
	public void click_nextButton() throws Exception
	{
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);
		Thread.sleep(2000);
		if (fnIsDisplayed(ErrorMsg)) {
			String err_text=ErrorMsg.getText();
			log.info("***error text present is*** : " +err_text);
			//Thread.sleep(20000);
			Assert.fail("failing test case due to error text present");

		}

	}



	public void demographics_details_CDB_MEDICA(String SSN) throws Exception
	{
		addNewemp_demographics.click();
		fnWaitForAlertPresent(driver);
		fnAlertAccept(driver);
		fnWaitAndSwitchToFrame("ff-iframe", driver);

		OroginalEffectveDate.sendKeys(selectDate());
		/*calenderimg.click();
		dateimg.click();*/
		Thread.sleep(6000);
		ContinueBtn.click();
		log.info("clicked on continue button");
		app_SpinnerInvisible(driver);


		//details
		firstNameInput.sendKeys("TEST");
		lastNameCDBInput.sendKeys("SELPOMFRMWRK");
		SsnInput.sendKeys(generateSSN());
		fnSelectByText("EMPLOYEE", RelationshpDrpdwn);
		Thread.sleep(4000);
		fnSelectByText("FEMALE", GenderDrpdwn);
		Thread.sleep(4000);
		DobInput.clear();
		DobInput.sendKeys("01011990");
		fnSelectByText("TIMELY ENROLLMENT", LateEnrolleeDrpdwn);
		Thread.sleep(4000);
		DateofHireInput.clear();
		DateofHireInput.sendKeys("11112016");
		Thread.sleep(4000);
		fnSelectByText("English", language_drpdwn);
		Thread.sleep(4000);
		fnSelectByText("No", waitperiod_drpdwn);
		Thread.sleep(4000);

		//address
		Adrssline1Input.sendKeys("ADDRESS");
		Thread.sleep(1000);
		CityInput.sendKeys("CITY");
		Thread.sleep(1000);
		fnSelectByText("Wisconsin", StateCDB_CDBMEDICAdrpdwn);
		Thread.sleep(4000);
		ZipcodeCDB_CDBMEDICA_Input.clear();
		ZipcodeCDB_CDBMEDICA_Input.sendKeys("54001");
		Thread.sleep(6000);
		nextBtn_end.click();
		log.info("clicked on next button");
		fnWaitForPageLoad(driver);
		fnWaitForPageLoad(driver);
		if (fnIsDisplayed(ErrorMsg)) {
			String err_text=ErrorMsg.getText();
			log.info("***error text present is*** : " +err_text);
			//Thread.sleep(20000);
			Assert.fail("failing test case due to error text present");
		}

	}

	public void demographics_details_CDB_with_Dependent() throws Exception
	{
		demographics_details_CDB();
		AddDependentsBtn.click();
		app_SpinnerInvisible(driver);
		firstNameDep_Input.sendKeys("potter");
		fnSelectByText("Spouse", RelatinshpDep_drpdwn);
		fnSelectByText("FEMALE", GenderDep_drpdwn);
		Dob_dep_Input.clear();
		Dob_dep_Input.sendKeys("01011992");
		log.info("entered first dependent details");


	}
	public void add_Different_address_otherThanEmployee() throws Exception
	{
		addrsAndPhDiffnt_chkbx.click();
		log.info("clicked on address different check box");
		fnSelectByText("Canada", CountryDepDrpdwn);
		MunicipalityDepInput.sendKeys("MANITOBA");
		fnSelectByText("Quebec", ProvinceDepDrpdwn);
		PostalcodeDepInput.sendKeys("123456");
		click_nextButton();
		app_SpinnerInvisible(driver);



	}
	public void edit_member_demo_address_US_to_CANADA() throws Exception
	{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		Edit_Emp_DemographicsBtn.click();

		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);

		fnSelectByText("Canada", CountryDrpdwn);
		Adrssline1Input.sendKeys(generateAddressFields());
		MunicipalityInput.sendKeys(generateAddressFields());
		fnSelectByText("Quebec", Provincedrpdwn);
		postalcodeInput.clear();
		postalcodeInput.sendKeys("A2C 1B2");
		Thread.sleep(6000);
		
		
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver,tickMark, shortTimeout);
		Thread.sleep(6000);
		
		//setting back to rerun automation
		Edit_Emp_DemographicsBtn.click();

		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);

		fnSelectByText("United States", CountryDrpdwn);

		//address
		Adrssline1Input.sendKeys("near temple");
		Thread.sleep(1000);
		CityInput.sendKeys("amaravathi");
		Thread.sleep(1000);
		fnSelectByText("Wisconsin", StateCDB_CDBMEDICAdrpdwn);
		Thread.sleep(2000);
		ZipcodeCDB_CDBMEDICA_Input.clear();

		ZipcodeCDB_CDBMEDICA_Input.sendKeys("54001");
		fnSelectByText("No Preference Selected", DocMailingPreferenceDrpDwn);
		Thread.sleep(1000);
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver,tickMark, shortTimeout);
		Thread.sleep(6000);

	}
	//working
	public void edit_dep_demo_adress() throws Exception
	{
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		edit_demo_dpndntBtn.click();

		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);

		fnSelectByText("Canada", CountryDepDrpdwn);
		addrssLin1depInput.clear();
		addrssLin1depInput.sendKeys(generateAddressFields());
		
		MunicipalityDepInput.sendKeys(generateAddressFields());
		fnSelectByText("Quebec", ProvinceDepDrpdwn);
		PostalcodeDepInput.clear();
		PostalcodeDepInput.sendKeys("A2C 1B2");
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver,tickMark, shortTimeout);
		Thread.sleep(6000);
		
		//setting back to pass autoamtion
		edit_demo_dpndntBtn.click();

		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);

		fnSelectByText("United States", CountryDepDrpdwn);
		addrssLin1depInput.clear();
		addrssLin1depInput.sendKeys(generateAddressFields());
		CityDepInput.clear();
		CityDepInput.sendKeys(generateAddressFields());
		fnSelectByText("Wyoming", StateDepDrpdwn);
		ZipcodeDepInput.clear();
		ZipcodeDepInput.sendKeys("54001");
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		fnWaitForElement(driver,tickMark, shortTimeout);


	}

}
