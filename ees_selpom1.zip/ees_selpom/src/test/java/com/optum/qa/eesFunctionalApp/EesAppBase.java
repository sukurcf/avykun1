package com.optum.qa.eesFunctionalApp;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.commons.collections.ListUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.Alert;
/*import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;*/
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.optum.qa.eesBase.EesBaseTest;
import com.rallydev.rest.RallyRestApi;
import com.rallydev.rest.request.CreateRequest;
import com.rallydev.rest.request.GetRequest;
import com.rallydev.rest.request.QueryRequest;
import com.rallydev.rest.response.CreateResponse;
import com.rallydev.rest.response.GetResponse;
import com.rallydev.rest.response.QueryResponse;
import com.rallydev.rest.util.Fetch;
import com.rallydev.rest.util.QueryFilter;
import com.rallydev.rest.util.Ref;
import com.saucelabs.common.SauceOnDemandAuthentication;
import com.saucelabs.common.SauceOnDemandSessionIdProvider;
import com.saucelabs.testng.SauceOnDemandAuthenticationProvider;

public class EesAppBase extends EesBaseTest
implements SauceOnDemandSessionIdProvider, SauceOnDemandAuthenticationProvider {

	// Removed class-level driver object, will instantiate a new driver for each
	// test function.
	// Each test method should now start with:
	// RemoteWebDriver driver = getWebDriver();
	// protected RemoteWebDriver driver;
	protected ThreadLocal<RemoteWebDriver> threadDriver = new ThreadLocal<RemoteWebDriver>();
	protected int LogoutNotifWait = 180000; // in milliseconds
	protected int LogoutWait = 240000; // in milliseconds
	protected static String fileSeperator = System.getProperty("file.separator");
	public String testCaseID, AlertText = null, Attributetext = null, GetText = null, GetSelectedDropDownValue = null,
			CurrentDate;
	public String windowHandle = null, windowTitle = null, actualValue = null;

	List<String> expectedOptions = new ArrayList<String>();
	List<String> actualOptions = new ArrayList<String>();

	/**
	 * ThreadLocal variable which contains the Sauce Job Id. used to report
	 * pass/fail to sauceLabs dashboard
	 */
	private static ThreadLocal<String> sessionId = new ThreadLocal<String>();

	/**
	 * Constructs a {@link com.saucelabs.common.SauceOnDemandAuthentication}
	 * instance using the supplied user name/access key. To use the
	 * authentication supplied by environment variables or from an external
	 * file, use the no-arg
	 * {@link com.saucelabs.common.SauceOnDemandAuthentication} constructor.
	 */
	public SauceOnDemandAuthentication authentication = new SauceOnDemandAuthentication();

	/**
	 * @return the {@link WebDriver} for the current thread
	 */
	public RemoteWebDriver getWebDriver() {
		log.info("WebDriver " + threadDriver.get());

		return threadDriver.get();
	}





	/**
	 * Helper method to select drop down by passing by Element and Value
	 * 
	 * @param root:
	 *            Root element to search underneath
	 * @param by:
	 *            Value of the drop down to Select
	 * 
	 */
	public void fnSelectByText(String Value, WebElement webElement) {
		try {

			if (webElement != null) {
				Select select = new Select(webElement);
				select.selectByVisibleText(Value);
				log.info("Selected value is : " + Value);
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
	}

	/**
	 * Helper method to select drop down by passing by Element and Partial Value
	 * 
	 * @param root:
	 *            Root element to search underneath
	 * @param by:
	 *            Value of the drop down to Select
	 * 
	 */
	public void fnSelectByPartialVisibleText(String Value, WebElement webElement) {
		try {
			Select select = new Select(webElement);
			List<WebElement> elements = select.getOptions();
			for (WebElement option : elements) {
				String fullText = option.getText();
				if (fullText.contains(Value)) {
					select.selectByVisibleText(fullText);
					log.info("Selected value is : " + fullText);
				}
			}
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
	}

	/**
	 * Helper method to select drop down by passing by Element and Value
	 * 
	 * @param root:
	 *            Root element to search underneath
	 * @param by:
	 *            Value of the drop down to Select
	 * 
	 */
	public void fnSelectByIndex(int Index, WebElement element) {
		try {

			if (element != null) {
				Select select = new Select(element);
				select.selectByIndex(Index);
				log.info("Selected Index value is : " + Index);
			}
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
	}

	/**
	 * Helper method to supplement Selenium IDE because WebDriver does not have
	 * 
	 * @param by
	 * @return
	 */
	protected boolean fnIsElementPresent(WebElement element) {
		boolean status = false;
		try {
			// fnIsDisplayed(by);
			// fnWaitForElement(by, longTimeout);
			Thread.sleep(2000);
			status=element.isDisplayed();

		} catch (NoSuchElementException | InterruptedException e) {
			status = false;
		}
		return status;
	}

	/**
	 * Helper method to supplement Selenium IDE because WebDriver does not have
	 * it
	 * 
	 * @param root:
	 *            Root element to search underneath
	 * @param by:
	 *            selector definition of element to check existence
	 * @return
	 */
	protected boolean fnRootElementPresent(WebElement root, By by) {
		try {

			root.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}



	/**
	 * This method is to get main Window Handle
	 * 
	 * @param driver
	 * @return
	 */
	public String fnGetMainWindowHandle(WebDriver driver) {
		return driver.getWindowHandle();
	}

	/**
	 * This EMthod is to get Current Window title
	 * 
	 * @return
	 */
	public String fnGetCurrentWindowTitle(WebDriver driver) {
		String windowTitle = driver.getTitle();
		return windowTitle;
	}

	/**
	 * This Method is to Wait till the Element is Visible Need to Pass Element
	 * Locator
	 * 
	 * @param by
	 * @param seconds
	 * @return
	 */
	protected boolean fnWaitForElement(WebDriver driver, WebElement element,int seconds) {
		boolean displayedElement = false;

		// Intialize wait object on current driver, with timeout set to
		// 'seconds' parameter
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		try {
			// Wait condition is to be that element exists and is displayed
			wait.until(ExpectedConditions.visibilityOf(element));
			// If exception is not thrown, element was found, set
			// displayedElement to true
			displayedElement = true;
		} catch (TimeoutException e) {
			log.info("Failed to find a visible element with [" + element + "]");
			displayedElement = false;
			Assert.fail("Unable to find a visible element with [" +element + "]");
		} catch (Exception e) {
			log.info("Generic exception e [" + e.getMessage() + "]");
			displayedElement = false;
		}
		return displayedElement;
	}

	/**
	 * Default slider selector
	 * 
	 * @author
	 * 
	 * 		The slider calls clickSlider with default values If you need more
	 *         configuration control, please use the other clickSlider method
	 * 
	 *         Scale 10, Beginning position 5, and Slider bar width 100px
	 * 
	 * @param slider
	 *            - Slider's Web Element
	 * @param value
	 *            - Value to be selected
	 */
	protected void clickSlider(WebElement slider, int value,WebDriver driver) {
		clickSlider(slider, value, 10, 5, 100,driver);
	}

	/**
	 * Helper function to click on a selected value on a Slider.
	 * 
	 * The width of the slider is identified by Selenium getWidth() method. This
	 * will return the slider's width accordingly. We are using the
	 * dragAndDropBy method to move the slider value per OffsetX.
	 * 
	 * Computes OffsetX using the width of the slider and breaks into "scale"
	 * number of slices multiplied by the selection needed on the slider.
	 * 
	 * Note: If the the slider default starts at the beginning, we can slide
	 * only to right. If the slider default does not start at the beginning,
	 * then we substract the beginningPosition to move to the correct relative
	 * selected value.
	 * 
	 * Please refer to Selenium documentation for dragAndDropBy method
	 * https://selenium.googlecode.com/git/docs/api/java/org/openqa/selenium/
	 * interactions/Actions.html#dragAndDropBy-org.openqa.selenium.WebElement-
	 * int-int-
	 * 
	 * This works on all browsers
	 * 
	 * @author
	 * @param slider
	 *            - Slider's Web Element.
	 * @param value
	 *            - Value to be selected regardless of starting slider position.
	 * @param scale
	 *            - Scale of slider e.g. 10 for a slider of 10 values
	 * @param beginningPosition
	 *            - starting position of the Slider
	 * @param sliderBarWidthInPixels
	 *            - slider bar width in pixels (should match to CSS slider bar
	 *            width settings)
	 * 
	 */
	protected void clickSlider(WebElement slider, int value, int scale, int beginningPosition,
			int sliderBarWidthInPixels,WebDriver driver) {
		Actions move = new Actions(driver);
		int Width = slider.getSize().getWidth();
		// Remove the slider bar width from slider width
		Width = Width - sliderBarWidthInPixels;
		// Compute OffsetX based on width, beginningPosition, scale of the
		// slider and value needed
		int offsetX = Width * (value - beginningPosition) / scale;
		int offsetY = 1;
		Action actionDrag = move.dragAndDropBy(slider, offsetX, offsetY).build();
		actionDrag.perform();
	}

	/**
	 * Helper function to shuffle the capitalization of an input string.
	 * 
	 * @param input
	 * @return String with input, but every other character is upper case
	 */
	protected String shuffleCase(String input) {
		String newString = "";

		for (int counter = 0; counter < input.length(); counter++) {
			if (counter % 2 == 0) {
				newString += input.substring(counter, counter + 1).toUpperCase();
			} else {
				newString += input.substring(counter, counter + 1).toLowerCase();
			}

		}

		return newString;
	}

	/**
	 * This Method is to Get current Date, Hour, Minute, Second, Millisecond;
	 * 
	 * @return
	 */
	public String getTimeStamp() {
		String today;
		DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Calendar calendar = Calendar.getInstance();
		today = dateFormat.format(calendar.getTime());
		return today;
	}

	/**
	 * This Method is to Update Pass or Fail after Execution of test case. If
	 * test case is failed then it will take screenshot
	 * 
	 * @param result
	 */
	@AfterMethod(alwaysRun = true)
	public void afterMethod(ITestResult result) {

		// Here will compare if test is failing then only it will enter into if
		// condition

		try {

			String Rallytestcase = null;
			testCaseID = result.getName();
			if (!(ITestResult.FAILURE == result.getStatus())) {

				// RallyTestcaseUpdation(testCaseID, "Pass");
				log.info("Updated :" + testCaseID + ": Test case Result -- PASS");
			}

			else if (ITestResult.FAILURE == result.getStatus()) {

				String testClassName = getTestClassName(result.getInstanceName()).trim();


				Rallytestcase = result.getName().substring(0, 5);
				String[] testMethodName = result.getName().split("_");
				String screenShotName = testMethodName[0] + "_" + getTimeStamp() + ".png";

				if (threadDriver != null) {
					String fileSeperator = null;
					String imagePath = ".." + fileSeperator + "Screenshots" + fileSeperator + "Results" + fileSeperator
							+ testClassName + fileSeperator + takeScreenShot(screenShotName, testClassName);

					log.info("Screenshot Captured");
					// RallyTestcaseUpdation(testCaseID, "Fail");
					log.info("Updated :" + testCaseID + ": Test case Result Test case Result -- FAIL");
				}
			}
			if (threadDriver.get() != null) {
				threadDriver.get().close();
				threadDriver.get().quit();
				
					threadDriver.get().get("someURL");
				
			}

		} catch (Exception e) {
			// Need to trap exceptions so failure in afterMethod doesn't block
			// subsequent tests.
			// May have side effects, though

		}
	}

	/**
	 * This Method is to capture screenshot. It will Pick Parameter form
	 * AfterMethod
	 * 
	 * @param screenShotName
	 * @param testName
	 * @return
	 */
	public String takeScreenShot(String screenShotName, String testName) {
		try {
			File file = new File("Screenshots" + fileSeperator + "Results");
			if (!file.exists()) {
				log.info("File created " + file);
				file.mkdir();
			}

			File screenshotFile = ((TakesScreenshot) threadDriver.get()).getScreenshotAs(OutputType.FILE);
			File targetFile = new File("test-output" + fileSeperator + "Screenshots" + fileSeperator + "Results"
					+ fileSeperator + testName, screenShotName);
			FileUtils.copyFile(screenshotFile, targetFile);

			return screenShotName;
		} catch (Exception e) {
			log.info("An exception occured while taking screenshot " + e.getCause());
			return null;
		}
	}

	/**
	 * This Method is to get Class Name to Save failed test cases screenshots as
	 * per class Name
	 * 
	 * @param testName
	 * @return
	 */
	public String getTestClassName(String testName) {
		String[] reqTestClassname = testName.split("\\.");
		int i = reqTestClassname.length - 1;
		log.info("Required Test Name : " + reqTestClassname[i]);
		return reqTestClassname[i];
	}

	/**
	 * Set up test execution variables for the current test class
	 * 
	 * @param browser:
	 *            Browser to execute (can be "firefox", "ie", or "chrome"
	 * @param platform:
	 *            Environment to execute the browser on (can be "local" or
	 *            "sauce")
	 * @param context:
	 *            Method context allowing for extracting test method name to set
	 *            as sauce lab job description.
	 * 
	 */
	@BeforeMethod(alwaysRun = true)
	@Parameters({ "browser", "platform" })
	public void beforeMethod(@Optional("firefox") String browser, @Optional("sauce") String platform, Method context) {

		log.info("beforeMethod(): Testing with browser " + browser + " on platform " + platform);

		// Initialize the driver for the desired platform
		switch (platform) {
		case "local":
			threadDriver.set(createWebDriverLocal(browser));
			break;
		case "sauce":
			threadDriver.set(createWebDriverSauce(browser, context));
			break;
		case "perfecto":
			threadDriver.set(createWebDriverPerfecto(browser));
			break;
		default:
			Assert.fail("Invalid platform parameter + [" + platform + "] passed");

		}

		sessionId.set(getWebDriver().getSessionId().toString());
		threadDriver.get().manage().window().maximize();
		threadDriver.get().manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

	}

	/**
	 * This method is for loading Property file Before starting the bactch
	 * execution
	 */
	/*@BeforeClass(alwaysRun = true)
	public void beforeClass() {
		log.info("DEBUG: Starting beforeClass");
		// Load Element Map properties
		elementMap = new java.util.Properties();
		InputStream in = getClass().getResourceAsStream("/ees_ElementMap.properties");
		try {
			elementMap.load(in);
			in.close();
			log.info("DEBUG: SUCCESSFULLY LOADED elementMap");
		} catch (IOException e) {
			Assert.fail("Exception loading element map", e);
		}
	}*/

	/**
	 * Creates a new instance of the driver object with desired capabilities
	 * running a local browser.
	 * 
	 * @param browser:
	 *            Browser to instantiate (can be "firefox", "chrome" or "ie"
	 * @return New RemoteWebDriver instance for a local browser
	 * 
	 * @author
	 */
	private RemoteWebDriver createWebDriverLocal(String browser) {
		DesiredCapabilities capabilities = null;
		RemoteWebDriver newDriver = null;
		switch (browser) {
		case "firefox":

			
			
			ProfilesIni myProfile = new ProfilesIni();
			
//			FirefoxProfile ffprofile = myProfile.getProfile("default");
			capabilities = DesiredCapabilities.firefox();
//			FirefoxOptions option = new FirefoxOptions().setLogLevel(Level.OFF);
			
//			capabilities = option.addTo(DesiredCapabilities.firefox());
			FirefoxOptions option = new FirefoxOptions();
//			option.addPreference("--log", "error");
//			option.addPreference("log", "{level: "logging":"level":"trace"}");
			capabilities.setCapability({"moz:firefoxOptions": {"logging":"level":"trace"}});
			
//			if (ffprofile == null) {
//				ffprofile = new FirefoxProfile();
//			}
			// Configuration to use FF tabs to view PDFs even if Acrobat
			// installed
//			ffprofile.setPreference("browser.helperApps.neverAsk.openFile", "application/pdf");
//			ffprofile.setPreference("plugin.disable_full_page_plugin_for_types", "");
//			capabilities.setCapability(FirefoxDriver.PROFILE, ffprofile);
			
			System.setProperty("webdriver.firefox.marionette","Drivers" + File.separator + "geckodriver.exe");
			
			newDriver = new FirefoxDriver(capabilities);
			
			
			break;
		case "chrome":
			// Assumes web driver executable is in 'Drivers' directory under
			// project.
			System.setProperty("webdriver.chrome.driver", "Drivers" + File.separator + "chromedriver.exe");
			ChromeDriverService service = ChromeDriverService.createDefaultService();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			options.addArguments("--start-maximized");
			options.addArguments("--disable-extensions");
			newDriver = new ChromeDriver(service, options);
			break;
		case "ie":
			// Assumes web driver executable is in 'Drivers' directory under
			// project.
			capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
			capabilities.setCapability(CapabilityType.VERSION, "11");
			capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability("ignoreZoomSetting", true);
			System.setProperty("webdriver.ie.driver", "Drivers" + File.separator + "IEDriverServer.exe");
			newDriver = new InternetExplorerDriver(capabilities);
			break;
		default:
			Assert.fail("Invalid browser parameter passed");
		}

		return newDriver;
	}

	/**
	 * Creates a new instance of the driver object with desired capabilities
	 * running in a sauce labs environment.
	 * 
	 * This requires that the runtime environment have two variables defined:
	 * SAUCE_USERNAME: Your sauce Labs login username SAUCE_ACCESS_KEY: Your
	 * sauce labs login access key (obtained from "Account")
	 * 
	 * @param browser:
	 *            Browser to instantiate (can be "firefox", "chrome" or "ie"
	 * @param context:
	 *            Method context allowing for extraction of test method name for
	 *            Sauce job name.
	 * @return New RemoteWebDriver instance for a local browser
	 * 
	 * @author
	 */
	private RemoteWebDriver createWebDriverSauce(String browser, Method context) {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		RemoteWebDriver newDriver = null;
		capabilities = new DesiredCapabilities();
		String USERNAME = System.getenv("SAUCE_USERNAME");
		String ACCESS_KEY = System.getenv("SAUCE_ACCESS_KEY");
		String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";

		if (USERNAME == null || ACCESS_KEY == null) {
			Assert.fail(
					"Missing value for environment variable(s) SAUCE_USERNAME or SAUCE_ACCESS_KEY.  Check environment configuration and try again");
		}

		authentication.setUsername(USERNAME);
		authentication.setAccessKey(ACCESS_KEY);

		switch (browser) {
		/**************** chrome ****************************/
		case "chrome":
			capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "chrome");
			capabilities.setCapability(CapabilityType.VERSION, "47");
			capabilities.setCapability(CapabilityType.PLATFORM, "Windows 7");
			capabilities.setCapability("screenResolution", "1280x1024");
			break;

			/**************** FireFox ****************************/
		case "firefox":
			capabilities = DesiredCapabilities.firefox();
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "firefox");
			capabilities.setCapability(CapabilityType.VERSION, "52");
			capabilities.setCapability(CapabilityType.PLATFORM, "Windows 7");
			capabilities.setCapability("screenResolution", "1280x1024");
			break;

			/**************** Internet Explorer 11 ****************************/
		case "ie":
			capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability("seleniumVersion", "2.46.0");
			capabilities.setCapability("iedriverVersion", "2.46.0");
			capabilities.setCapability("platform", "Windows 7");
			capabilities.setCapability("version", "11.0");
			capabilities.setCapability("screenResolution", "1280x1024");
			break;

			/**************** Safari ****************************/
		case "safari":
			capabilities = DesiredCapabilities.safari();
			capabilities.setCapability("platform", "OSX 10.8");
			capabilities.setCapability("screenResolution", "1280x1024");
			break;

			/**************** Iphone ****************************/
		case "iphone":
			capabilities = DesiredCapabilities.iphone();
			capabilities.setCapability("platform", "OS X 10.10");
			capabilities.setCapability("version", "9.1");
			capabilities.setCapability("deviceName", "iPhone 5s");
			capabilities.setCapability("deviceOrientation", "portrait");
			break;

			/**************** Ipad ****************************/
		case "ipad":
			capabilities = DesiredCapabilities.iphone();
			capabilities.setCapability("platform", "OS X 10.10");
			capabilities.setCapability("version", "9.1");
			capabilities.setCapability("deviceName", "iPad 2");
			capabilities.setCapability("deviceOrientation", "portrait");
			break;

			/**************** Ipad ****************************/
		case "andriod":
			capabilities = DesiredCapabilities.android();
			capabilities.setCapability("deviceName", "Samsung Galaxy Note Emulator");
			capabilities.setCapability("deviceOrientation", "portrait");
			break;

			/****************
			 * mobile emulator, Nexus + Safari*************************** case
			 * "nexusSafari": capabilities.setCapability("browserName", "Safari");
			 * capabilities.setCapability("deviceName", "Google Nexus 7 HD Emulator"
			 * ); capabilities.setCapability(CapabilityType.VERSION, "9");
			 * capabilities.setCapability("platformName", "iOS"); break;
			 */

			/****************
			 * safari*************************** REMOVED FOR NOW. Safari has a bug
			 * with Selenium 2.45 around calling driver.get(URL) when the page is
			 * already at URL, causes timeout error. case "safari": capabilities =
			 * DesiredCapabilities.safari();
			 * capabilities.setCapability("browserName","safari");
			 * capabilities.setCapability(CapabilityType.VERSION, "9");
			 * 
			 * capabilities.setCapability("platform", "OSX 10.11");
			 * capabilities.setCapability("screenResolution", "1024x768"); //OS X
			 * Yosemite //capabilities.setCapability("platform", "OSX 10.8"); break;
			 */
		default:
			Assert.fail("Invalid sauceLab browser parameter [" + browser + "]");
		}

		String jobName = "EES Test Execution of [" + this.getClass().getSimpleName() + ":" + context.getName()
		+ "] - Using " + capabilities.getBrowserName() + " in environment " + profile;
		capabilities.setCapability("name", jobName);

		try {
			newDriver = new RemoteWebDriver(new URL(URL), capabilities);
		} catch (MalformedURLException e) {
			Assert.fail("Invalid SauceLabs URL: [" + URL + "]", e);
		}

		log.info("Sucessfully configured connection to Sauce Labs");

		return newDriver;
	}

	/**
	 * This method is for Perfecto Execution configuration
	 * 
	 * @param browser
	 * @return
	 */
	private RemoteWebDriver createWebDriverPerfecto(String browser) {
		DesiredCapabilities capabilities = null;
		String host = "optum.perfectomobile.com";
		String perfectoUserNAme = System.getenv("PERFECTO_USERNAME");
		String PerfectoPassword = System.getenv("PERFECT_PASSWORD");
		String URL = "https://" + host + "/nexperience/perfectomobile/wd/hub";
		String browserName = "mobileOS";
		String deviceID;
		RemoteWebDriver newDriver = null;

		if (perfectoUserNAme == null || PerfectoPassword == null) {
			Assert.fail(
					"Missing value for environment variable(s) cloudUser or cloudPw.  Check environment configuration and try again");
		}

		switch (browser) {
		//**************** iphone6s ****************************//*
		case "iphone":

			deviceID = "9F1EE4D3A4F2176863EBF800AC7CDA6291050724";
			capabilities = new DesiredCapabilities(browserName, "", Platform.ANY);

			// define credentials for the CQ Lab connection
			capabilities.setCapability("user", perfectoUserNAme);
			capabilities.setCapability("password", PerfectoPassword);

			// Selecting Device By Device Id
			capabilities.setCapability("deviceName", deviceID);
			// select the device to use for the testing

			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("platformVersion", "5.1.1*");

			break;

			//**************** Samsung 5s ****************************//*
		case "andriod":

			deviceID = "559AC393";
			capabilities = new DesiredCapabilities(browserName, "", Platform.ANY);

			// define credentials for the CQ Lab connection
			capabilities.setCapability("user", perfectoUserNAme);
			capabilities.setCapability("password", PerfectoPassword);

			// Selecting Device By Device Id
			capabilities.setCapability("deviceName", deviceID);
			// select the device to use for the testing

			capabilities.setCapability("platformName", "iOS");
			capabilities.setCapability("platformVersion", "9.1*");

			break;

			//**************** Internet Explorer 11 ****************************//*
		case "ie":

			break;
		default:
			Assert.fail("Invalid perfecto browser parameter [" + browser + "]");
		}

		try {
			newDriver = new RemoteWebDriver(new URL(URL), capabilities);
		} catch (MalformedURLException e) {
			Assert.fail("Invalid Perfecto URL: [" + URL + "]", e);
		}

		log.info("Sucessfully configured connection to Perfecto");

		return newDriver;
	}

	/**
	 *
	 * @return the Sauce Job id for the current thread
	 */
	public String getSessionId() {
		return sessionId.get();
	}

	/*
	 *
	 * @return the {@link SauceOnDemandAuthentication} instance containing the
	 *         Sauce username/access key
	 */
	@Override
	public SauceOnDemandAuthentication getAuthentication() {
		return authentication;
	}
	/**
	 * Updating Testcase Results into Rally.
	 * 
	 * @param testCaseID
	 * @param Result
	 * @throws Exception
	 */
	public void RallyTestcaseUpdation(String testCaseID, String Result) throws Exception {

		String RALLYUSERNAME = System.getenv("RALLY_USERNAME");
		String RALLYPASSWORD = System.getenv("RALLY_PASSWORD");
		String host = "https://rally1.rallydev.com";
		String wsapiVersion = "v2.0";
		// String projectRef = "/iset/Team Primavera";
		String workspaceRef = "/Secure Projects";
		// String applicationName = "RestExample_AddTCR";

		@SuppressWarnings("deprecation")
		RallyRestApi restApi = new RallyRestApi(new URI(host), RALLYUSERNAME, RALLYPASSWORD);
		restApi.setWsapiVersion(wsapiVersion);
		// restApi.setApplicationName(applicationName);

		/*
		 * //fetch defect QueryRequest defectRequest = new
		 * QueryRequest("defect");
		 * 
		 * defectRequest.setFetch(new Fetch("FormattedID", "Name", "State",
		 * "Priority")); defectRequest.setQueryFilter(new QueryFilter("State",
		 * "=", "Fixed").and(new QueryFilter("Priority", "=",
		 * "Resolve Immediately"))); defectRequest.setOrder(
		 * "Priority ASC,FormattedID ASC");
		 * 
		 * defectRequest.setPageSize(25); defectRequest.setLimit(100);
		 * 
		 * QueryResponse queryResponse = restApi.query(defectRequest); JsonArray
		 * userQueryResults = queryResponse.getResults(); JsonElement
		 * userQueryElement = userQueryResults.get(0); JsonObject
		 * userQueryObject = userQueryElement.getAsJsonObject(); log.info("");
		 */

		// Read User
		QueryRequest userRequest = new QueryRequest("User");
		userRequest.setFetch(new Fetch("UserName", "Subscription", "DisplayName", "SubscriptionAdmin"));
		userRequest.setQueryFilter(new QueryFilter("UserName", "=", RALLYUSERNAME));
		QueryResponse userQueryResponse = restApi.query(userRequest);
		JsonArray userQueryResults = userQueryResponse.getResults();
		JsonElement userQueryElement = userQueryResults.get(0);
		JsonObject userQueryObject = userQueryElement.getAsJsonObject();
		String userRef = userQueryObject.get("_ref").getAsString();
		log.info(userRef);

		// Query for Test Case to which we want to add results
		QueryRequest testCaseRequest = new QueryRequest("TestCase");
		testCaseRequest.setFetch(new Fetch("FormattedID", "Name"));
		testCaseRequest.setWorkspace(workspaceRef);
		testCaseRequest.setQueryFilter(new QueryFilter("FormattedID", "=", testCaseID));
		// testCaseRequest.setQueryFilter(new QueryFilter("FormattedID", "=",
		// tcid));
		QueryResponse testCaseQueryResponse = restApi.query(testCaseRequest);
		JsonObject testCaseJsonObject = testCaseQueryResponse.getResults().get(0).getAsJsonObject();
		String testCaseRef = testCaseQueryResponse.getResults().get(0).getAsJsonObject().get("_ref").getAsString();

		try {
			for (int i = 0; i < 1; i++) {

				// Add a Test Case Result
				log.info(testCaseRef);
				log.info("Creating Test Case Result...");
				JsonObject newTestCaseResult = new JsonObject();
				newTestCaseResult.addProperty("Verdict", Result);
				// newTestCaseResult.addProperty("Verdict", Result);
				java.util.Date date = new java.util.Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
				String timestamp = sdf.format(date);
				newTestCaseResult.addProperty("Date", timestamp);
				newTestCaseResult.addProperty("Notes", "Updated by Automation Scripts");
				newTestCaseResult.addProperty("Build", "2.0");
				newTestCaseResult.addProperty("Tester", userRef);
				newTestCaseResult.addProperty("TestCase", testCaseRef);
				newTestCaseResult.addProperty("TestSet", 1);
				// newTestCaseResult.addProperty("Workspace", workspaceRef);

				CreateRequest createRequest = new CreateRequest("testcaseresult", newTestCaseResult);
				CreateResponse createResponse = restApi.create(createRequest);
				if (createResponse.wasSuccessful()) {

					log.info(String.format("Created %s", createResponse.getObject().get("_ref").getAsString()));

					// Read Test Case
					String ref = Ref.getRelativeRef(createResponse.getObject().get("_ref").getAsString());
					log.info(String.format("\nReading Test Case Result %s...", ref));
					GetRequest getRequest = new GetRequest(ref);
					getRequest.setFetch(new Fetch("Date", "Verdict"));
					GetResponse getResponse = restApi.get(getRequest);
					JsonObject obj = getResponse.getObject();
					log.info(String.format("my Read Test Case Result. Date = %s, Verdict = %s",
							obj.get("Date").getAsString(), obj.get("Verdict").getAsString()));
				} else {
					String[] createErrors;
					createErrors = createResponse.getErrors();
					log.info("Error occurred creating Test Case Result: ");
					for (int j = 0; i < createErrors.length; j++) {
						log.info(createErrors[j]);
					}
				}
			}

		} finally {
			// Release all resources
			restApi.close();
		}
	}

	/**
	 * /** This Method is to verify all dropdown values. Need to Pass parameter
	 * Element and Dropdown Actual values
	 *
	 * @param by
	 * @param actualOptions
	 */

	public void fnVerifyDropdownValues(WebElement element, List<String> actualOptions) {
		try {

			Select dropdown = new Select(element);
			List<WebElement> allItems = dropdown.getOptions();
			for (WebElement item : allItems)
				expectedOptions.add(item.getText());
			List resultList = ListUtils.subtract(expectedOptions, actualOptions);
			List<String> emptyStringList = new ArrayList<String>();
			emptyStringList.add("");
			List<String> noneStringList = new ArrayList<String>();
			noneStringList.add("None");
			if (!(emptyStringList.equals(resultList) || noneStringList.equals(resultList) || resultList.isEmpty())) {
				log.info("Drop down Verification Error: Error in verification of dropdown values!");
			}
			log.info("Drop down Verification Pass:verification of dropdown values!");
			expectedOptions.clear();
		} catch (Exception e) {
			log.info("TestError: Error in verification of dropdown values!");
			expectedOptions.clear();
		}

	}

	/**
	 * This Method is to verify Selected dropdown values. Need to Pass parameter
	 * Element and Dropdown values string
	 * 
	 * @param by
	 * @param exptecedValue
	 */
	public void fnVerifySelectedDropDownValue(WebElement element, String exptecedValue) {
		try {
			//fnWaitForElement(by, longTimeout);
			Select dropdown = new Select(element);
			WebElement option = dropdown.getFirstSelectedOption();
			actualValue = option.getText();
			Assert.assertEquals(actualValue, exptecedValue, "FAIL - Acutal results Unable to Match Expected address");
			log.info(" verified Expected Value Exists:  " + exptecedValue);
		} catch (Exception e) {
			log.info("TestError: Error in verification of dropdown values!");
		}
	}

	/**
	 * This Method is to Click by using JavascriptExecutor Need to Pass By
	 * Element
	 * 
	 * @param by
	 */
	public void fnClickElementByJS(WebDriver driver, WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;

		executor.executeScript("arguments[0].click();", element);
	}

	/**
	 * This Method is for Verifying only specific dropdown values need to pass
	 * element and Values string array
	 * 
	 * @param expected
	 * @param elementLocator
	 */

	public void fnCheckOptions(String[] expected, WebElement element) {
		List<WebElement> options = element.findElements(By.xpath("//option"));
		for (int j = 0; j < expected.length; j++) {
			for (WebElement opt : options) {
				if (opt.getText().contains(expected[j])) {
					log.info("value exists in drop down " + opt.getText());
				}
			}

		}

	}

	/**
	 * To check Drop down values doesn't not contains values
	 * 
	 * @param expected
	 * @param elementLocator
	 */
	public void fnCheckOptionsNotContains(String[] expected,WebElement element) {
		List<WebElement> options = element.findElements(By.xpath("//option"));
		for (int j = 0; j < expected.length; j++) {
			for (WebElement opt : options) {
				if (!opt.getText().contains(expected[j])) {
					log.info("value doesnt exists in drow down" + opt.getText());
				}
			}

		}

	}

	/**
	 * This Method is to verify Specific Drop down values exist Need to pass
	 * parameter by Element & Drop down values in String Array
	 * 
	 * @param expected
	 * @param elementLocator
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws Exception
	 */
	public void fnVerifyTrueOptionExists(String[] expected, WebElement element)
			throws ClassNotFoundException, IOException, InterruptedException, Exception {
		Select select = new Select(element);
		List<WebElement> allOpts = select.getOptions();
		log.info("Size of Dropdown is : " + allOpts.size());
		boolean isOptionExists = false;
		for (int j = 0; j < expected.length; j++) {
			for (WebElement opt : allOpts) {
				if (opt.getText().equalsIgnoreCase(expected[j]))
					isOptionExists = true;
			}
			Assert.assertTrue(isOptionExists);
			log.info("Drop Down Values Match : " + expected[j]);
		}

	}

	/**
	 * This Method is to verify Drop down values doesn't exist Need to pass
	 * parameter By Element & Drop down values in String Array
	 * 
	 * @param expected
	 * @param elementLocator
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws Exception
	 */

	public void fnVerifyFalseOptionExists(String[] expected, WebElement element)
			throws ClassNotFoundException, IOException, InterruptedException, Exception {
		Select select = new Select(element);
		List<WebElement> allOpts = select.getOptions();
		log.info("Size of Dropdown is : " + allOpts.size());
		boolean isOptionExists = false;
		for (int j = 0; j < expected.length; j++) {
			for (WebElement opt : allOpts) {
				if (opt.getText().equalsIgnoreCase(expected[j]))
					isOptionExists = true;
			}
			Assert.assertFalse(isOptionExists);
			log.info("Drop Down Values Doesn't Match : " + expected[j]);
		}

	}

	/**
	 * This Method is to verify table Headers. Need to Pass parameter Table
	 * Header String[] and By element
	 * 
	 * @param expectedTableNames
	 * @param by
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws Exception
	 */
	public void fnVerifyTableHeaderExists(String[] expectedTableNames, By by)
			throws ClassNotFoundException, IOException, InterruptedException, Exception {
		/*
		 * RemoteWebDriver driver = getWebDriver();
		 * 
		 * List<WebElement> AcutalTableNames = driver.findElements(by);
		 * 
		 * for (int i = 0; i < AcutalTableNames.size(); i++) { log.info(
		 * "Size is :" + AcutalTableNames.size());
		 * 
		 * log.info("Actual Table Name = " + AcutalTableNames.get(i).getText());
		 * Assert.assertEquals(AcutalTableNames.get(i).getText(),
		 * expectedTableNames[i], "FAIL - Unable to Match expected Labels" + i);
		 * log.info(" verified Expected value Exists:  " +
		 * expectedTableNames[i]);
		 * 
		 * }
		 */

	}

	/**
	 * This Methos to Verify text of value. Need to pass parameter Exepected
	 * value and By element
	 * 
	 * @param expected_text
	 * @param by
	 */
	public void fnAssertEqualsText(String expected_text, WebElement element) {
		String Actual_text = element.getText();
		Assert.assertEquals(Actual_text, expected_text, "FAIL-text did not match");

	}

	/**
	 * To Webdriver function to click
	 * 
	 * @param by
	 * @throws Exception
	 */
	public void fnClick(WebElement element, WebDriver driver) throws Exception {
		fnClickIfEnabled(element, driver);
	}

	/**
	 * This Method is Verify Alert text and click on it Need to Pass Alert text
	 * as Parameter
	 * 
	 * @param textValue,
	 *            this also can be a regular expression
	 * @return
	 */
	public boolean fnIsAlertTextPresent(String textValue) {
		try {
			String EAlert_Text = textValue;
			String AAlert_Text = threadDriver.get().switchTo().alert().getText();
			log.info("AlertInfo: Alert Text is " + " " + AAlert_Text);
			Assert.assertEquals(true, AAlert_Text.matches(EAlert_Text));
			log.info("TestInfo:Alert Text is Matching!");
			threadDriver.get().switchTo().alert().accept();
			return true;

		} catch (NoAlertPresentException ex) {
			return false;
		}
	}

	/**
	 * This Method is to check boxes using index
	 * 
	 * @param by
	 * @param index
	 * @throws InterruptedException
	 */
	public void fnCheckByIndex(By by, String index) throws InterruptedException {
		List<WebElement> eles = threadDriver.get().findElements(by);
		int Index = Integer.parseInt(index);
		int counter = 0;
		for (WebElement ele : eles) {
			if (counter == Index) {
				ele.click();
				break;
			}
			counter++;
		}
	}

	/**
	 * This Method to Perform Action on tho that element & click on it Using
	 * Actions Need to Pass parameter of the Element locator to perform action
	 * 
	 * @param by
	 * @throws InterruptedException
	 */
	public void fnActionsClick(WebDriver driver, WebElement element) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, timeOut);

		wait.until(ExpectedConditions.visibilityOf(element));
		Actions builder = new Actions(driver);
		builder.moveToElement(element).build().perform();
		element.click();
	}




	/**
	 * This Method will verify is alert present or not
	 * 
	 */
	public void fnWaitForAlertPresent(WebDriver driver ) {

		
		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			
			
		} catch (TimeoutException eTO) {
			
			log.info("NO Alert Present");
		}
		
	}

	/**
	 * This Method will help to find Age in years
	 * 
	 */
	public static String AgeInYears(String Date) {

		String[] parts = Date.split("/");
		String month = parts[0]; // 004
		String day = parts[1];
		String year = parts[2];

		/*
		 * LocalDate today = LocalDate.now(); LocalDate birthday =
		 * LocalDate.of(Integer.parseInt(year), Integer.parseInt(month),
		 * Integer.parseInt(day));
		 * 
		 * Period p = Period.between(birthday, today);
		 */
		// long p2 = ChronoUnit.DAYS.between(birthday, today);
		/*
		 * System.out.println("You are " + p.getYears() + " years, " +
		 * p.getMonths() + " months, and " + p.getDays() + " days old. (" + p2 +
		 * " days total)");
		 */
		// return Integer.toString(p.getYears());
		return null;
	}

	/**
	 * This Method is verifying Drop down values using sorting order
	 * 
	 * @param by
	 * @return
	 */
	public boolean fnVerifyDropDownListSorting(WebElement element) {
		int TeamQuickListSize = new Select(element).getOptions().size();
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < TeamQuickListSize; i++) {
			list.add(new Select(element).getOptions().get(i).getText());
		}
		log.info("before sorting  " + list);
		Collections.sort(list);
		log.info("After sorting  " + list);
		Boolean SotringStatus = true;
		for (int i = 0; i < TeamQuickListSize; i++) {
			if (!list.get(i).equals(new Select(element).getOptions().get(i).getText())) {
				SotringStatus = false;
			}
		}

		return SotringStatus;
	}

	/**
	 * This Method is to check Whether Element is Displayed or not
	 * 
	 * @param by
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIsDisplayed(WebElement element) throws InterruptedException {
		boolean status = false;
		for (int i = 1; i <= 10; i++) {
			try {
				if (element.isDisplayed()) {
					status = true;
					log.info("Expected Element is Displayed : " );
					break;
				}
			} catch (Exception e) {
			}
			Thread.sleep(1000);
		}
		return status;
	}

	/**
	 * Mouse to over to a webElement
	 * 
	 * @param element
	 */
	public void fnMouseOverToElement(WebElement element) {
		Actions act = new Actions(threadDriver.get());
		act.moveToElement(element).build().perform();
	}
	
	public void fnMouseOverAndClick(WebElement hoverElement,WebElement clickableElement) throws Exception
	{
		Actions action = new Actions(threadDriver.get());
		 
        action.moveToElement(hoverElement).build().perform();
 
        clickableElement.click();
        Thread.sleep(3000);
	}

	/**
	 * It switches to frame and perform click operation on a given element
	 * 
	 * @param frame
	 * @param element
	 */
	public void fnSwitchToFrameAndClickElement(By frame, By element) {
		threadDriver.get().switchTo().defaultContent();
		threadDriver.get().switchTo().frame(threadDriver.get().findElement(frame));
		// driver.findElement(element).click();
		threadDriver.get().switchTo().defaultContent();
	}

	/**
	 * to Verify the Selected dropdown value
	 * 
	 * @param by
	 * @param name
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIsSeletedTrue(By by, String name) throws InterruptedException {
		boolean status = false;
		// --Thread.sleep(1000);
		if (threadDriver.get().findElement(by).isSelected()) {
			status = true;
			log.info(name + " Selected");
		} else {
			Assert.fail(name + " not Selected");
			// status = false;
		}

		return status;
	}

	/**
	 * To Verify selected dropdown value is is false
	 * 
	 * @param by
	 * @param name
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIsSeletedFalse(By by, String name) throws InterruptedException {
		boolean status = false;
		// --Thread.sleep(1000);
		if (!threadDriver.get().findElement(by).isSelected()) {
			log.info(name + " not Selected");
		} else {
			Assert.fail(name + " Selected");
		}

		return status;
	}

	/**
	 * To Verify Element is Enabled True
	 * 
	 * @param by
	 * @param name
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIsEnabledTrue(By by, String name) throws InterruptedException {
		boolean status = false;
		// --Thread.sleep(1000);
		if (threadDriver.get().findElement(by).isEnabled()) {
			status = true;
			log.info(name + " enabled");
		} else {
			Assert.fail(name + " not enabled");
			// status = false;
		}

		return status;
	}

	/**
	 * To Verify Element is Enabled False
	 * 
	 * @param by
	 * @param name
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIsEnabledFalse(WebElement element, String name) throws InterruptedException {
		boolean status = false;
		if (!element.isEnabled()) {
			status = true;
			log.info(name + " not enabled");
		} else {
			Assert.fail(name + " enabled");
		}

		return status;
	}

	/**
	 * To Method is to Enter values in Textbox
	 * 
	 * @param by
	 * @param text
	 * @throws InterruptedException
	 */
	public void fnSendKeys(WebElement element, String text) throws InterruptedException {
		try {
			element.clear();
			element.sendKeys(text);
			log.info("Entered Text is : " + text);
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}

	}

	/**
	 * this method to getText of the Element
	 * 
	 * @param by
	 * @return
	 * @throws InterruptedException
	 */
	public String fnGetText(WebElement element) throws InterruptedException {
		GetText = null;
		try {
			GetText = element.getText();
			log.info("GetText value is : " + GetText);

		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
		return GetText;
	}

	/**
	 * To Verify the text is alpha numeric value
	 * 
	 * @param String
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIsAlphaNumericText(String str) throws InterruptedException {
		log.info("Started ALpha numeric check for the string " + str);
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c < 0x30 || (c >= 0x3a && c <= 0x40) || (c > 0x5a && c <= 0x60) || c > 0x7a)
				return false;
			break;
		}
		return true;

	}

	/**
	 * this Method is to grt Attribute value of Element
	 * 
	 * @param by
	 * @param Attribute
	 * @return
	 * @throws InterruptedException
	 */
	public String fnGetAttribute(WebElement element, String Attribute) throws InterruptedException {
		Attributetext = null;
		try {

			Attributetext = element.getAttribute(Attribute);
			log.info("Feteched Attribute value is : " + Attributetext);

		} catch (Exception e) {
			log.info(e.getLocalizedMessage());
		}
		return Attributetext;
	}

	/**
	 * This Method to verify drop down values Exists
	 * 
	 * @param by
	 * @param actualOptions
	 */
	public void fnAssertDropdownValues(By by, List<String> actualOptions) {
		try {
			Select dropdown = new Select(threadDriver.get().findElement(by));
			List<WebElement> allItems = dropdown.getOptions();

			for (int i = 0; i < actualOptions.size(); i++) {

				if (!allItems.get(i).getText().contains(actualOptions.get(i)))
					Assert.fail(actualOptions.get(i) + " value not matched with respected value");
				// log.info(actualOptions.get(i) + " value not matched with
				// respected value");
				else
					log.info(actualOptions.get(i) + "Drop down value  matched with respected value");
			}

		} catch (Exception e) {
			log.info("TestError: Error in verification of dropdown values!");
		}

	}

	/**
	 * Date Generatror
	 * 
	 * @param dateValue
	 * @return
	 * @throws ParseException
	 */
	public String getDate(String dateValue) throws ParseException {
		String dateInString;
		Calendar calendar = Calendar.getInstance();
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		date = dateFormat.parse(dateValue);
		calendar.setTime(date);
		int mm = calendar.get(Calendar.MONTH);
		int yyyy = calendar.get(Calendar.YEAR);
		int dd = calendar.get(Calendar.DATE);
		dateInString = (mm + 1) + "/" + dd + "/" + yyyy;
		return dateInString;
	}

	/**
	 * Date Generator for DD/MM/YYYY format
	 * 
	 * @return
	 * @throws ParseException
	 */
	public String dateMonthYear() throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String DateFormate = getDate(dateFormat.format(date.getTime()));
		return DateFormate;
	}

	public void VerifyCurrentDate() throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
		Date date = new Date();
		String CurrentDate = dateFormat.format(date);
		log.info("Current Date is :" + CurrentDate);
	}

	/**
	 * This Method is to verify Alert Present using waitTime
	 * 
	 * @param waitTime
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnIntAlertPresent(int waitTime,WebDriver driver) throws InterruptedException {
		Boolean foundAlert = false;
		for (int i = 0; i < waitTime; i++) {
			try {
				driver.switchTo().alert();
				foundAlert = true;
				log.info("Alert Found...");
				break;
			} catch (Exception e) {
				log.info("Waiting for Alert...");
			}
			Thread.sleep(1000);
		}

		return foundAlert;
	}

	/**
	 * This Method is to Accept Alerts
	 * 
	 * @throws InterruptedException
	 */
	public void fnAlertAccept(WebDriver driver) throws InterruptedException {
		Thread.sleep(3000);
		try {
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info("Seems it had a problem with handling alert - accept");
			Assert.fail("Seems it had a problem with handling alert - accept");
		}
	}

	/**
	 * This Method is to Dismiss Alerts
	 * 
	 * @throws InterruptedException
	 */
	public void fnAlertDismiss(WebDriver driver) throws InterruptedException {
		try {
			Alert alert = driver.switchTo().alert();
			alert.dismiss();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info("Seems it had a problem with handling alert - dismiss");
			Assert.fail("Seems it had a problem with handling alert - dismiss");
		}
	}

	/**
	 * This explicit wait method will help full at the time of handling AJAX
	 * elements
	 * 
	 * @syntax fnWaitForElementPresent(final By locator);
	 * @param locator
	 * @return
	 */
	/*
	public WebElement fnWaitForElementPresent(final WebElement element , WebDriver driver) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(90, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		//ait.until(ExpectedConditions.visibilityOf(element))

		Boolean br = wait.until((new ExpectedCondition() {

			@Override
			public Boolean apply(WebDriver driver) {
				return element.isDisplayed();
			}
		}));
		return br;
	}*/

	/**
	 * This explicit wait method will help full at the time of handling AJAX
	 * elements
	 * 
	 * @syntax fnWaitForElementPresent(final By locator);
	 * @param locator
	 * @return
	 */

	public void fnWaitForElementToBeClickable(WebElement element,WebDriver driver) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			WebElement clickableElement = wait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
			log.info("TestError: Element is not in clickable!!!");
			log.info(e.getLocalizedMessage());
		}
	}

	/**
	 * 
	 * @param Title
	 * @param Seconds
	 * @return
	 * @throws InterruptedException
	 */
	public String fnSwitchToWindow(String Title, int Seconds,WebDriver driver) throws InterruptedException {
		String retunStatus = null;
		Boolean WindowStatus = false;
		for (int i = 0; i < Seconds; i++) {

			Set<String> handles = driver.getWindowHandles();
			String parent = driver.getWindowHandle();
			System.out.println("Window ID 's : " + handles);
			Iterator<String> it = handles.iterator();

			while (it.hasNext()) {

				driver.switchTo().window(it.next());
				// --Thread.sleep(5000);
				System.out.println(driver.getTitle());
				if (driver.getTitle().contains(Title)) {
					log.info("Seems It found Expected window and switching now");
					retunStatus = parent;
					// --Thread.sleep(4000);
					WindowStatus = true;
					break;
				} else {
					// --Thread.sleep(1000);
					log.info("not found expected window ... seems Found KM Launcher window");
					driver.switchTo().window(parent);
					// --Thread.sleep(3000);
				}
			}
			handles.removeAll(handles);
			// --Thread.sleep(1000);
			if (WindowStatus)
				break;
		}
		return retunStatus;

	}

	/**
	 * To select first option in the dropdown
	 * 
	 * @param locator
	 * @return
	 */
	public String fnGetFirstSelectedOption(WebDriver driver, WebElement element) {
		return new Select(element).getFirstSelectedOption().getText();
	}

	/**
	 * this method is to generate Random Number
	 * 
	 * @return
	 */
	public String generateEmpid() {
		Random rand = new Random();
		String codeNums = "012345678";
		int randomCodeLen = 9;
		String randomCode = "";
		for (int i = 0; i < randomCodeLen; ++i)
			randomCode = randomCode + codeNums.charAt(rand.nextInt(codeNums.length()));
		log.info("TestWarning:Generated random number Value is: " + randomCode);
		return randomCode;
	}
	
	
	public String generateSSN() {
		Random rand = new Random();
		String codeNums = "012345678";
		int randomCodeLen = 9;
		String randomCode = "";
		for (int i = 0; i < randomCodeLen; ++i)
			randomCode = randomCode + codeNums.charAt(rand.nextInt(codeNums.length()));
		log.info("TestWarning:Generated random number Value is: " + randomCode);
		return randomCode;
	}

	/**
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isInteger(String s) {
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			return false;
		} catch (NullPointerException e) {
			return false;
		}
		// only got here if we didn't return false
		return true;
	}

	/**
	 * To get Text from alert message
	 * 
	 * @return
	 */
	public String fnGetAlertText() {
		AlertText = null;
		try {
			AlertText = threadDriver.get().switchTo().alert().getText();
			log.info("Found Alert text is : " + AlertText);
		} catch (TimeoutException eTO) {
			log.info("No Alert Found to get text");
			AlertText = null;
		}
		return AlertText;
	}

	/**
	 * This Method to Verify URL. Need to pass parameter Exepected URL
	 * 
	 * @param expected_url
	 */
	public void validateURL(String expected_url,WebDriver driver) {
		String Actual_url = driver.getCurrentUrl();
		Assert.assertEquals(Actual_url, expected_url, "FAIL - URL Not Matched");
	}

	/**
	 * This method is to switch frame
	 * 
	 * @param frame
	 */
	/*public void fnSwitchToFrame(WebElement element, WebDriver driver) {
		try {
			driver.switchTo().defaultContent();
			threadDriver.get().switchTo().frame(element);
		} catch (Exception e) {
			log.info("Seems there is a problem with switching frame");
			Assert.fail("Seems there is a problem with switching frame");
		}

	}*/

	/**
	 * This method is to clear the value in input field
	 * 
	 * @param Locator
	 */
	public void fnClear(By Locator) {
		try {
			threadDriver.get().findElement(Locator).clear();
		} catch (Exception e) {
			log.info("Seems there is a problem with Element Identification " + Locator);
			Assert.fail("Seems there is a problem with Element Identification " + Locator);
		}

	}

	/**
	 * To Wait until Element is Visible
	 * 
	 * @param Locator
	 * @throws Exception
	 */
	public void fnWaitForvisible(By by) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(threadDriver.get(), timeOut);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			log.info("TestError: Error in waiting for element to be visible!");
			log.info(e.getLocalizedMessage());
		}
	}

	/**
	 * To Wait until Element is Enabled
	 * 
	 * @param Locator
	 * @throws Exception
	 */
	public void fnWaitForEnabled(WebElement element) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(threadDriver.get(), timeOut);
			wait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
			log.info("TestError: Error in waiting for element to be enabled!");
			log.info(e.getLocalizedMessage());
		}
	}

	/**
	 * To Type Text on Input Field if input is enabled
	 * 
	 * @param by
	 * @param Value
	 * @throws Exception
	 */
	public void fnTypeIfVisible(WebElement element, String Value, WebDriver driver) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			WebElement clickableElement = wait.until(ExpectedConditions.visibilityOf(element));
			clickableElement.sendKeys(Value);
		} catch (Exception e) {
			log.info("TestError: Error in inputting element!");
			log.info(e.getLocalizedMessage());
		}

	}

	/**
	 * To check the Element is Enabled & click on it
	 * 
	 * @param by
	 * @param Value
	 * @throws Exception
	 */
	public void fnClickIfEnabled(WebElement element, WebDriver driver) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			WebElement clickableElement = wait.until(ExpectedConditions.elementToBeClickable(element));
			clickableElement.click();
		} catch (Exception e) {
			log.info("TestError: Error in clicking element!");
			log.info(e.getLocalizedMessage());
		}
	}

	/**
	 * To Send Press Enter Key
	 * 
	 * @param by
	 * @throws Exception
	 */
	public void fnSendKeyEnter(WebElement element) throws Exception {
		try {
			element.sendKeys(Keys.ENTER);
		} catch (Exception e) {
			log.info("TestError: Error in Pressing Enter!");
			log.info(e.getLocalizedMessage());
		}
	}



	/**
	 * The Method is for Waiting until Spinner Icon Is not visible
	 * 
	 * @throws InterruptedException
	 */
	public void app_SpinnerInvisible(WebDriver driver) throws InterruptedException {
		try {
			log.info("Waiting for loading image to go away");
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(".//img[@class='loading']")));
		} catch (TimeoutException eTO) {
			eTO.getMessage();
		}
	}

	/*
	 * This Method is to verify masking. Need to Pass parameter string which is
	 * expected to have masking and starting Index of masking from the above
	 * string and Ending Index of masking from the above string
	 * 
	 * @param String
	 * 
	 * @param Start Index
	 * 
	 * @param End Index
	 * 
	 */
	public boolean fnVerifyMaskingContent(String string, int startIndex, int endIndex) {
		boolean status = true;

		String mask = string.substring(startIndex, endIndex);

		log.info("the mask is " + mask);

		for (int i = 0; i < endIndex; i++) {
			if (mask.charAt(i) != 'x') {
				status = false;
				Assert.fail("The masking failed");
			}
		}
		log.info("The masking verified");

		return status;
	}

	/**
	 * This Method is to press tab key
	 * 
	 * @param by
	 * 
	 */
	public void fnTabPress(WebElement element,WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, longTimeout);

		element.sendKeys(Keys.TAB);

	}

	/**
	 * This Method is to accept the available alert
	 * 
	 * 
	 * 
	 */
	public void fnIsAlertPresent_sendKeys(String text, WebDriver driver) {

		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			log.info("The Alert " + threadDriver.get().switchTo().alert().getText() + "is Accepted");
			driver.switchTo().alert().sendKeys(text);
			driver.switchTo().alert().accept();
		} catch (TimeoutException eTO) {
			eTO.getMessage();
		}

	}

	/**
	 * this Method is to verify Attribute value of Element
	 * 
	 * @param by
	 * @param Attribute
	 * @return
	 * @throws InterruptedException
	 */
	public boolean fnVerifyAttribute(WebElement element, String Attribute) throws InterruptedException {
		boolean attribute = false;
		try {
			element.getAttribute(Attribute);
			attribute = true;

		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
			attribute = false;
		}
		return attribute;
	}

	public void fnDefaultContent() {
		threadDriver.get().switchTo().defaultContent();
	}

	public Date fnstringToDate(String dateInString, String format) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date convertedCurrentDate = sdf.parse(dateInString);
		return convertedCurrentDate;

	}

	public int fncalDaysBetweenDates(Date to, Date from) {

		long diff = to.getTime() - from.getTime();
		return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

	}

	public boolean fnVerifyElementText(WebElement element, String Text) {
		try {
			String RunTimeText = element.getText();
			if (Text.trim().toLowerCase().contains(RunTimeText.trim().toLowerCase())) {
				return true;
			}
		} catch (Exception e) {
		}
		return false;

	}

	public void fnCheck(WebElement element) {

		if (!element.isSelected()) {
			element.click();
		}

	}

	public void fnUnCheck(WebElement element) {

		if (element.isSelected()) {
			element.click();
		}

	}



	/*
	 * This method to get the text of the drop down value
	 * 
	 */
	public String fngetSelectedDropDownValue(WebElement element) {
		GetSelectedDropDownValue = null;
		try {
			Select dropdown = new Select(element);
			WebElement option = dropdown.getFirstSelectedOption();
			GetSelectedDropDownValue = option.getText();
			log.info("Selected Drop dwon value is:  " + GetSelectedDropDownValue);
		} catch (Exception e) {
			log.info("TestError: Error in getting selected dropdown value");
		}
		return GetSelectedDropDownValue;
	}

	/*
	 * 
	 * This method is used to select a drop down using value attribute
	 */
	public void fnSelectByValue(String Value, WebElement element) {
		try {


			if (element != null) {
				Select select = new Select(element);
				select.selectByValue(Value);
				log.info("Selected value is : " + Value);
			}
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
	}

	/**
	 * This Method is to verify Specific Drop down size parameter by Element &
	 * Drop down size
	 * 
	 * @param elementLocator
	 * @param expected
	 *            size of the dropdown
	 * 
	 */
	public void fnVerifyDropdownSize(WebElement element, int size) {
		Select select = new Select(element);
		List<WebElement> allOpts = select.getOptions();
		log.info("Size of Dropdown is : " + allOpts.size());
		Assert.assertEquals(allOpts.size(), size);

	}



	/**
	 * 
	 */
	public void fnWaitForPageLoad(WebDriver driver) {
		System.out.println("Wating for ready state complete");
		(new WebDriverWait(driver, 100)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				JavascriptExecutor js = (JavascriptExecutor) d;
				String readyState = js.executeScript("return document.readyState").toString();
				log.info("Ready State: " + readyState);
				return (Boolean) readyState.equals("complete");
			}
		});
	}
	
	/** this function is to verify whether element is displayed or not
	 * 
	 */
	
	public void  fnVerifyElementDisplayed(WebElement element)
	{   try {
			Assert.assertTrue(element.isDisplayed(),element + " is not diplayed");
	} catch(NoSuchElementException e)
	{
		e.getMessage();
		log.info("element is not present "+element);
	}
			
	}
	public void fnSwitchFrame(String FrameName)
	{
		try {
			threadDriver.get().switchTo().frame(FrameName);
		} catch (Exception e) {
			log.info("frame is not avaliable" + FrameName);
			
		}

	}
	
	/**
	 * This method is to switch frame
	 * 
	 * @param frame
	 */
	public void fnSwitchToFrame(WebElement element, WebDriver driver) {
		try {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(element);
		} catch (Exception e) {
			log.info("Seems there is a problem with switching frame");
			Assert.fail("Seems there is a problem with switching frame");
		}

	}
	
	public void fnWaitAndSwitchToFrame(String frameName, WebDriver driver) {
		try {
			driver.switchTo().defaultContent();
			WebDriverWait wait = new WebDriverWait(driver,30);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
			log.info("switched to frame");
		} catch (Exception e) {
			log.info("Seems there is a problem with switching frame");
			Assert.fail("Seems there is a problem with switching frame");
		}

	}
	
	public String selectDate() throws IOException, InterruptedException
	  {
		  
		  DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		  Date date = new Date();
		  System.out.println("DATE IS: "+dateFormat.format(date));
		  return dateFormat.format(date);
	   
	  }
	public String generateRandomchar()
	{
		String charcter=RandomStringUtils.random(1, "abcdefghijkl");
		return charcter;

	}
	
	public String generateAddressFields()
	{
	
		String addrss_field=RandomStringUtils.randomAlphabetic(6);
		return addrss_field;

	}
	public String generatetext()
	{
	
		String txt=RandomStringUtils.randomAlphabetic(5);
		return txt;

	}
}
