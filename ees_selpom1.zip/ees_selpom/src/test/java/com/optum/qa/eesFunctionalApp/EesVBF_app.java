package com.optum.qa.eesFunctionalApp;

import java.util.ArrayList;

import org.apache.poi.poifs.crypt.standard.EncryptionRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optum.qa.pages.AddEmpDemographicsPage;
import com.optum.qa.pages.AssignPlansPage;
import com.optum.qa.pages.HomePage;
import com.optum.qa.pages.IDCardPage;
import com.optum.qa.pages.InquirePage;
import com.optum.qa.pages.InvoicesPage;
import com.optum.qa.pages.LoginPage;
import com.optum.qa.pages.ManageAccessPage;
import com.optum.qa.pages.ManageEmployeesPage;
import com.optum.qa.pages.PHSPage;
import com.optum.qa.pages.ReportsPage;
import com.optum.qa.pages.ReviewAndSubmitPage;

public class EesVBF_app extends EesWorkFlows {

	public Logger log = LoggerFactory.getLogger(this.getClass());

	@Test(groups="UAT")
	public void TC01_eCR_Reports() throws Exception {
		
		/*
	       Created By:- Suresh Itha
	       Modified Date:-06/13/2017
	       Screen Navigated:-LoginPage<HomePage<ReportsPage
	       High Level Summary:- Validating ECR Reports functionality via ExtUser
	         */

		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("eCRreports");
		String main_Window = driver.getWindowHandle();
		homePage.clickReportstab_eCR();
		ReportsPage reportspage=new ReportsPage(driver);
		//reportspage.click_Visit_UHC_costAndUtilizationSite_lnk(); --- STAGE
		//UAT
		driver.findElement(By.linkText("eCR Reporting Link")).click();
		Thread.sleep(3000);
		fnSwitchToWindow("Summary", 20, driver);
		reportspage.validate_eCR_functionality();
		driver.switchTo().window(main_Window);
		homePage.Click_LogOutLnk();
		
		
		

		
		
		 

	}

	@Test
	public void TC02_EEMS_ExternalUser() throws Exception {
		
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<EEMSReports
	       High Level Summary:- Validate EEMS Report Extuser < Reports validation
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("EEMSExternalUser");
		//homePage.Click_ElectronicEligibilityManagement();		
		homePage.clickReports();
		log.info("clickiking on Reports completed");
		//homePage.searchForGroup("1800727");
		//log.info("completed selection of group");
		Thread.sleep(6000);
		fnClickElementByJS(driver, driver.findElement(By.xpath("//*[@id='tab-link-electronicEligibilityMgmt']")));
		log.info("clicked on EEMS link");
		//fnWaitForPageLoad(driver);
		Thread.sleep(8000);
		homePage.click_visit_electroniclink();
		log.info("clicked on Visit_electronic link");
		Thread.sleep(8000);
		fnSwitchToWindow("EEMS - Home", 2000, driver);
		Thread.sleep(8000);
		homePage.validate_eems();
		log.info("EEMS validated sucessfully");
		
	}

	@Test

	public void TC03_EEMS_InternalUser() throws Exception
	{
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<EEMSReports
	       High Level Summary:- Validate EEMS Report Intuser < Reports validation
	         */
		
	log.info(" *** Execution Started");
	RemoteWebDriver driver = getWebDriver();

	log.info("Step1: Login to EES Site");
	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage = loginPage.doLogin("EEMSInternalUser");
	String mainWindow = driver.getWindowHandle();
	
	homePage.Click_ElectronicEligibilityManagement();
	log.info("clicked on EEMS link");
	homePage.Validate_EEMSPageLoad();
	log.info("validated EEMS Page");
	//Step 2
	homePage.Logout_EEMS();
	log.info("Step2: Clicked on Logout Button on EEMS Page");
	//Step 3
	driver.switchTo().window(mainWindow);
	log.info("Step3: Click on Logout Button on Main Window");
	homePage.Click_LogOutLnk();
		
	}

	@Test
	public void TC04_OBS_ExternalUser()  throws Exception
	{ 
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<invoicesPage
	       High Level Summary:- Validate invoices for OBS extuser
	         */

	log.info(" *** Execution Started");
	RemoteWebDriver driver = getWebDriver();

	log.info("Step1: Login to EES Site");
	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage = loginPage.doLogin("OBSExternalUser");
	String main_Window = driver.getWindowHandle();
	InvoicesPage invoicesPage=homePage.click_Invoices_Tab();
	log.info("clicked on invoices tab");
	invoicesPage.validate_OBS_External_user_invoice_screen();
	log.info("validated invoices screen");
	invoicesPage.click_closeWindowButton();
	log.info("clicked on close window button on invoices screen");
	driver.switchTo().window(main_Window);
	log.info("switched to main window");
	Thread.sleep(4000);
	homePage.Click_LogOutLnk();	
	Thread.sleep(6000);
	
	/*//invoicesPage.click_ok();
	Thread.sleep(1000);
	driver.switchTo().frame("invoicesIframe");
	fnVerifyElementDisplayed(driver.findElement(By.xpath("//*[contains(text(),'Invoice Listing')]")));
	//fnVerifyElementDisplayed(driver.findElement(By.xpath("invoiceListingForm:invoiceListingDataTable:0:j_id113")));
	fnGetCurrentWindowTitle(driver);
	driver.findElement(By.xpath(".//a[starts-with(@id, 'invoiceListingForm:invoiceListingDataTable:0')]")).click();
	(new WebDriverWait(driver, 3)).until(ExpectedConditions.numberOfWindowsToBe(3));
	ArrayList<String> tab3= new ArrayList<String>(driver.getWindowHandles());	
	driver.switchTo().window(tab3.get(tab3.size()-2));
	driver.close();
	Thread.sleep(10000);
	driver.switchTo().defaultContent();
	driver.close();
	invoicesPage.click_closeWindowButton();
	driver.switchTo().window(mainWindow);
	homePage.Click_LogOutLnk();
	*/

	}
	
	
	@Test

	public void TC05_OBS_internalUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<invoicesPage
	       High Level Summary:- Validate invoices for OBS intuser
	         */
		
	log.info(" *** Execution Started");
	RemoteWebDriver driver = getWebDriver();

	log.info("Step1: Login to EES Site");
	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage = loginPage.doLogin("OBSInternalUser");
	String main_window = driver.getWindowHandle();
	InvoicesPage invoicesPage=homePage.click_Invoices_Tab();
	log.info("clicked on invoices tab");
	invoicesPage.click_ok();
	log.info("clicked on ok button");
	invoicesPage.validate_OBP_Internal_user_invoices_screen();
	log.info("validated invoices screen");
	invoicesPage.click_closeWindowButton();
	log.info("clicked on close window button on invoices screen");
	driver.switchTo().window(main_window);
	log.info("switched to main window");
	Thread.sleep(4000);
	homePage.Click_LogOutLnk();	
	Thread.sleep(6000);
	}
	
	
	
	
	@Test
	public void TC06_OBP_ExternalUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<invoicesPage
	       High Level Summary:- Validate invoices for OBP Extuser
	         */
	log.info(" *** Execution Started");
	RemoteWebDriver driver = getWebDriver();

	log.info("Step1: Login to EES Site");
	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage = loginPage.doLogin("OBPExternalUser");
	String main_window = driver.getWindowHandle();
	InvoicesPage invoicesPage=homePage.click_Invoices_Tab();
	log.info("clicked on invoices tab");
	invoicesPage.validate_OBP_External_user_invoices_screen();
	log.info("validated invoices screen");
	invoicesPage.click_closeWindowButton();
	log.info("clicked on close window button on invoices screen");
	driver.switchTo().window(main_window);
	log.info("switched to main window");
	Thread.sleep(4000);
	homePage.Click_LogOutLnk();	
	Thread.sleep(6000);
	}
	
	
	
	@Test
	public void TC07_OBP_InternalUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<invoicesPage
	       High Level Summary:- Validate invoices for OBP Intuser
	         */
	log.info(" *** Execution Started");
	RemoteWebDriver driver = getWebDriver();

	log.info("Step1: Login to EES Site");
	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage = loginPage.doLogin("OBPInternalUser");
	fnWaitForPageLoad(driver);
	InvoicesPage invoicesPage=homePage.click_Invoices_Tab();
	log.info("clicked on invoices tab");
	(new WebDriverWait(driver, 3)).until(ExpectedConditions.numberOfWindowsToBe(2));
	ArrayList<String> tab2= new ArrayList<String>(driver.getWindowHandles());	
	driver.switchTo().window(tab2.get(tab2.size()-1));
		 invoicesPage.validate_OBP_Internal_user_invoices_screen();
		 log.info("validated invoices screen");
		 invoicesPage.click_closeWindowButton();
		 log.info("clicked on close window button on invoices screen");
		 driver.switchTo().window(tab2.get(0));
		 log.info("switched to main window");
	homePage.Click_LogOutLnk();
	Thread.sleep(6000);
	}

	@Test(groups = { "Regression08" })
	public void TC08_OBPP_ExternalUser() throws Exception {

		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<invoicesPage
	       High Level Summary:- Validate invoices for OBPP Extuser
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("OBPPExternalUser");

		log.info("Step2: Click on Invoices Tab on the Home Page");
		InvoicesPage invoicesPage =homePage.click_Invoices_Tab();
		log.info("clicked on invoices tab");

		invoicesPage.Verify_InvoicesPage_OBPP();
		log.info("validated invoices screen");
		Thread.sleep(1000);


	}
	
	
	@Test(groups = { "Regression08" })
	public void TC09_OBPP_InternalUser() throws Exception {
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<invoicesPage
	       High Level Summary:- Validate invoices for OBPP Intuser
	         */
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("OBPPInternalUser");

		log.info("Step2: Click on Invoices Tab on the Home Page");
		InvoicesPage invoicesPage =homePage.click_Invoices_Tab();
		(new WebDriverWait(driver, 3)).until(ExpectedConditions.numberOfWindowsToBe(2));
		ArrayList<String> tab2= new ArrayList<String>(driver.getWindowHandles());	
		driver.switchTo().window(tab2.get(tab2.size()-1));
		log.info("clicked on invoices tab");
			 invoicesPage.validate_OBP_Internal_user_invoices_screen();
			 log.info("validated invoices screen");
			 invoicesPage.click_closeWindowButton();
			 log.info("clicked on close window button on invoices screen");
			 driver.switchTo().window(tab2.get(0));
			 log.info("switched to main window");
		homePage.Click_LogOutLnk();
		Thread.sleep(6000);
		

	}


	@Test(groups = { "Regression16" })
	public void TC16_EmpDep_IDCards_CDB() throws Exception {

		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<inquirePage
	       High Level Summary:- Validate EmpDep_IDCards_CDB successful message 
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CDBPCPPolicy.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("TC16_EmpDep_IDCards_CDB.altid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		log.info("Step5: Click on ID Card Link on the Inquire Page");
		inquirePage.click_IDCard_Link();


		log.info("Step6: Click on Request ID card button on IDcardPage");
		idCardPage.clickOnRequestIDCard();

		log.info("Step7: Verify IDCard Successful message for Employee on IDcardPage");
		idCardPage.Verify_IDCard_SucsfulMsg();

		log.info("Step8: Click on Dependent Radio Button on IDcardPage");
		idCardPage.click_Dep1_RadioButn();

		log.info("Step9: Click on Request ID card button on IDcardPage");
		idCardPage.clickOnRequestIDCard();

		log.info("Step10: Verify IDCard Successful message for Dependent IDcardPage");
		idCardPage.Verify_IDCard_SucsfulMsg();

	}
	
	@Test
	public void TC15_EmpDep_IDCards_COSMOS() throws Exception
	{
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<inquirePage
	       High Level Summary:- Validate EmpDep_IDCards_COSMOS successful message 
	         */
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc15.CosmosInquiry.policynum"));

		log.info("Step3: Search for Employee using the lastname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("TC15.CosmosInquiry.lastname"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		log.info("Step5: Click on ID Card Link on the Inquire Page");
		inquirePage.click_IDCard_Link();


		log.info("Step6: Click on Request ID card button on IDcardPage");
		idCardPage.clickOnRequestIDCard();

		log.info("Step7: Verify IDCard Successful message for Employee on IDcardPage");
		idCardPage.Verify_IDCard_SucsfulMsg();

		log.info("Step8: Click on Dependent Radio Button on IDcardPage");
		idCardPage.click_Dep1_RadioButn();

		log.info("Step9: Click on Request ID card button on IDcardPage");
		idCardPage.clickOnRequestIDCard();

		log.info("Step10: Verify IDCard Successful message for Dependent IDcardPage");
		idCardPage.Verify_IDCard_SucsfulMsg();

		
	}


	@Test(groups = { "Regression14" })
	public void TC14_EmpDep_IDCards_PRIME() throws Exception {

		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<inquirePage
	       High Level Summary:- Validate EmpDep_IDCards_PRIME successful message 
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("PrimeL&DPolicy.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("TC14_EmpDep_IDCards_PRIME.altid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		log.info("Step5: Click on ID Card Link on the Inquire Page");
		inquirePage.click_IDCard_Link();


		log.info("Step6: Click on Request ID card button on IDcardPage");
		idCardPage.clickOnRequestIDCard();

		log.info("Step7: Verify IDCard Successful message for Employee on IDcardPage");
		idCardPage.Verify_IDCard_SucsfulMsg();

		log.info("Step8: Click on Dependent Radio Button on IDcardPage");
		idCardPage.click_Dep1_RadioButn();

		log.info("Step9: Click on Request ID card button on IDcardPage");
		idCardPage.clickOnRequestIDCard();

		log.info("Step10: Verify IDCard Successful message for Dependent IDcardPage");
		idCardPage.Verify_IDCard_SucsfulMsg();

	}
	@Test
	public void TC12_ViewClaim_Summary_Details_Cosmos() throws Exception
	{
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<InquirePage<
	       High Level Summary:- Validate Claim summary details for COSMOS
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");
		
		
		
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc12.CosmosInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc12.CosmosInquiry.empid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		//TODO : need to work once we get the correct test data
		
	}
	
	@Test
	public void TC11_ViewDownload_HistoricalBankingReports_ExternalUser() throws Exception
	{
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_HistoricalBankingReports_ExternalUser
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		/*IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);*/
		HomePage homePage = loginPage.doLogin("ExternalBanking");
		//homePage.verify_homePage();
		homePage.clickReports();
		log.info("reports link is clicked");
		//homePage.click_banking();
		ReportsPage reportspage=new ReportsPage(driver);
		Thread.sleep(5000);
		///reportspage.verify_reportsPage();
		log.info("verified reports");
		reportspage.select_historicalBankingReport("Charged Claim Activity", "12/10/2014");
		log.info("reports is selected");
		
		
		
		
	}
	
	@Test
	public void TC10_ViewDownload_BankingReports_ExternalUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		/*IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);*/
		HomePage homePage = loginPage.doLogin("ExternalBanking");
		//homePage.verify_homePage();
		//homePage.Reports_banking();
		homePage.clickReports();
		log.info("reports link is clicked");
		//homePage.click_banking();
		ReportsPage reportspage=new ReportsPage(driver);
		Thread.sleep(6000);
		//reportspage.verify_reportsPage();
		reportspage.click_chrgedclaimActivity_lnk();
		log.info("clicked on chrgedclaimActivity_lnk");
	}
	@Test
	public void TC13_Claim_DownloadEOB() throws Exception
	{
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<InquirePage<
	       High Level Summary:- Validate Claim download EOB for CDB
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");
		
		
		
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc12.CosmosInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc12.CosmosInquiry.empid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		//TODO : need to work once we get the correct test data
	}

	@Test
	public void TC17_Prime_InquireFunctionality() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<inquirepage
	       High Level Summary:- Validate employee and dependent are navigated to inquire page
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("PrimyInquiry");
		
		
		
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc17.PrimyInquiry.policynum"));
		Thread.sleep(4000);

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc17.PrimyInquiry.altid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		
		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		homePage.Validate_Inquire_DepSection();
		log.info("validate dependent inquire section");
		
		
		log.info("Step5: Click on LogOut Link on the homePage");
		homePage.Click_LogOutLnk();
		
		
	}
	
	@Test
	public void TC18_COSMOS_Inquire_Functionality() throws Exception
	{
		/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<Inquirepage
	       High Level Summary:- Validate employee and dependent are navigated to inquire page
	         */
		
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");
		
		
		
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("TC18.CosmosInquiry.policynum"));

		log.info("Step3: Search for Employee using the lastname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("TC18.CosmosInquiry.lastname"));

		log.info("Step4: Click on EmpInquire Link on the homePage");
		homePage.Click_InquireEmployee_link();
		
		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		homePage.Validate_Inquire_DepSection();
		log.info("validate dependent inquire section");
		
		
		log.info("Step5: Click on LogOut Link on the homePage");
		homePage.Click_LogOutLnk();
		
		
		
	}
	@Test
	public void TC19_CDB_Inquire_Functionality() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage<inquirepage
	       High Level Summary:- Validate employee and dependent are navigated to inquire page
	         */
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		IDCardPage idCardPage = new IDCardPage(driver);
		InquirePage inquirePage = new InquirePage(driver);
		HomePage homePage = loginPage.doLogin("CdbInquiry");
		
		
		
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc19.CDBInquiry.altid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		
		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		homePage.Validate_Inquire_DepSection();
		log.info("validate dependent inquire section");
		
		log.info("Step5: Click on LogOut Link on the homePage");
		homePage.Click_LogOutLnk();
	}

	@Test
	public void TC_29_Reg_CreateNew_ExternalUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t29");
		homePage.verify_homePage();
		//homePage.Reports_banking();
		homePage.clickReports();
		log.info("reports link is clicked");
		//homePage.click_banking();
		ReportsPage reportspage=new ReportsPage(driver);
		Thread.sleep(6000);
		//reportspage.verify_reportsPage();
		reportspage.click_chrgedclaimActivity_lnk();
		log.info("clicked on chrgedclaimActivity_lnk");
	}
	@Test
	public void TC30_Reg_DB_AddInternalUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t31");
		homePage.verify_homePage();
		homePage.click_manage_accesss();
		log.info("clicked on manage access");
		ManageAccessPage mapage=new ManageAccessPage(driver);
		mapage.create_internaluserGroup();
		mapage.click_DoMoreLnk();
		log.info("clicked on do more link");
		mapage.click_adduserLnk();
		log.info("clicked on add user link");
		mapage.click_addNewInternalLnk();
		mapage.create_internal_user_profile();
		log.info("created internal user");
	}
	@Test
	public void TC20_Add_Flow_M_S_D_V_PCP() throws Exception
	{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members with pcp
		 * 
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_pcp();
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.Validate_enrollment_complete();
		
	}
	
	@Test
	public void TC21_AddFlow_Empand_Dep_COSMOS_M_D_V() throws Exception
	{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of cosmos members with pcp
		 * 
		 */

		log.info(" *** TC_06_AddFlow_EmpandDep_COSMOS with Medical Only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.pcppolicynum"));
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_pcpcosmos();
		addempdemographicPage.dependent_demographics_details_cosmos();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_pcpcosmos();
		assignplans.plans_Dependent_pcpcosmos();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();

		
	}
	@Test()
	public void TC24_Submit_Enrollment_Form_Add_Updated() throws Exception
	{
		/**
		 * 
		 * @author eshravan
		 *Creation Date: 06/12/2017
		 *Screen Navigated: LoginPage-->>HomePage-->>MemberEnrollmentPage
		 *High Level Summary:- Submitting member enrollment  ADD form for subscriber and one dependent 

		 */
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("PHS");

		log.info("Step2: Click on MemberEnrollment Link");
		homePage.Click_MemberEnrollment_link();
		PHSPage phspage=new PHSPage(driver);

		log.info("Step3: Adding subscriber");
		phspage.addSubscriberOneDep("PlanCode$123");
		//phspage.addSubscriber("PlanCode$123");

		log.info("Step4: Click on send request button");
		phspage.click_SendRequest_Button();

		log.info("Step5: Verifying confirmation message");
		phspage.Verifying_ConfrimationPage();

	}
	@Test
	public void TC25_Prime_Add_Flow_M_D_V_with_PCP() throws Exception
	{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members with pcp
		 * 
		 */

		/*log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_prime();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_prime();
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.Validate_enrollment_complete();
		Enroll_Employee_prime_withoutDpdnt("");*/
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		Enroll_Employee_prime_withoutDpdnt("04x2933");

		
		
	}
	@Test(groups={"gecko_Demo"})
	public void TC23_Reg_CreateNew_EmployerClient() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t23");
		homePage.verify_homePage();
		homePage.click_manage_accesss();
		ManageAccessPage mapage=new ManageAccessPage(driver);
		
		mapage.clientSearchByPolicy("MSP32575");
		mapage.click_addNewClientLnk();
		mapage.create_client_profile("MSP32575");
		Thread.sleep(6000);
		
	}
	@Test
	
	public void TC22_ExternalUser_having_only_onePrimePolicy_adminKit() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t22");
		homePage.verify_homePage();
	//	homePage.selectgroup();
		homePage.click_benefitsAdminKit();
		homePage.groupSearch("0231110");
		homePage.validate_benefitAdminKits();
		
		
		
	}/*() throws Exception
	{
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t23");
		homePage.verify_homePage();
		homePage.click_manage_accesss();
		ManageAccessPage mapage=new ManageAccessPage(driver);
		
		mapage.clientSearchByPolicy("MSP32575");
		mapage.click_addNewClientLnk();
		mapage.create_client_profile("MSP32575");
		Thread.sleep(6000);
		
	}*/
	@Test
	public void TC27_SBC_Functionality_Prime() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-LoginPage<homePage
	       High Level Summary:- Validate ViewDownload_BankingReports_ExternalUser
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t27");
		homePage.validate_homepage();
		homePage.click_summryAndBenftCoverageLnk();
		homePage.click_pdf();
		homePage.Click_LogOutLnk();
		
		
	}
	@Test
	public void TC31_Reg_DB_CreateSuperuserUser() throws Exception
	{/*
	       Created By:- Suresh Itha
	       Modified Date:- 06/12/2017
	       Screen Navigated:-manageaccess<superusergroup<superuser users
	       High Level Summary:- creation of super user 
	         */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
		

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		
		HomePage homePage = loginPage.doLogin("t31");
		homePage.verify_homePage();
		homePage.click_manage_accesss();
		log.info("clicked on manage access");
		ManageAccessPage mapage=new ManageAccessPage(driver);
		mapage.create_superuserGroup();
		log.info("created super group");
		mapage.click_DoMoreLnk();
		log.info("clicked on do more link");
		mapage.click_adduserLnk();
		log.info("clicked on add user link");
		mapage.click_addNewSuperUseruserLnk();
		mapage.create_superuser_user_profile();
		log.info("created super user");
}
	
	}