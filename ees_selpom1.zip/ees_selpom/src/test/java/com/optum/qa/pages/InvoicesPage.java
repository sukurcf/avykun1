package com.optum.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.optum.qa.eesFunctionalApp.EesAppBase;

/**
 * 
 * @author eshravan
 *This represents the Invoices Page of the EES application which will comes after Clicking on Invoices link
 */

public class InvoicesPage extends EesAppBase {

		private WebDriver driver;


		@FindBy(xpath=".//*[contains(text(),'Close Window')]")
		private WebElement CloseWindowButton ;
		
		@FindBy(id="tab-link-invoices")
		private WebElement InvoicesTab ;
		
		@FindBy(id="invoicesIframe")
		private WebElement InvoicesFrame ;
			
		@FindBy(linkText="Invoices")
		private WebElement InvoicesTabInResults ;
		
		@FindBy(className="navigationScreenDisplay")
		private WebElement OpenInvoiceLstngText ;
		
		@FindBy(xpath=".//*[@id='openInvoiceListForm:headerColumn1Area']//span[text()='Account Summary']")
		private WebElement AccountSummaryText ;
		@FindBy(xpath="//*[@value='Ok']")
		private WebElement okButton;
		
		@FindBy(xpath=".//*[@value='Reset']")
		private WebElement ResetButton;
		
		@FindBy(xpath=".//*[@id='tab-link-invoices']")
		private WebElement OBPInvoicesLnk;
		
		@FindBy(xpath=".//*[contains(text(),'Invoice Listing')]")
		private WebElement OBSInvoiceListingLnk;
				
		public InvoicesPage(WebDriver driver){
			this.driver = driver;
			PageFactory.initElements(this.driver, this);

		}
		
		public void click_ok()
		{
			driver.switchTo().frame("invoicesIframe");
			okButton.click();
			fnWaitForPageLoad(driver);
			driver.switchTo().defaultContent();
		}

	
		public void Verify_InvoicesPage_OBPP()throws Exception{
			fnVerifyElementDisplayed(CloseWindowButton);
			fnVerifyElementDisplayed(InvoicesTab);
			log.info("i validated ");
			Thread.sleep(2000);
			driver.switchTo().frame(0);
			fnVerifyElementDisplayed(OpenInvoiceLstngText);
			fnVerifyElementDisplayed(InvoicesTabInResults);
			
			
		}
		
		public void validate_OBP_Internal_user_invoices_screen()
		{
			driver.switchTo().frame(InvoicesFrame);
			fnVerifyElementDisplayed(ResetButton);
			
		}
		
		public void validate_OBP_External_user_invoices_screen() throws Exception 
		{
			
			fnVerifyElementDisplayed(OBPInvoicesLnk);
	
		}
		
		public void validate_OBS_External_user_invoice_screen() throws Exception 
		{
			driver.switchTo().frame(InvoicesFrame);
			fnVerifyElementDisplayed(OBSInvoiceListingLnk);
		}
		
		public void click_closeWindowButton() {
			driver.switchTo().defaultContent();
			fnWaitForElementToBeClickable(CloseWindowButton, driver);
			CloseWindowButton.click();
			
			
		}
		
		
	

	
		
	}

	


