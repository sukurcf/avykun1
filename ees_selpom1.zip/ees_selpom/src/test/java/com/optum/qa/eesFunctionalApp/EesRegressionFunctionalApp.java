package com.optum.qa.eesFunctionalApp;

//import java.time.LocalDateTime;
//import java.time.LocalDateTime;
/*import java.time.LocalDate;
import java.time.LocalDateTime;*/

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.optum.qa.pages.AddEmpDemographicsPage;
import com.optum.qa.pages.AssignPlansPage;
import com.optum.qa.pages.HomePage;
import com.optum.qa.pages.LoginPage;
import com.optum.qa.pages.ManageEmployeesPage;
import com.optum.qa.pages.MyProfilePage;
import com.optum.qa.pages.ReviewAndSubmitPage;

public class EesRegressionFunctionalApp extends EesWorkFlows {
	public Logger log = LoggerFactory.getLogger(this.getClass());

	@Test(groups = { "Regression10" })
	public void tc17_Prime_Inquiry_Functionality() throws Exception {

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("PrimyInquiry");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc17.PrimyInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc17.PrimyInquiry.altid"));

	}

	@Test(groups = "Divyani")
	public void TC_ID_504_TC01_Myprofile_Page_ValidationTest() throws Exception {

		/*
		 * Created By:- Divyani Pandey Modified Date:-06/19/2017 Screen
		 * Navigated:-Login<HomePage<MyProfilePage High Level Summary:- My
		 * Profile page validation
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");

		log.info("Click on MyProfile link");
		homePage.Click_MyProfileLnk();
		MyProfilePage myprofilepage = new MyProfilePage(driver);
		log.info("my profile page is validated");
		myprofilepage.Validate_MyProfile_Page();
		log.info("my profile details are filled");
		myprofilepage.MyProfileDetails();

	}

	@Test(groups = "Divyani")
	public void TC_ID_505_TC02_Myprofile_SecuritySection() throws Exception {

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("CosmosInquiry");
		log.info("Click on MyProfile link");
		homePage.Click_MyProfileLnk();
		MyProfilePage myprofilepage = new MyProfilePage(driver);
		myprofilepage.UpdateSecurityQuestions();

	}

	@Test(groups = "Divyani")
	public void TC_ID_507_TC04_Myprofile_Password() throws Exception {

		/*
		 * Created By:- Divyani Pandey Modified Date:-06/19/2017 Screen
		 * Navigated:-Login<HomePage<MyProfilePage High Level Summary:- Change
		 * Password
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("MyProfile");
		log.info("Click on MyProfile link");
		homePage.Click_MyProfileLnk();
		MyProfilePage myprofilepage = new MyProfilePage(driver);
		myprofilepage.ChangePassword();

	}

	@Test(groups = "suresh")
	public void prime_enrollment() throws Exception {

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		Enroll_Employee_prime_withoutDpdnt("04x2933");

		// 04x2933 //04Y1312//0231110

	}

	@Test(groups = "suresh")
	public void cosmos_enrollment() throws Exception {

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		Enroll_Employee_cosmos_withoutDpdnt("MSP80494");

	}

	@Test(groups = "suresh")
	public void CDB_enrollment() throws Exception {

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		Enroll_Employee_CDB_withoutDpdnt("1800727");

	}

	@Test(groups = "suresh")
	public void CDB_enrollment_dependent() throws Exception {

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		Enroll_Employee_CDB_with_Dependent("1800727");

	}

	@Test(groups = "Suresh")
	public void cdb_medica_enrollment() throws Exception {
		/*
		 * Created By:- Divyani Pandey Modified Date:-06/19/2017 Screen
		 * Navigated:-LoginPage<HomePage<AddEmpDemographicsPage<AssignPlansPage<
		 * Review&SubmitPage High Level Summary:- Change Password
		 */

		String SSN = null;
		log.info("*** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		Enroll_Employee_CDB_MEDICA_withoutDpdnt("0712926", SSN);
	}

	@Test
	public void TC_ID_506_TC03_Myprofile_DefaultGroup() throws Exception {
		/*
		 * Created By:- Aswani Atluri Modified Date:-06/13/2017 Screen
		 * Navigated:-Login<HomePage<MyProfilePage High Level Summary:-
		 * Validating DefaultGroup tab
		 */
		log.info(" *** TC03_Myprofile_DefaultGroup Test script Execution Started");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("MyprofileDefault");
		log.info("Click MyProfile link on the Home Page");
		homePage.Click_MyProfileLnk();
		MyProfilePage myprofilePage = new MyProfilePage(driver);
		myprofilePage.validateText_DefaultGroupTab();
		myprofilePage.validateTab_DefaultGroup();
		myprofilePage.validate_DisableListBox();

	}

	@Test
	public void TC_ID_508_TC05_Myprofile_SetDefaultGroup() throws Exception {
		/*
		 * Created By:- Aswani Atluri Modified Date:-06/13/2017 Screen
		 * Navigated:-Login<HomePage<MyProfilePage High Level Summary:-
		 * Validating DefaultGroup Drop down
		 */
		log.info(" *** TC05_Myprofile_SetDefaultGroup Test script Execution Started");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("MyprofileMultiple");
		log.info("Click MyProfile link on the Home Page");
		homePage.Click_MyProfileLnk();
		MyProfilePage myprofilePage = new MyProfilePage(driver);
		myprofilePage.validateText_DefaultGroupTab();
		myprofilePage.validateTab_DefaultGroup();
		log.info("Validated Default Group Tab");
		myprofilePage.validate_EnableListBox();
		myprofilePage.validateDropdown_SelectedText();

	}
	@Test
	public void TC_ID_2098_TC18_COSMOS_InquireFunctionality() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-06/18/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login 
	       and verify the employee name links in manage employee tab
	 */
		log.info(" *** TC18_COSMOS_Inquire Functionality Test script Execution Started");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.lastname"));
		log.info("Validate employee search results");
		homePage.validate_employeeSearchResults();
		homePage.validate_dashboardTab();


	}
	@Test
	public void TC_ID_401_TC_13_AddFlow_EmpandDep_COSMOS_MedicalOnly() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-06/21/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and Add new employee 
	       and dependent enrollment with Medical only coverage
	       
	    */
		
		log.info(" *** TC_13_AddFlow_EmpandDep_COSMOS with Medical Only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_cosmos();
		addempdemographicPage.dependent_demographics_details_cosmos();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_cosmos();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();

	}
	
	@Test
	public void TC_ID_403_TC_15_ChangeFlow_COSMOS_MedicalOnly() throws Exception
	{
		/*	      
		   Created By:- Aswani Atluri
	       Modified Date:-06/21/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and edit demographics for  employee 
	       and dependent with Medical only coverage 	      

       */
		
		log.info(" *** TC_15_ChangeFlow_COSMOS with Medical only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.lastname"));
		homePage.validate_employeeanddependentSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_editEmployeeandDependent_Cosmos();
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();
		
		
				
	}
	
	@Test
	public void TC_ID_396_TC_16_Terminate_COSMOS_MedicalOnly() throws Exception
	
	{
		/*	      
		   Created By:- Aswani Atluri
	       Modified Date:-06/27/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and Terminate Employee 
	       with  Medical only coverage in Manage employees tab 	      

 */
		//int addDate = 3;
		
		log.info(" *** TC_15_ChangeFlow_COSMOS with Medical only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.Terminatepolicylastname"));
		homePage.validate_employeeSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_TerminateEmployee_Cosmos();
		manageEmpPage.validate_TerminatecoverageDate();
		manageEmpPage.validate_printRecordButton();
		

	}
	
	@Test
	public void TC_ID_405_TC_17_Reinstate_COSMOS_MedicalOnly() throws Exception
	{
		/*	      
		   Created By:- Aswani Atluri
	       Modified Date:-06/30/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and resinstate Employee 
	       with  Medical only coverage in Manage employees tab 	      

    */
		log.info(" *** TC_15_ChangeFlow_COSMOS with Medical only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.Terminatepolicylastname"));
		homePage.validate_employeeSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_ReinstateEmployee();
		manageEmpPage.validate_printRecordButton();


	}
	
	@Test
	public void TC_ID_400_TC_11_Add_Dependent_Cosmos() throws Exception{
		/*	      
		   Created By:- Aswani Atluri
	       Modified Date:-07/06/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Fillout and Submit all demographic information and assign plans for an employee and then 
	       add Dependent with Plans and demographic information.
	       and Validate search results in Manage Employee tab.

       */
		
		log.info(" *** TC_11_Add_Dependent");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_cosmos();
		addempdemographicPage.AddEmoployee_NextButton_cosmos();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_cosmos();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		addempdemographicPage.Add_Newdependent_demographics_details_cosmos();
		reviewpage.click_submit();
		
		//manageEmpPage.Validate_enrollment_complete();
	}

	@Test
	public void TC_ID_399_TC_12_Search_Cosmos() throws Exception
	{
		/*	      
		   Created By:- Aswani Atluri
	       Modified Date:-07/07/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy EMPLOYEE ID and SSN in Dashboard after login to Home page 
	       and Validate search results in Manage Employee tab.

       */
		
		log.info(" *** TC_12_Search");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the EMPLOYEE ID");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.EmployeeID"));
		homePage.validate_employeeSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_ManageEmployeeTab_Cosmos();
		homePage.validate_dashboardTab();
		log.info("Search for Employee using the SSN");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.SSN"));
		Thread.sleep(5000);
		homePage.validate_employeeSearchResults();
		manageEmpPage.validate_ManageEmployeeTab_Cosmos();
		
						
	}
	
	@Test	
	public void TC_ID_402_TC_14_AddFlow_Dep_COSMOS_Medicalonly() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/03/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and Add new employee 
	       and more than one dependent enrollment with Medical only coverage
	       
	    */
		
		log.info(" *** TC_14_AddFlow_Dep_COSMOS with Medical only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.policynum"));
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_cosmos();
		//addempdemographicPage.dependent_demographics_details_cosmos();
		addempdemographicPage.Addmoredependents_demographics_details_cosmos();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_cosmos();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();

	}
	
	@Test
	public void TC_ID_388_TC_06_AddFlow_EmpandDep_Medica_WithPCP_COSMOS() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/10/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and Add new employee 
	       and dependent enrollment Medica with PCP coverage
	       
	    */
		
		log.info(" *** TC_06_AddFlow_EmpandDep_COSMOS with Medical Only");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.pcppolicynum"));
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_pcpcosmos();
		addempdemographicPage.dependent_demographics_details_cosmos();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_pcpcosmos();
		assignplans.plans_Dependent_pcpcosmos();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();

	}
	public void TC_ID_393_TC_01_AddFlow_Empand_Dep_MDV_COSMOS() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/11/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and Add new employee 
	       and dependent enrollment Medical, Dental and Vision coverages
	       
	    */
		
		log.info(" *** TC_ID_393_TC_01_AddFlow_Empand_Dep_MDV_COSMOS");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.Allcoveragepolicynum"));
		Thread.sleep(2000);
		fnWaitForPageLoad(driver);
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_cosmos_with_Dependent();
		log.info("completed demographics details");
		addempdemographicPage.AddEmoployee_NextButton_cosmos();
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_cosmos_medicare_YES();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();
	}
	
	public void TC_ID_394_TC_02_AddFlow_Dep_MDV_COSMOS() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/11/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login and Add new employee 
	       dependent with enrollment Medical, Dental and Vision coverages 
	       and add new dependent to the same employee.
	       
	    */
		
		log.info(" *** TC_ID_394_TC_02_AddFlow_Dep_MDV_COSMOS");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.Allcoveragepolicynum"));
		Thread.sleep(2000);
		fnWaitForPageLoad(driver);
		homePage.click_addNewEmp();
		Thread.sleep(8000);
		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_cosmos_with_add_another_Dependent();
		log.info("completed demographics details");
		addempdemographicPage.AddEmoployee_NextButton_cosmos();
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_cosmos_medicare_YES();
		log.info("completed Assign plans details");
		
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();
	}
	
	public void TC_ID_395_TC_03_ChangeFlow_MDV_COSMOS() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/10/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login, search with employee last name and 
	       verify the search results, and Edit employee and dependent demographics.
	       
	    */
		
		log.info(" *** TC_ID_395_TC_03_ChangeFlow_MDV_COSMOS");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.Allcoveragepolicynum"));
		Thread.sleep(2000);
		fnWaitForPageLoad(driver);
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.Allcoveragepolicylastname"));
		homePage.validate_AllCoverage_employeeanddependentSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_editEmployeeandDependent_Cosmos();
		
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		manageEmpPage.Validate_enrollment_complete();
	}
	
	public void TC_ID_396_TC_04_Terminate_MDV_COSMOS() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/12/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login, search with employee last name and 
	       verify the search results, and terminate employee and dependents.
	       
	    */
		
		log.info(" *** TC_ID_396_TC_04_Terminate_MDV_COSMOS");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.Allcoveragepolicynum"));
		Thread.sleep(2000);
		fnWaitForPageLoad(driver);
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.Terminatepolicylastname"));
		//homePage.validate_AllCoverage_employeeanddependentSearchResults();
		homePage.validate_employeeSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_TerminateEmployee_Cosmos();
		manageEmpPage.validate_TerminatecoverageDate();
		manageEmpPage.Validate_enrollment_complete();
		manageEmpPage.validate_printRecordButton();
}
	public void TC_ID_397_TC_05_Reinstate_COSMOS_MDV_COSMOS() throws Exception
	{
		/*
	       Created By:- Aswani Atluri
	       Modified Date:-07/12/2017
	       Screen Navigated:-Login<HomePage(Manage employees tab/Dashboard tab)
	       High Level Summary:- Search with Cosmos policy in Dashboard after login, search with employee last name and 
	       verify the search results, and Reinstate employee and dependents.
	       
	    */
		
		log.info(" *** TC_ID_397_TC_05_Reinstate_COSMOS_MDV_COSMOS");
		RemoteWebDriver driver = getWebDriver();
		LoginPage loginPage = new LoginPage(driver);
		log.info("Login to EES Site");
		HomePage homePage = loginPage.doLogin("CosmosMedical");
		log.info("Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CosmosInquiry.Allcoveragepolicynum"));
		Thread.sleep(2000);
		fnWaitForPageLoad(driver);
		homePage.validate_manageEmployeesTab();
		log.info("Search for Employee using the lname");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CosmosInquiry.Terminatepolicylastname"));
		//homePage.validate_AllCoverage_employeeanddependentSearchResults();
		homePage.validate_employeeSearchResults();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.validate_ReinstateEmployee();
		manageEmpPage.validate_printRecordButton();
}
}