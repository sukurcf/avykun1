package com.optum.qa.eesFunctionalApp;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mysql.jdbc.Driver;
import com.optum.qa.pages.HomePage;
import com.optum.qa.pages.LoginPage;
import com.optum.qa.pages.PHSPage;


/**
 * 
 * @author eshravan
 *Creation Date: 06/12/2017
 *Screen Navigated: LoginPage-->>HomePage-->>MemberEnrollmentPage
 *High Level Summary:- Here we are verifying the functionalities of Add, terminate and Request change flows

 */
public class EesPHSScripts extends EesAppBase{
	public Logger log = LoggerFactory.getLogger(this.getClass());


	/**
	 * 
	 * @author eshravan
	 *Creation Date: 06/12/2017
	 *Screen Navigated: LoginPage-->>HomePage-->>MemberEnrollmentPage
	 *High Level Summary:- Submitting member enrollment  ADD form for subscriber and one dependent 

	 */

	@Test(groups={"Sauce_Demo"})
	public void TC01_Submit_Enrollment_Form_Add() throws Exception
	{
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("PHS");

		log.info("Step2: Click on MemberEnrollment Link");
		homePage.Click_MemberEnrollment_link();
		PHSPage phspage=new PHSPage(driver);

		log.info("Step3: Adding subscriber");
		phspage.addSubscriberOneDep("PlanCode$123");
		//phspage.addSubscriber("PlanCode$123");

		log.info("Step4: Click on send request button");
		phspage.click_SendRequest_Button();

		log.info("Step5: Verifying confirmation message");
		phspage.Verifying_ConfrimationPage();

	}


	/**
	 * 
	 * @author eshravan
	 * @throws Exception
	 *Creation Date: 06/12/2017
	 *Screen Navigated: LoginPage-->>HomePage-->>MemberEnrollmentPage
	 *High Level Summary:- Submitting member enrollment CHANGE form

	 */
	@Test(groups={"Sauce_Demo"})
	public void TC02_Submit_Enrollment_Form_Change() throws Exception
	{
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("PHS");

		log.info("Step2: Click on MemberEnrollment Link");
		homePage.Click_MemberEnrollment_link();
		PHSPage phspage=new PHSPage(driver);

		log.info("Step3: Changing subscriber");
		phspage.requestChange();

		log.info("Step4: Verifying confirmation message");
		phspage.Verifying_ConfrimationPage();
	}
	/**
	 * @author eshravan
	 * @throws Exception
	 * *Creation Date: 06/12/2017
	 *Screen Navigated: LoginPage-->>HomePage-->>MemberEnrollmentPage
	 *High Level Summary:- Submitting member enrollment TERMINATE form
	 */

	@Test(groups={"Sauce_Demo"})
	public void TC03_Submit_Enrollment_Form_Terminate() throws Exception
	{
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("PHS");

		log.info("Step2: Click on MemberEnrollment Link");
		homePage.Click_MemberEnrollment_link();
		PHSPage phspage=new PHSPage(driver);

		log.info("Step3: Terminate subscriber");
		phspage.terminateMember();

		log.info("Step4: Verifying confirmation message");
		phspage.Verifying_ConfrimationPage();
	}
	/**
	 * @author eshravan
	 * @throws Exception
	 * *Creation Date: 06/12/2017
	 *Screen Navigated: LoginPage-->>HomePage-->>MemberEnrollmentPage
	 *High Level Summary:- Validating plan code functionality text box with different inputs
	 */

	@Test(groups={"Sauce_Demo_1"})
	public void TC04_Member_Enrollment_Add_Transaction_Validations() throws Exception
	{
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("PHS");

		log.info("Step2: Click on MemberEnrollment Link");
		homePage.Click_MemberEnrollment_link();
		PHSPage phspage=new PHSPage(driver);

		log.info("Step3: Entering all required fields and leaving Product selection/Plan Code as blank");
		phspage.addSubscriber("");

		log.info("Step4: Verifying Error message and click on start overflow");
		phspage.Verify_ErrorMessage();

		log.info("Step5: Enter all the required information along with Product Code as numeric and click send request button");
		phspage.addSubscriberEndToEnd("23474848");

		log.info("Step6: Enter all the required information along with Product Code as alphabet and click on send request button");
		phspage.addSubscriberEndToEnd("dajfljld");

		log.info("Step7: Enter all the required information along with Product Code as alphanumeric and click on send request button");
		phspage.addSubscriberEndToEnd("dja892dka");

		log.info("Step8: Enter all the required information along with Product Code as more than 50 char and click on send request button");
		phspage.addSubscriberEndToEnd("AbcdkgndoeverythingAgirlcandoeverything!@#$1234567");

		log.info("Step9: Enter all the required information along with Product Code with leading spaces and click on send request button");
		phspage.addSubscriberEndToEnd("    @planCodee9239");				

	}

}
