package com.optum.qa.eesFunctionalApp;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optum.qa.pages.AddEmpDemographicsPage;
import com.optum.qa.pages.AssignPlansPage;
import com.optum.qa.pages.HomePage;
import com.optum.qa.pages.LoginPage;
import com.optum.qa.pages.ManageEmployeesPage;
import com.optum.qa.pages.ReviewAndSubmitPage;

public class EesCdbEnrollment extends EesWorkFlows {
	public Logger log = LoggerFactory.getLogger(this.getClass());
	
	
	@Test
	public void tcid_2547_TC_022_ChangeOtherInsurance_TypeA_to_TypeB() throws Exception
	{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirypage<planspage
		 * High Level Summary:- change other insurances of dependent
		 * 
		 */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));
		//validating through alt id

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid_dep"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		AssignPlansPage asp=new AssignPlansPage(driver);
		asp.edit_plans_dependent_cdb_otherInsurance_yes_no();
	}
	
	@Test(groups="done")
	public void tcid_2711_TC_015_Employee_search_through_SSN_EmpID_AltID() throws Exception
	{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirypage
		 * High Level Summary:- search of emp through SSN ,empid,altid
		 * 
		 */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));
		//validating through alt id

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		//validating through emp id
		homePage.click_dashboard_tab();
		homePage.searchForEmployee(eesTestDataProperties.getProperty("Cdbempid"));
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		//validating through SSN
		homePage.click_dashboard_tab();
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbSSN"));
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();

		
	}
	
	
	
	
	
	@Test(groups="working")
	public void tcid_2718_TC_023_ChangeEmployee_Plans_Medicare_Update_YES_to_No() throws Exception
	{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members
		 * 
		 */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		AssignPlansPage app=new AssignPlansPage(driver);
		//TODO:need to validate msg in edit medicare coverage
		app.edit_medicare_coverage_YES_to_NO();
		
		
	}
	
	
	
	@Test(groups="working")
	public void tcid_2721_TC_024_Change_Employee_Plans_Medicare_Update_to_NO_to_Yes() throws Exception
	{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<editplans
		 * High Level Summary:- user able to edit medicare plans
		 * 
		 */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		AssignPlansPage app=new AssignPlansPage(driver);
		//TODO:need to validate msg in edit medicare coverage
		app.edit_medicare_coverage_NO_to_YES();
		
		
	}

	
	@Test(groups="done")
	public void tcid_2732_TC_025_Add_Enrollee_IRS() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members
		 * */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		Enroll_Employee_CDB_with_Dependent("1800727");

	}

	
	
	@Test(groups="done")
	public void tcid_2734_TC_026_CDB_Edit_Enrollee_Plan_IRS() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit plans of member
		 * */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc19.CDBInquiry.edit"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AssignPlansPage planspage= new AssignPlansPage(driver);
		planspage.edit_member_demo_cdb();
		planspage.edit_member_plans_cdb();


	}

	@Test(groups="done")//failing due data issue
	public void tcid_2737_TC_027_CDB_Edit_Dependent_Plan_IRS() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit plans of member
		 * */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AssignPlansPage planspage= new AssignPlansPage(driver);
		planspage.edit_plans_dependent_cdb();


	}

	@Test(groups="done")
	public void tcid_2736_TC_028_CDB_TermFlow_IRS() throws Exception
	{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit plans of member
		 * */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.terminate_emp("CORRECTION, NO CERTIFICATION SENT", "12122018");

	}
	@Test(groups="done")
	public void tcid_2738_TC_029_CDB_Reinstate_IRS() throws Exception
	{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<reinstate
		 * High Level Summary:- reinstate of emp
		 * */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validated employee inquire section");
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.reinstate_CDB("1800727","0001~0001~POS");


	}

	@Test(groups="done")
	public void tcid_2717_TC_017_Print_record() throws Exception
	{ /*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<print records
		 * High Level Summary:- print record
		 * */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.print_records("2717");
		//TODO:NEED VALIDATE PRINT
	}
	@Test(groups="done")
	public void tcid_2743_TC_031_CDB_Inquire_Functionality() throws Exception
	{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members
		 * 
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
	}

	@Test(groups="done")
	public void tcid_2707_TC_016_Employee_having_different_address_than_employee() throws Exception{
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<adddemographics
		 * High Level Summary:- enrollment of CDB members with different address for dependent and empo
		 * 
		 */
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB_with_Dependent();
		addempdemographicPage.add_Different_address_otherThanEmployee();

		AssignPlansPage asp=new AssignPlansPage(driver);
		asp.plans_CDB_dependent();
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.Validate_enrollment_complete();
	}


	@Test(groups="done")
	public void tcid_2696_TC_001_Add_flow_M_S_D_V_PCP() throws Exception{


		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members with pcp
		 * 
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_pcp();
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.Validate_enrollment_complete();

	}
	@Test(groups="done")
	public void tcid_2697_TC_002_Dep_Add_flow_M_S_D_V_PCP() throws Exception{
		
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of dependent with pcp
		 * 
		 */


		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));
        homePage.click_addNewEmp();

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB_with_Dependent();
		//demographics_details_CDB();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_dependent_pcp();
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.Validate_enrollment_complete();

	}
	/* @Test
	 public void tcid_2698_TC_003_EditPlans_Emp_PCP() throws Exception{


	 * Created By:- Suresh Itha 
	 * Modified Date:-XX-XX-2017
	 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
	 * High Level Summary:- enrollment of CDB members
	 * 


		    log.info(" *** Execution Started");
			RemoteWebDriver driver = getWebDriver();

			log.info("Step1: Login to EES Site");

			LoginPage loginPage = new LoginPage(driver);
			HomePage homePage = loginPage.doLogin("superuser");
			homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));
			log.info("Step3: Search for Employee using the altid");
			homePage.searchForEmployee(eesTestDataProperties.getProperty("tc19.CDBInquiry.lastname"));
           AssignPlansPage planspage= new AssignPlansPage(driver);
           planspage.edit_pcp_member_cdb();



			}*/
	@Test
	public void tcid_2702_TC_004_EditPlans_Dep_PCP() throws Exception{
		

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of dependent with pcp
		 * 
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_pcp();

	}
	@Test
	public void tcid_2706_TC_005_Term_flow_M_S_D_V_PCP() throws Exception{
		
		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirypage<terimante
		 * High Level Summary:- terimante employee who have pcp
		 * 
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));
		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbLastName"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.terminate_emp("CORRECTION, NO CERTIFICATION SENT", "07042017");
		Thread.sleep(8000);

	}
	@Test
	public void tcid_2730_TC_008_AddEmp_and_Dep_for_US_to_Canada() throws Exception{
		

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of dependent with canada address
		 * 
		 */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_pcp();

	}
	@Test
	public void tcid__TC__CDB_Inquire_Functionality() throws Exception
	{



		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
	}

	@Test
	public void tcid__TC_Inquire_Functionality() throws Exception
	{



		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();

		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
	}

	@Test
	public void tcid_2698_TC_003_EditPlans_Emp_PCP() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit plans of member
		 * */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbLastName"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AssignPlansPage planspage= new AssignPlansPage(driver);
		planspage.edit_member_demo_cdb();
		planspage.edit_member_plans_cdb();
		//planspage.edit_pcp_member_cdb();
		/*ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage mep=new ManageEmployeesPage(driver);
		mep.Validate_enrollment_complete();*/



	}
	

	@Test(groups="done")
	public void tcid_2703_TC_009_Edit_Demo_EMP_country_change_US_to_CANADA_M_S_D_V_PCP() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit plans of member
		 * */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("Cdbempid.tc2703"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AddEmpDemographicsPage demoPage=new AddEmpDemographicsPage(driver);
		demoPage.edit_member_demo_address_US_to_CANADA();
		



	}
	@Test
	public void tcid_2703_TC_010_Edit_Demo_DEP_country_change_US_to_CANADA_M_S_D_V_PCP() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit adress of dependent
		 * */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("Cdbempid.tc2703"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AddEmpDemographicsPage demoPage=new AddEmpDemographicsPage(driver);
		demoPage.edit_dep_demo_adress();



	}
	@Test(groups="done")
	public void tcid_2541_TC_019_Change_DEP_plans_with_OtherInsurance_No_To_YES() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit other plans of dependent
		 * */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("Cdbempid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AssignPlansPage planspage= new AssignPlansPage(driver);
		
		planspage.edit_plans_dependent_cdb_otherInsurance_yes_no();
		



	}


	/*@Test
 public void tcid_2737_TC_027_CDB_Edit_Dependent_Plan_IRS() throws Exception{


	 * Created By:- Suresh Itha 
	 * Modified Date:-XX-XX-2017
	 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
	 * High Level Summary:- enrollment of CDB members
	 * 


	log.info(" *** Execution Started");
	RemoteWebDriver driver = getWebDriver();

	log.info("Step1: Login to EES Site");

	LoginPage loginPage = new LoginPage(driver);
	HomePage homePage = loginPage.doLogin("superuser");

	log.info("Step2: Search for Policy on the Home Page");
	homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

	log.info("Step3: Search for Employee using the altid");
	homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));

	log.info("Step4: Click on EmpInquire LInk on the homePage");
	homePage.Click_InquireEmployee_link();
       AssignPlansPage planspage= new AssignPlansPage(driver);
       planspage.edit_pcp_member_cdb();



		}
	 */
	/* @Test
 public void tcid_2698_TC_003_EditPlans_Emp_PCP() throws Exception{


	 * Created By:- Suresh Itha 
	 * Modified Date:-XX-XX-2017
	 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
	 * High Level Summary:- enrollment of CDB members
	 * 


	    log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));
		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("tc19.CDBInquiry.lastname"));
       AssignPlansPage planspage= new AssignPlansPage(driver);
       planspage.edit_pcp_member_cdb();



		}*/
	/* @Test
 public void tcid_2702_TC_004_EditPlans_Dep_PCP() throws Exception{

	    log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB();
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_pcp();

		}*/
	
	@Test(groups="done")
	public void tcid_2548_TC_021_Change_DEP_OTHERINSURANCE_Yes_to_No() throws Exception{

		/*
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<inquirepage<edit plans
		 * High Level Summary:- edit other plans of dependent
		 * */

		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");

		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("tc19.CDBInquiry.policynum"));

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("Cdbempid"));

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		AssignPlansPage planspage= new AssignPlansPage(driver);
		
		planspage.edit_plans_dependent_cdb_otherInsurance_yes_no();
		



	}

	/*@Test(groups="done")
	public void tcid_2743_TC_31_CDB_Inquire_Functionality() throws Exception
	{
	
		
		 * Created By:- Suresh Itha 
		 * Modified Date:-XX-XX-2017
		 * Screen Navigated:-Login<HomePage<Addemploee<Assignplans<review and submit
		 * High Level Summary:- enrollment of CDB members
		 * 
		 
	
		log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();
	
		log.info("Step1: Login to EES Site");
	
		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin("superuser");
	
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(eesTestDataProperties.getProperty("CdbPolicy"));
	
		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(eesTestDataProperties.getProperty("CdbAltid"));
	
		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
	
		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
	}
*/

	
	
}
