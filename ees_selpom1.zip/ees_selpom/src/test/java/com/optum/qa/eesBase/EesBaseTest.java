package com.optum.qa.eesBase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.xls.report.main.ExcelReport;

/*************************************************************************
 * Abstract class providing helper utilities for Optum Market Test Cases
 *************************************************************************/
public abstract class EesBaseTest {
  public static String eESAppUrl; 
  protected static String profile;
  protected static int VeryshortTimeout =10;
  protected static int shortTimeout = 30; // in seconds
  protected static int longTimeout = 90; // in seconds
  protected static int timeOut=100;
  protected Logger log = LoggerFactory.getLogger(getClass());
  public static Properties eesProperties;
  public static Properties eesTestDataProperties;
  public static Properties TestDataProperties;

  
  @BeforeSuite(alwaysRun = true)
  public void setupSuite() throws Exception {

    profile = System.getenv("EES_ENV");
    if (profile == null) {
      Assert.fail("EES_ENV Environment Variable NOT Set");
    }
    log.info("using profile: " + profile);

    // Load properties
    eesProperties = new java.util.Properties();
    InputStream in = getClass().getResourceAsStream("/eesProp.properties");
    eesProperties.load(in);
    in.close();
    
 // Load properties
    eesTestDataProperties = new java.util.Properties();
   InputStream testdatain = getClass().getResourceAsStream("/eesTestdata.properties");
   eesTestDataProperties.load(testdatain);
   in.close();

    /**
     * Load the app url.
     * 
     * 
     */

    
    // configure the Urls for the Api and Applicaton UI
   eESAppUrl = eesProperties.getProperty("EES.url." + profile);
    //isetApiUrl = isetProperties.getProperty("isetApi.url." + profile);
    

    if (eESAppUrl != null) {
      log.info("using url: " + eESAppUrl);
      log.info("Using profile: \"" + profile + "\".  Environment Is Valid!");

    } else {
      Assert.fail("Environment \"" + profile + "\" Is NOT Supported !!");
    }

  }

  
 /* @AfterSuite(alwaysRun = true)
  public void AfterSuite() throws Exception {
   testUpdateReport();
   log.info("Generated Excel Fail log report");
	}

	public static void testUpdateReport() throws SAXException, IOException, ParserConfigurationException {
		
		ExcelReport.generateReport("target\\surefire-reports\\testng-results.xml");
		ExcelReport.generateReport("artifact\\target\\surefire-reports\\testng-results.xml");
		//ExcelReport.createOrUpdateReport("", "test-output\\testng-results.xml");

	}
  */
  
  
  protected Node getNode(String tagName, NodeList nodes) {
    for (int x = 0; x < nodes.getLength(); x++) {
      Node node = nodes.item(x);
      if (node.getNodeName().equalsIgnoreCase(tagName)) {
        return node;
      }
    }
    return null;
  }

  protected String getNodeAttr(String attrName, Node node) {
    NamedNodeMap attrs = node.getAttributes();
    for (int y = 0; y < attrs.getLength(); y++) {
      Node attr = attrs.item(y);
      if (attr.getNodeName().equalsIgnoreCase(attrName)) {
        return attr.getNodeValue();
      }
    }
    return "";
  }

  protected String getNodeAttr(String tagName, String attrName, NodeList nodes) {
    for (int x = 0; x < nodes.getLength(); x++) {
      Node node = nodes.item(x);
      if (node.getNodeName().equalsIgnoreCase(tagName)) {
        NodeList childNodes = node.getChildNodes();
        for (int y = 0; y < childNodes.getLength(); y++) {
          Node data = childNodes.item(y);
          if (data.getNodeType() == Node.ATTRIBUTE_NODE) {
            if (data.getNodeName().equalsIgnoreCase(attrName))
              return data.getNodeValue();
          }
        }
      }
    }
    return "";
  }

  protected String getNodeValue(Node node) {
    NodeList childNodes = node.getChildNodes();
    for (int x = 0; x < childNodes.getLength(); x++) {
      Node data = childNodes.item(x);
      if (data.getNodeType() == Node.TEXT_NODE)
        return data.getNodeValue();
    }
    return "";
  }

  protected String getNodeValue(String tagName, NodeList nodes) {
    for (int x = 0; x < nodes.getLength(); x++) {
      Node node = nodes.item(x);
      if (node.getNodeName().equalsIgnoreCase(tagName)) {
        NodeList childNodes = node.getChildNodes();
        for (int y = 0; y < childNodes.getLength(); y++) {
          Node data = childNodes.item(y);
          if (data.getNodeType() == Node.TEXT_NODE)
            return data.getNodeValue();
        }
      }
    }
    return "";
  }

  protected String responseBuilder(String filename) throws IOException {
    InputStream in = getClass().getResourceAsStream(filename);
    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
    StringBuilder sb = new StringBuilder();
    String line;
    while ((line = reader.readLine()) != null) {
      sb.append(line);
    }
    String response = sb.toString(); // Prints the string content read from
                                     // input stream
    reader.close();

    return response.trim().replaceAll(" +", " ");
  }
}
