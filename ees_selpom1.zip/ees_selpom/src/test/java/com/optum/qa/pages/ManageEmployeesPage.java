package com.optum.qa.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.optum.qa.eesFunctionalApp.EesAppBase;

public class ManageEmployeesPage extends EesAppBase {

	private WebDriver driver;

	@FindBy(xpath = "//*[contains(text(),'Enrollment Completed')]")
	private WebElement EnrollmentcompleteMsg;

	@FindBy(xpath = "//*[contains(text(),'Transaction Successful')]")
	private WebElement TransactionsuccessMsg;

	@FindBy(linkText = "ID Cards")
	private WebElement IdCardsLnk;

	@FindBy(linkText = "Print Record")
	private WebElement PrintRecordLnk;
	// page end
			@FindBy(xpath = "//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a[1]")
			private WebElement nextBtn_end;
		

	// terminate cdb
	@FindBy(xpath = ".//*[@id='terminateInquireEmp']")
	private WebElement TerminateEmpBtn;
	
	

		
		//reinstate cdb
			@FindBy(xpath = ".//*[@id='reinstateInquireEmp']")
			private WebElement ReinstateEmpBtn;
			
			@FindBy(xpath = ".//*[@id='effectiveDate']")
			private WebElement ReinstateEffectiveDateInput;
		
			@FindBy(xpath = "//*[contains(text(),'Expand All')]")
			private WebElement expandAllLnk;
			
			@FindBy(xpath = "//*[contains(text(),'Reinstate Successful')]")
			private WebElement reinstateSuccessfulMsg;
			
			@FindBy(xpath = ".//*[@id='policyNumber-Med-0-00']")
			private WebElement PolicyNumberdrpdwn;

			@FindBy(xpath = ".//*[@id='coverage-Med-0-00']")
			private WebElement Coveragedrpdwn;
			//tick mark
			@FindBy(xpath = ".//img[@alt='Transaction Successful']")
			private WebElement tickMark;

	// edit cdb
	@FindBy(xpath = ".//*[@id='editInquireEmpDemo']")
	private WebElement Edit_info_Emp_Btn;

	@FindBy(xpath = ".//*[@id='editInquireEmpPlans']")
	private WebElement Edit_plans_emp_Btn;

	// cdb
	@FindBy(xpath = ".//*[@id='coverageReasons']")
	private WebElement CoverageEndReason_emp_drpdwn;

	@FindBy(xpath = ".//*[@id='coverageDep1']")
	private WebElement CoverageEndReason_emp_input;

	@FindBy(xpath = ".//*[@id='dialog-yes']")
	private WebElement confirmTerminationYes;
	// btn
	@FindBy(xpath = "//*[@id='enrollmentForm']/following-sibling::div[1]/div[2]/a[1]")
	private WebElement SubmitEndBtn;
	
	
	
	
	@FindBy(xpath=".//*[@id='editInquireEmpDemo']")
	private WebElement EmpEditBtn ;

	@FindBy(xpath=".//*[@id='editInquireDepDemo-0']")
	private WebElement DepEditBtn ;

	@FindBy(xpath="//*[@id='dateOfBirth']")
	private WebElement DobInput;

	@FindBy(xpath=".//*[@id='depDateofBirth0']")
	private WebElement dependentDobInput;

	@FindBy(xpath="//*[contains(text(),'Change Successful')]']")
	private WebElement ChangeSuccessfulTxt;

	@FindBy(xpath=".//*[@class='page-content']/div[3]/div[2]/a")
	private WebElement submitStartBtn;

	@FindBy(xpath=".//*[@id='employeeInfo.demographicInfo.middleInitial']")
	private WebElement MiddleNameInput;

	@FindBy(xpath="//span[contains(text(),'Employee Information')]")
	private WebElement EmployeeInformationTxt ;

	@FindBy(xpath=".//*[@id='content-section-wrap-employee']/div/div/div[1]/a[2]")
	private WebElement CollapseAllEmployee ;

	@FindBy(xpath=".//*[@id='content-section-wrap-employee']/div/div/div[1]/a[1]")
	private WebElement ExpandAllEmployee ;

	@FindBy(xpath=".//*[@id='content-section-wrap-dependents']/div/div/div[1]/a[2]")
	private WebElement CollapseAllDependents ;

	@FindBy(xpath=".//*[@id='content-section-wrap-dependents']/div/div/div[1]/a[1]")
	private WebElement ExpandAllDependents ;

	@FindBy(xpath=".//*[@id='accordion-body-emp']/div[2]/div/div/div[2]/nobr/a")
	private WebElement EmployeePlanDetailsLnk ;

	@FindBy(xpath=".//*[@id='planBenefitDetailsForm']/div[1]/div[1]/a")
	private WebElement EmployeePlanDetailsBackBtn ;

	@FindBy(xpath=".//*[@id='accordion-body-']/div[2]/div/div/div[2]/nobr/a")
	private WebElement DependentPlanDetailsLnk ;

	@FindBy(xpath=".//*[@id='planBenefitDetailsForm']/div[1]/div[1]/a")
	private WebElement DependentPlanDetailsBackBtn ;

	@FindBy(xpath=".//*[@id='depSsn']")
	private WebElement DependentSsnInput ;

	@FindBy(xpath=".//*[@id='terminateInquireEmp']")
	private WebElement TerminateEmployeeBtn ;

	@FindBy(xpath=".//*[@id='coverageReasons']")
	private WebElement CoverageEndreasonListBox ;


	@FindBy(xpath=".//*[@id='coverageDep1']")
	private WebElement CoverageEndDateInput ;

	@FindBy(xpath=".//*[@id='dialog-yes']")
	private WebElement ConfirmTerminationYesBtn ;

	@FindBy(xpath=".//*[@id='modal-161']/h2")
	private WebElement ConfirmTerminationPageHeaderTxt ;

	//Confirm Termination

	@FindBy(xpath=".//*[@id='modal-161']/div[1]/p[1]")
	private WebElement ConfirmTerminationPageSitecopyTxt ;

	//Are you sure you want to terminate the following member(s)?


	@FindBy(xpath=".//*[@id='enrollment-body']/div[1]/div/div[2]/div[1]/div/div[2]/h2")
	private WebElement TerminateSuccessfulMessageTxt ;

	//Terminate Successful 

	@FindBy(xpath=".//*[@id='enrollment-body']/div[1]/div/div[2]/div[3]/div/div[1]/a")
	private WebElement PrintrecordBtn;

	@FindBy(xpath=".//*[@id='selectAll']")
	private WebElement PrintOptionsChkBox;

	@FindBy(xpath=".//*[@id='print-record']")
	private WebElement PrintOptionsPrintrecordBtn;

	@FindBy(xpath=".//*[@id='reinstateInquireEmp']")
	private WebElement EmployeeReinstateBtn;

	@FindBy(xpath=".//*[@class='page-content']/div[3]/div[2]/a")
	private WebElement NextBtn;

	@FindBy(xpath=".//*[@id='enrollment-body']/div[1]/div/div[2]/div[1]/div/div[2]/h2")
	private WebElement ReinstateSuccessfulMessageTxt ;
	
	

	@FindBy(xpath = ".//*[@id='selectAll']")
	private WebElement SelectAllchkbx;
	
	@FindBy(xpath = ".//*[@id='print-record']")
	private WebElement PrintRecrd_modal;

	public ManageEmployeesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void Validate_enrollment_complete()

	{
		fnWaitForElement(driver, EnrollmentcompleteMsg, shortTimeout);
		fnWaitForElement(driver, TransactionsuccessMsg, shortTimeout);
		fnWaitForElement(driver, IdCardsLnk, VeryshortTimeout);
		fnWaitForElement(driver, PrintRecordLnk, VeryshortTimeout);
	}

	public void terminate_emp(String reason, String date) throws Exception {
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		TerminateEmpBtn.click();
		fnWaitForElement(driver, CoverageEndReason_emp_drpdwn, shortTimeout);
		fnSelectByText(reason, CoverageEndReason_emp_drpdwn);
		CoverageEndReason_emp_input.clear();
		CoverageEndReason_emp_input.sendKeys(date);
		Thread.sleep(1000);
		SubmitEndBtn.click();
		app_SpinnerInvisible(driver);
		driver.switchTo().defaultContent();

		confirmTerminationYes.click();
		
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		fnWaitForElement(driver, tickMark, shortTimeout);
		

	}
	public void validate_editEmployeeandDependent_Cosmos() throws Exception{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		fnIsDisplayed(EmployeeInformationTxt);
		fnIsDisplayed(PrintRecordLnk);
		CollapseAllEmployee.click();
		ExpandAllEmployee.click();
		EmployeePlanDetailsLnk.click();
		EmployeePlanDetailsBackBtn.click();
		CollapseAllDependents.click();
		ExpandAllDependents.click();
		DependentPlanDetailsLnk.click();
		DependentPlanDetailsBackBtn.click();

		EmpEditBtn.click();
		String middlename= RandomStringUtils.randomAlphabetic(1);
		MiddleNameInput.clear();
		MiddleNameInput.sendKeys(middlename);

		//DobInput.clear();
		// DobInput.sendKeys("01011990");
		submitStartBtn.click();
		app_SpinnerInvisible(driver);
		fnVerifyElementText(ChangeSuccessfulTxt, "Change Successful");
		log.info("Dependent update");
		DepEditBtn.click();
		Thread.sleep(1000);
		String depssn= RandomStringUtils.randomNumeric(12);
		DependentSsnInput.clear();
		Thread.sleep(10000);
		log.info("SSN "+depssn);
		DependentSsnInput.sendKeys(depssn);
		//DependentSsnInput.sendKeys("000456788888");
		//log.info("SSN "+generateSSN());
		Thread.sleep(10000);
		submitStartBtn.click();
		
		//driver.switchTo().defaultContent();
		app_SpinnerInvisible(driver);
		fnVerifyElementText(ChangeSuccessfulTxt, "Change Successful");

	}
	public void validate_TerminateEmployee_Cosmos() throws Exception{
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		fnIsDisplayed(EmployeeInformationTxt);
		fnIsDisplayed(PrintRecordLnk);
		TerminateEmployeeBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		fnVerifyElementText(CoverageEndreasonListBox, "- Select One -");
		fnSelectByText("Cobra Termination", CoverageEndreasonListBox);
		Thread.sleep(2000);
		CoverageEndDateInput.clear();
		//CoverageEndDateInput.sendKeys("01012017");
		driver.switchTo().defaultContent();


	}
	
	public void validate_TerminatecoverageDate() throws Exception{
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		/*incdate += 2;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, incdate); // Adding 2 days
		String output = sdf.format(c.getTime());
		System.out.println(output);*/
		CoverageEndDateInput.clear();
		CoverageEndDateInput.sendKeys(selectDate());
		submitStartBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		fnVerifyElementText(ConfirmTerminationPageHeaderTxt, "Confirm Termination");
		fnVerifyElementText(ConfirmTerminationPageSitecopyTxt, "Are you sure you want to terminate the following member(s)?");
		driver.switchTo().defaultContent();
		ConfirmTerminationYesBtn.click();
		Thread.sleep(2000);
		fnVerifyElementText(TerminateSuccessfulMessageTxt, "Terminate Successful");
		/*fnWaitAndSwitchToFrame("ff-iframe", driver);
		PrintRecordLnk.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		SelectAllchkbx.click();
		Thread.sleep(2000);
		PrintOptionsPrintrecordBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(5000);*/
	}

	public void validate_ReinstateEmployee() throws Exception{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		EmployeeReinstateBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		NextBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		NextBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		NextBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		submitStartBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		fnVerifyElementText(ReinstateSuccessfulMessageTxt, "Terminate Successful");

	}
	
	public void validate_printRecordButton() throws Exception{
		fnWaitAndSwitchToFrame("ff-iframe", driver);
		PrintRecordLnk.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		SelectAllchkbx.click();
		Thread.sleep(2000);
		PrintOptionsPrintrecordBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(5000);
	}

	public void validate_ManageEmployeeTab_Cosmos() throws Exception{

		fnWaitAndSwitchToFrame("ff-iframe", driver);
		fnIsDisplayed(EmployeeInformationTxt);
		fnIsDisplayed(PrintRecordLnk);
		CollapseAllEmployee.click();
		ExpandAllEmployee.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
	}
	 public void print_records(String testid) throws Exception
		{ 
			fnWaitAndSwitchToFrame("ff-iframe", driver);
			PrintRecordLnk.click();
			driver.switchTo().defaultContent();
			fnClickElementByJS(driver, SelectAllchkbx);
			//SelectAllchkbx.click();
			Thread.sleep(6000);
			//fnAlertAccept(driver);
			//fnClickElementByJS(driver, PrintRecrd_modal);
			PrintRecrd_modal.click();
			//fnWaitForPageLoad(driver);
			Thread.sleep(15000);
			//GetScreenShot("printRecords", testid,driver);

		}
	 public void reinstate_CDB(String policyNumber,String Coverage) throws Exception
		{
			fnWaitAndSwitchToFrame("ff-iframe", driver);
			ReinstateEmpBtn.click();
			log.info("clicked on reinstate button");
			app_SpinnerInvisible(driver);
			ReinstateEffectiveDateInput.sendKeys("");
			nextBtn_end.click();
			app_SpinnerInvisible(driver);
			nextBtn_end.click();
			app_SpinnerInvisible(driver);
			//plans
			expandAllLnk.click();
			fnSelectByText(policyNumber, PolicyNumberdrpdwn);

			app_SpinnerInvisible(driver);
			// Thread.sleep(6000);
			log.info("policy is selected");

			fnSelectByValue(Coverage, Coveragedrpdwn);
			//fnSelectByValue("0001~0001~POS", Coveragedrpdwn);
			Thread.sleep(6000);
			log.info("coverage is selected");
			nextBtn_end.click();
			app_SpinnerInvisible(driver);
			SubmitEndBtn.click();
			app_SpinnerInvisible(driver);
			
		}
		
}