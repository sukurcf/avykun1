package com.optum.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.optum.qa.eesFunctionalApp.EesAppBase;
/**
 * 
 * @author jsahoo10
 *This represents the Home Page of the EES application which will comes after the login to EES
 */
public class HomePage extends EesAppBase{

	private WebDriver driver;

	@FindBy(xpath=".//*[contains(@href,'/ees/dashboard')]")
	private WebElement dashboardTab;

	@FindBy(xpath=".//*[contains(@href,'/ees/manageEmployees')]")
	private WebElement manageEmployeesTab;

	@FindBy(xpath="//*[@rel='reports']")
	private WebElement reportsTab;

	@FindBy(xpath="//a[contains(text(),'Banking')]")
	private WebElement Banking_reports_subTab;


	@FindBy(xpath="//*[contains(text(),'Tools For Wellness')]")
	private WebElement ToolsForWellnessTab;


	@FindBy(xpath=".//*[contains(@title,'Select Group')]")
	private WebElement selectGroup;

	@FindBy(id="groupSearch-input")
	private WebElement groupSearchInput;

	@FindBy(xpath=".//*[@alt='Search']")
	private WebElement searchImage;

	@FindBy(id="groupSearch-selectButton")
	private WebElement selectPolicyButton;

	@FindBy(id="employee-search-box")
	private WebElement searchEmployee;

	@FindBy(id="searchForEmployees-Submit")
	private WebElement searchEmployeeImage;

	@FindBy(xpath="//*[contains(text(),'Invoices')]")
	private WebElement invoicesTab;

	@FindBy(id="ffSearchResult-0")
	private WebElement EmpInquireLink;

	@FindBy(xpath="//a[contains(text(),'Member Enrollment')]")
	private WebElement MemberEnrollmentLink;

	@FindBy(id="add-new-employee")
	private WebElement AddNewEmp_button;


	@FindBy(xpath="//*[contains(text(),'Electronic Eligibility Management')]")
	private WebElement ElectronicEligibilityManagement;

	@FindBy(xpath=".//*[@id='data_tab0']")
	private WebElement EEMSPageLoadgrid;


	@FindBy(xpath="//*[@rel='reportsCostAndUtilization']")
	private WebElement reportseCR;

	//in pop up
	@FindBy(xpath=".//*[@id='groupSelectPopup-input']")
	private WebElement searchforgrpInput;

	//in pop up
	@FindBy(xpath="//*[@id='groupSelectPopup-searchButton']")
	private WebElement searchimg_seachgrp;

	@FindBy(xpath="//*[@class='column-one']")
	private WebElement groupfrstResult;

	@FindBy(xpath="//*[@id='groupSelectPopup-continue']")
	private WebElement continueBtn;

	@FindBy(xpath=".//*[@id='myProfile-link']")
	private WebElement MyProfileLnk;

	@FindBy(xpath="//a[contains(text(),'Visit the Electronic Eligibility Management Site')]")
	private WebElement visitEltroniclink;


	@FindBy(xpath="//*[@src='/eems/images/e3-banner-c.gif']")
	private WebElement eems_img;
	@FindBy(xpath="//*[contains(text(),'Logout')]")
	private WebElement logout_eems;

	@FindBy(xpath=".//*[@id='logout-link']")
	private WebElement LogOutButton;

	@FindBy(xpath=".//*[@id='content-section-wrap-employee']")
	private WebElement InquireEmployeeFrame;

	@FindBy(xpath=".//*[@id='content-section-wrap-dependents']/h2")
	private WebElement InquireDepFrame;

	@FindBy(xpath=".//*[@href='planBenefitDetails.do?memberLevel=00&sourceUrl=inquireEnrollment.do']")
	private WebElement EmpPlanDetailslnk;
	@FindBy(xpath=".//*[@id='ffSearchResult-0']")
	private WebElement employeeSearchResults;
	
	@FindBy(xpath=".//*[@id='ffSearchResult-2']")
	private WebElement employeeanddependentSearchResults;
	
	@FindBy(xpath=".//*[@id='ffSearchResult-0']")
	private WebElement AllCoverage_employeeanddependentSearchResults;
	
		
	@FindBy(xpath=".//*[@id='ffSearchResult-1']")
	private WebElement dependentSearchResults;
	
	@FindBy(xpath=".//*[@id='notificationsAndAlerts-link']")
	private WebElement alerts_notificationsLnk;
	
	
	@FindBy(xpath=".//*[@id='help-link']")
	private WebElement helpLnk;
	
	
	@FindBy(xpath=".//*[@rel='toolsForWellness']")
	private WebElement ToolsforwellnessTab;
	
	
	@FindBy(xpath=".//*[@id='feedback-link']")
	private WebElement feedbackLnk;
	
	@FindBy(xpath=".//*[@rel='manageAccess']")
	private WebElement manageAccesstab;
	
	//plans and services
	@FindBy(xpath=".//*[@id='dashboard-plansAndServices']")
	private WebElement plansAndServices;
	
	@FindBy(xpath="//*[contains(text(),'Summary of Benefits and Coverage')]")
	private WebElement summryAndBenftCoverageLnk;
	//bottom 
	@FindBy(xpath=".//*[@class='copyright']")
	private WebElement copyright;
	
	@FindBy(xpath="//*[(@class='urchin-tracker')and(@href='/ees/static/internetServiceAgreement.do')]")
	private WebElement internetServiceAgrmnt;
	
	@FindBy(xpath=".//img[@class='close']")
	private WebElement close_modal;

	
	@FindBy(xpath=".//*[@id='sbc-docs-table']/tbody/tr/td[1]/a")
	private WebElement pdf1;
	
	/*@FindBy(xpath="//*[contains(text(),'Invoices')]")
	private WebElement invoicesTab;*/

	public HomePage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(this.driver, this);

	}
	/**
	 * 
	 * @param number
	 * @throws Exception
	 * Method to search for a policy
	 */
	public void searchForPolicy(String number) throws Exception{
		selectGroup.click();
		groupSearchInput.sendKeys(number);
		searchImage.click();
		log.info("****searching for policy :"+number);
		fnWaitForPageLoad(driver);
		selectPolicyButton.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("completed searching for policy");

	}

	/**
	 * 
	 * @param number
	 * @throws Exception
	 * Method to search for employee
	 */
	public void searchForEmployee(String number)throws Exception{
		searchEmployee.sendKeys(number);
		searchEmployeeImage.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);
		log.info("completed searching for employee: " +number);

	}

	/**
	 * 
	 * @throws Exception
	 * Method to Click on InvoicesTab on HomePage
	 */

	public InvoicesPage click_Invoices_Tab()throws Exception{
		String parentHandle = driver.getWindowHandle(); // get the current window handle
		invoicesTab.click();
		Thread.sleep(3000);
		fnWaitForPageLoad(driver);
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
		}

		fnWaitForPageLoad(driver);
		return new InvoicesPage(driver);	
	}


	/**
	 * 
	 * @param number
	 * @throws Exception
	 * Method to search for employee
	 */
	public void Click_InquireEmployee_link()throws Exception{
		EmpInquireLink.click();
		app_SpinnerInvisible(driver);
		fnWaitForPageLoad(driver);



	}

	public void Validate_Inquire_EmmployeeSection () throws Exception {

		(new WebDriverWait(driver, 3)).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("ff-iframe"));
		fnSwitchFrame("ff-iframe");
		fnIsDisplayed(InquireEmployeeFrame);
		fnIsDisplayed(EmpPlanDetailslnk);
		driver.switchTo().defaultContent();

	}

	public void Validate_Inquire_DepSection () throws Exception {

		(new WebDriverWait(driver, 3)).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("ff-iframe"));
		fnSwitchFrame("ff-iframe");
		fnWaitForElement(driver, InquireDepFrame, 2);
		driver.switchTo().defaultContent();

	}



	/**
	 * 
	 * @param number
	 * @throws Exception
	 * this Method is to click on member enrollment link
	 */

	public void Click_MemberEnrollment_link()throws Exception{
		MemberEnrollmentLink.click();
		fnWaitForPageLoad(driver);


	}
	public void Click_ElectronicEligibilityManagement() throws Exception
	{
		ElectronicEligibilityManagement.click();
		//fnWaitForPageLoad(dr
		fnSwitchToWindow("EEMS - Home", 20, driver);

		fnWaitForPageLoad(driver);


	}

	public void verify_homePage() throws Exception
	{
		//fnIsDisplayed(invoicesTab);
		fnIsDisplayed(manageEmployeesTab);
		fnIsDisplayed(reportsTab);
		fnIsDisplayed(ToolsForWellnessTab);



	}
	public void Reports_banking() throws Exception
	{
		fnMouseOverAndClick(reportsTab, Banking_reports_subTab);
	}

	public void clickReports() throws Exception
	{
		reportsTab.click();
		Thread.sleep(3000);
		//fnWaitForPageLoad(driver);
	}

	public void click_banking() throws Exception
	{
		Banking_reports_subTab.click();
		Thread.sleep(3000);
		//fnWaitForPageLoad(driver);
		//return new ReportsPage(driver);

	}
	public void clickReportstab_eCR() throws Exception
	{
		reportseCR.click();
		Thread.sleep(3000);
	}


	public void searchForGroup(String grpName) throws Exception
	{


		AddNewEmp_button.click();
		fnWaitForPageLoad(driver);
		searchforgrpInput.sendKeys(grpName);
		searchimg_seachgrp.click();

		fnWaitForPageLoad(driver);
		groupfrstResult.click();
		continueBtn.click();
		app_SpinnerInvisible(driver);


	}


	public void click_visit_electroniclink() throws Exception {
		//visitEltroniclink.click();
		fnClickElementByJS(driver, visitEltroniclink);
		Thread.sleep(8000);

	}

	public void Click_MyProfileLnk()throws Exception{
		MyProfileLnk.click();
		fnWaitForPageLoad(driver);

	}

	public void Click_LogOutLnk() throws Exception 
	{

		LogOutButton.click();
		log.info("clicked on log  out link on home page");
		fnWaitForvisible(By.name("passwordForm.userId"));
		driver.close();

	}

	public void validate_eems() throws Exception
	{
		fnVerifyElementDisplayed(EEMSPageLoadgrid);
		fnIsDisplayed(logout_eems);


	}


	public void Validate_EEMSPageLoad() throws Exception
	{
		fnIsDisplayed(EEMSPageLoadgrid);


	}

	public void Logout_EEMS() throws Exception
	{
		logout_eems.click();
		Thread.sleep(4000);
		//fnWaitForPageLoad(driver);


	}

	public void click_addNewEmp() throws Exception
	{
		//AddNewEmp_button.clear();
		fnClickElementByJS(driver, AddNewEmp_button);
		Thread.sleep(6000);
		//fnWaitForPageLoad(driver);

	}
	public void validate_dashboardTab(){

		dashboardTab.click();

	}
	public void validate_employeeSearchResults(){
		employeeSearchResults.click();
	}
	public void validate_manageEmployeesTab(){
		manageEmployeesTab.click();
		
	}
	
	public void validate_AllCoverage_employeeanddependentSearchResults()
	{

		AllCoverage_employeeanddependentSearchResults.click();
	}
	
	public void validate_employeeanddependentSearchResults()
	{

		employeeanddependentSearchResults.click();
	}
	public void click_dashboard_tab()
	{
		dashboardTab.click();
		fnWaitForPageLoad(driver);
	}
	
	public void click_manage_accesss() throws Exception
	{
		manageAccesstab.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(2000);
	}
	public void validate_homepage()
	{  //links header
		fnWaitForElement(driver, MyProfileLnk, shortTimeout);
		fnWaitForElement(driver, LogOutButton, shortTimeout);
		
		fnWaitForElement(driver, alerts_notificationsLnk, shortTimeout);
		fnWaitForElement(driver, helpLnk, shortTimeout);
		fnWaitForElement(driver, feedbackLnk, shortTimeout);

		//tabs
		fnWaitForElement(driver, manageEmployeesTab, shortTimeout);
		fnWaitForElement(driver, invoicesTab, shortTimeout);
		fnWaitForElement(driver, reportsTab, shortTimeout);
		
		fnWaitForElement(driver, ToolsForWellnessTab, shortTimeout);
		fnWaitForElement(driver, dashboardTab, shortTimeout);
		//sections
		fnWaitForElement(driver, plansAndServices, shortTimeout);

		
		//footer
		fnWaitForElement(driver, copyright, shortTimeout);
		fnWaitForElement(driver, internetServiceAgrmnt, shortTimeout);
	}
	public void click_summryAndBenftCoverageLnk() throws Exception
	{
		summryAndBenftCoverageLnk.click();
		app_SpinnerInvisible(driver);
	}
	public void close_selectpolicyModal(){
		close_modal.click();
		fnWaitForPageLoad(driver);
	}
	public void click_pdf()
	{
		pdf1.click();
		fnWaitForPageLoad(driver);
	}
	
	public void selectgroup() throws Exception
	{
		selectGroup.click();
		fnSelectByValue("101463929", selectGroup);
		Thread.sleep(6000);
	}
	public void click_benefitsAdminKit()
	{
		driver.findElement(By.xpath("//*[contains(text(),'Benefit Admin Kits')]")).click();
		fnWaitForPageLoad(driver);
	}
	
	public void groupSearch(String grpName) throws Exception
	{
		searchforgrpInput.sendKeys(grpName);
		searchimg_seachgrp.click();

		fnWaitForPageLoad(driver);
		groupfrstResult.click();
		Thread.sleep(2000);
		continueBtn.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(5000);
	}
	public void validate_benefitAdminKits()
	{
		fnWaitForElement(driver, driver.findElement(By.xpath("//*[contains(text(),'Benefit Admin Kits')]")), shortTimeout);

		fnWaitForElement(driver, driver.findElement(By.xpath("//*[contains(text(),'Admin Guide Tutorial')]")), shortTimeout);}
}