package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.optum.qa.eesFunctionalApp.EesAppBase;


/**
 * 
 * @author eshravan
 *This represents the PHS Page of the EES application which will comes after clicking on Member enrollment link
 */

public class PHSPage extends EesAppBase {

	private WebDriver driver;

	@FindBy(id="contentIframe")
	private WebElement contentIframePHS;

	@FindBy(xpath=".//*[@id='navMenuForm:j_id7']//input[@value='New Add Form']")
	private WebElement newAddFormButton;

	@FindBy(id="navMenuForm:terminateEnrollment")
	private WebElement terminationFormButton;

	@FindBy(id="navMenuForm:j_id12")
	private WebElement rqstChangeFormButton;



	/**
	 * 
	 * Elements on New Add Form page for Subscriber
	 * 
	 */

	@FindBy(id="addEnrollmentForm:stateSelection")
	private WebElement stateSelection_DrpDbutton;


	@FindBy(id="addEnrollmentForm:authContactName")
	private WebElement benefitAdminName_Input ;


	@FindBy(id="addEnrollmentForm:authAreaCode")
	private WebElement benefitAdminPhnAreaCode_Input;


	@FindBy(id="addEnrollmentForm:authPrefixCode")
	private WebElement benefitAdminPhnPrefixCode_Input ;


	@FindBy(id="addEnrollmentForm:authPhoneNumber")
	private WebElement benefitAdminPhnNumber_Input ;


	@FindBy(id="addEnrollmentForm:emailAddress")
	private WebElement benefitAdminEmailAddrs_Input ;


	@FindBy(id="addEnrollmentForm:groupNo")
	private WebElement groupNumber_Input ;


	@FindBy(id="addEnrollmentForm:groupName")
	private WebElement groupName_Input ;


	@FindBy(id="addEnrollmentForm:ssnOne")
	private WebElement ssnFstField_Input;


	@FindBy(id="addEnrollmentForm:ssnTwo")
	private WebElement ssnScndField_Input ;


	@FindBy(id="addEnrollmentForm:ssn")
	private WebElement ssnThirdField_Input ;

	@FindBy(id="addEnrollmentForm:subscriberLastName")
	private WebElement subscriberLstName_Input;


	@FindBy(id="addEnrollmentForm:subscriberFirstName")
	private WebElement subscriberFstName_Input ;

	@FindBy(id="addEnrollmentForm:subscriberMiddleName")
	private WebElement subscriberMddleName_Input ;

	@FindBy(id="addEnrollmentForm:dohCalIdInputDate")
	private WebElement subscriberDateOfHire_Input;

	@FindBy(id="addEnrollmentForm:dohCalIdPopupButton")
	private WebElement subscriberDateOfHireCalender_Img ;

	@FindBy(id="addEnrollmentForm:redCalIdInputDate")
	private WebElement reqstEffDate_Input;

	@FindBy(id="addEnrollmentForm:redCalIdPopupButton")
	private WebElement requestEffDateCalender_Img ;

	@FindBy(id="addEnrollmentForm:dobCalIdInputDate")
	private WebElement dOB_Input ;

	@FindBy(id="addEnrollmentForm:dobCalIdPopupButton")
	private WebElement dOBCalender_Img ;

	@FindBy(id="addEnrollmentForm:productPlanCode")
	private WebElement planCode_Input ;

	@FindBy(xpath="//select[@name='addEnrollmentForm:j_id94']")
	private WebElement lifeCvrgIncluded_DDN ;


	@FindBy(xpath="//select[@name='addEnrollmentForm:j_id101']")
	private WebElement qualifyingEvntReason_DDN ;

	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id108']")
	private WebElement specifyReason_Input;

	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id119']")
	private WebElement pCPNumber_Input ;

	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id124']")
	private WebElement pCPName_Input ;

	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id127']")
	private WebElement locationCode_Input ;

	@FindBy(xpath="//select[@name='addEnrollmentForm:j_id130']")
	private WebElement subscriberGender_DDN ;

	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id137']")
	private WebElement subscriberStreet_Input ;

	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id142']")
	private WebElement subscriberCity_Input ;


	@FindBy(xpath="//select[@name='addEnrollmentForm:j_id147']")
	private WebElement subscriberState_DDN;


	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id153']")
	private WebElement subscriberZip_Input;


	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id160']")
	private WebElement subscriberHomePhnFst_Input ;



	@FindBy(xpath="//input[@name='addEnrollmentForm:j_id162']")
	private WebElement subscriberHomePhnScnd_Input;


	@FindBy(xpath="//select[@name='addEnrollmentForm:j_id166']")
	private WebElement noOfDep_DDN;


	@FindBy(xpath=".//*[contains(text(),'Product Selection/Plan Code: is required field.')]")
	private WebElement PlanCoderequiredErrMsg;


	// Elements on New Add Form page for Dependent


	@FindBy(id="addEnrollmentForm:sdepRel-0")
	private WebElement relationshpToSubscriber_DDN ;

	@FindBy(id="addEnrollmentForm:sdepArea-0")
	private WebElement depssnfst_Input;

	@FindBy(id="addEnrollmentForm:sdepGrp-0")
	private WebElement depssnScnd_Input;

	@FindBy(id="addEnrollmentForm:sdepSerial-0")
	private WebElement depssnThird_Input;

	@FindBy(id="addEnrollmentForm:sdepLastName-0")
	private WebElement depLastName_Input ;

	@FindBy(id="addEnrollmentForm:sdepFirstName-0")
	private WebElement depFstName_Input;

	@FindBy(id="addEnrollmentForm:sdepMiddleName-0")
	private WebElement depMddleIntial_Input ;

	@FindBy(id="addEnrollmentForm:sdepCalDOB-0InputDate")
	private WebElement depDOB_Input ;

	@FindBy(id="addEnrollmentForm:sdepCalDOB-0PopupButton")
	private WebElement depDOBClnder_Img ;

	@FindBy(id="addEnrollmentForm:sdepProductPlanCode-0")
	private WebElement depPlanCode_Input ;

	@FindBy(id="addEnrollmentForm:sdepSelectedQualEvent-0")
	private WebElement depqualifyingEventReason_DDN  ;

	@FindBy(id="addEnrollmentForm:sdepSpecify-0")
	private WebElement depSpecify_Input ;

	@FindBy(id="addEnrollmentForm:sdepPCPNum-0")
	private WebElement depPCPNo_Input ;

	@FindBy(id="addEnrollmentForm:sdepPCPPhys-0")
	private WebElement depPCPName_Input  ;

	@FindBy(id="addEnrollmentForm:sdepGender-0")
	private WebElement depGender_DDN ;

	@FindBy(xpath="//input[@ value='Send Request']")
	private WebElement sendRequest_Btn ;

	@FindBy(xpath="//input[@value='Start Over']")
	private WebElement startOver_Btn ;

	@FindBy(xpath="//span[contains(text(),'Thank you for your Submission')]")
	private WebElement confirmatationMessage ;


	//Elements on Termination Form page for Subscriber

	@FindBy(id="terminateEnrollmentForm:stateSelection")
	private WebElement termStateSelection_DDN ;

	@FindBy(id="terminateEnrollmentForm:authContactName")
	private WebElement termBenefitAdminName_Input ;

	@FindBy(id="terminateEnrollmentForm:authAreaCode")
	private WebElement termSubscriberPhoneAreaCOde_Input ;

	@FindBy(id="terminateEnrollmentForm:authPrefixCode")
	private WebElement termSubscriberPhonePrefix_Input  ;

	@FindBy(id="terminateEnrollmentForm:authPhoneNumber")
	private WebElement termSubscriberPhoneThird_Input  ;

	@FindBy(id="terminateEnrollmentForm:emailAddress")
	private WebElement termSubscriberEmailAddrss_Input ;

	@FindBy(id="terminateEnrollmentForm:groupNo")
	private WebElement termSubscriberGrpNo_Input ;

	@FindBy(id="terminateEnrollmentForm:groupName")
	private WebElement termSubscriberGrpName_Input  ;

	@FindBy(id="terminateEnrollmentForm:ssnOne")
	private WebElement termSubscriberSSNfirst_Input ;

	@FindBy(id="terminateEnrollmentForm:ssnTwo")
	private WebElement termSubscriberSNScnd_Input ;

	@FindBy(id="terminateEnrollmentForm:ssn")
	private WebElement termSubscriberSSNThird_Input ;

	@FindBy(id="terminateEnrollmentForm:subscriberLastName")
	private WebElement termSubscriberLastName_Input ;

	@FindBy(id="terminateEnrollmentForm:subscriberFirstName")
	private WebElement termSubscriberFstName_Input  ;

	@FindBy(xpath="//select[@name='terminateEnrollmentForm:j_id80']")
	private WebElement termSubscriber_DDN  ;

	@FindBy(id="terminateEnrollmentForm:reqTermCalIdInputDate")
	private WebElement termSubscriberDate_Input  ;

	@FindBy(id="terminateEnrollmentForm:reqTermCalIdPopupButton")
	private WebElement termSubscriberDateCalender_Img ;

	@FindBy(xpath="//select[@name='terminateEnrollmentForm:j_id91']")
	private WebElement termDepOnly_DDN ;

	@FindBy(xpath="//select[@name='terminateEnrollmentForm:j_id93']")
	private WebElement termNoOfDep_DDN  ;

	@FindBy(id="terminateEnrollmentForm:dependentRepeat:0:dependent")
	private WebElement termDepToBeTerm_Input ;

	@FindBy(xpath="//input[@value='Send Request' and @name='terminateEnrollmentForm:j_id114']")
	private WebElement termSndRequest_Btn  ;

	@FindBy(xpath=".//*[@id='terminateEnrollmentForm:terminatePanel_body']//input[@value='Start Over']")
	private WebElement termSendOver_Btn ;


	// Elements on Request Change page for Subscriber


	@FindBy(id="changeEnrollmentForm:stateSelection")
	private WebElement rqstChangeStateSelction_DDN  ;

	@FindBy(id="changeEnrollmentForm:authContactName")
	private WebElement rqstChangeBeneftAdminName_Input  ;

	@FindBy(id="changeEnrollmentForm:authAreaCode")
	private WebElement rqstChangePhnAreaCode_Input  ;

	@FindBy(id="changeEnrollmentForm:authPrefixCode")
	private WebElement rqstChangePhnPrefixCode_Input ;

	@FindBy(id="changeEnrollmentForm:authPhoneNumber")
	private WebElement rqstChangePhnPhoneNumber_Input  ;

	@FindBy(id="changeEnrollmentForm:emailAddress")
	private WebElement rqstChangeEmailAddrss_Input ;

	@FindBy(id="changeEnrollmentForm:groupNo")
	private WebElement rqstChangeSubscriberGrpNo_Input  ;

	@FindBy(id="changeEnrollmentForm:groupName")
	private WebElement rqstChangeSubscriberGrpName_Input ;

	@FindBy(id="changeEnrollmentForm:ssnOne")
	private WebElement rqstChangeSubscriberSSNFrst_Input ;

	@FindBy(id="changeEnrollmentForm:ssnTwo")
	private WebElement rqstChangeSubscriberSSNScnd_Input  ;

	@FindBy(id="changeEnrollmentForm:ssn")
	private WebElement rqstChangeSubscriberSSNThird_Input  ;

	@FindBy(id="changeEnrollmentForm:subscriberLastName")
	private WebElement rqstChangeSubscriberLastName_Input ;

	@FindBy(id="changeEnrollmentForm:subscriberFirstName")
	private WebElement rqstChangeSubscriberFstName_Input  ;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:changePanel_body']/select[2]")
	private WebElement  rqstChange_DDN;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:otherPanel']/input[@name='changeEnrollmentForm:j_id81']")
	private WebElement describeChangesReq_Input  ;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:addressPanel']/input[1]")
	private WebElement rqstChngsubscriberStreetAddrss_Input  ;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:addressPanel']/input[2]")
	private WebElement rqstChangesSubscriberCity_Input  ;

	@FindBy(id="changeEnrollmentForm:selectState")
	private WebElement rqstChngeState_DDN  ;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:addressPanel']/input[3]")
	private WebElement rqstChngeZip_Input  ;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:changePanel_body']/input[@name='changeEnrollmentForm:j_id201']")
	private WebElement rqstchngeHomePhnefield1_Input  ;

	@FindBy(xpath=".//*[@id='changeEnrollmentForm:changePanel_body']/input[@name='changeEnrollmentForm:j_id203']")
	private WebElement rqstchngeHomePhnefield2_Input  ;


	@FindBy(xpath=".//*[@id='changeEnrollmentForm:pcpPanel']/input[@name='changeEnrollmentForm:j_id207']")
	private WebElement rqstchangePCPNumber_Input  ;


	@FindBy(xpath=".//*[@id='changeEnrollmentForm:changePanel_body']/input[@name='changeEnrollmentForm:j_id212']")
	private WebElement rqstchangePCPName_Input  ;


	@FindBy(xpath="//input[@value='Send Request']")
	private WebElement rqstChangeSendRequest_Btn  ;


	@FindBy(xpath=".//*[@id='changeEnrollmentForm:changePanel_body']/input[@name='changeEnrollmentForm:j_id217']")
	private WebElement rqstChangeStrtOver_Btn  ;






	public PHSPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(this.driver, this);

	}


	/**
	 * @author eshravan
	 * @param PlanCode
	 * Method to add subscriber
	 * 
	 */

	public void addSubscriber(String PlanCode){
		fnSwitchToFrame(contentIframePHS, driver);
		fnSelectByValue("CA", stateSelection_DrpDbutton);
		benefitAdminName_Input.sendKeys("TestBene");
		benefitAdminPhnAreaCode_Input.sendKeys("673");
		benefitAdminPhnPrefixCode_Input.sendKeys("543");
		benefitAdminPhnNumber_Input.sendKeys("7854");
		benefitAdminEmailAddrs_Input.sendKeys("shravani_embadi@optum.com");
		groupNumber_Input.sendKeys("84639373");
		groupName_Input.sendKeys("TestGroup");
		ssnFstField_Input.sendKeys("751");
		ssnScndField_Input.sendKeys("24");
		ssnThirdField_Input.sendKeys("8463");
		subscriberLstName_Input.sendKeys("Test");
		subscriberFstName_Input.sendKeys("Test");
		subscriberDateOfHire_Input.sendKeys("06/01/2017");
		reqstEffDate_Input.sendKeys("06/01/2017");
		dOB_Input.sendKeys("06/02/1993");
		planCode_Input.sendKeys(PlanCode);
		fnSelectByValue("New Hire",qualifyingEvntReason_DDN);
		specifyReason_Input.sendKeys("test");
		fnSelectByValue("Female",subscriberGender_DDN);	
		subscriberStreet_Input.sendKeys("test");
		subscriberCity_Input.sendKeys("test");
		fnSelectByValue("MD",subscriberState_DDN);
		subscriberZip_Input.sendKeys("20701");
		fnWaitForPageLoad(driver);



	}


	/**
	 * @author eshravan
	 * Method to add subscriber and dependent
	 */

	public void addSubscriberOneDep(String plancode){
		addSubscriber(plancode);
		fnSelectByValue("1", noOfDep_DDN);
		fnSelectByValue("Spouse", relationshpToSubscriber_DDN);
		depssnfst_Input.sendKeys("245");
		depssnScnd_Input.sendKeys("23");
		depssnThird_Input.sendKeys("8997");
		depLastName_Input.sendKeys("test");
		depFstName_Input.sendKeys("test");
		depDOB_Input.sendKeys("06/02/1993");
		depPlanCode_Input.sendKeys("PlanCode@123");
		fnSelectByValue("New Hire", depqualifyingEventReason_DDN);
		depSpecify_Input.sendKeys("test");

	}

	/**
	 * @author eshravan
	 * Method to click send request button
	 */

	public void click_SendRequest_Button()
	{
		sendRequest_Btn.click();
		fnWaitForPageLoad(driver);
	}


	/**
	 * @author eshravan
	 * Method to verify confirmation message after successful request
	 */

	public void Verifying_ConfrimationPage()
	{
		fnVerifyElementDisplayed(confirmatationMessage);
		fnVerifyElementDisplayed(startOver_Btn);
	}

	/**
	 * @author eshravan
	 * Method to verify Error message for submitting request with blank plan code
	 */

	public void Verify_ErrorMessage()
	{
		fnVerifyElementText(PlanCoderequiredErrMsg, "Product Selection/Plan Code: is required field.");
		startOver_Btn.click();
		fnWaitForPageLoad(driver);
	}


	/**
	 * @author eshravan
	 * @param plancode
	 * Method to add subscriber end to end
	 */

	public void addSubscriberEndToEnd(String plancode){
		addSubscriber(plancode);
		click_SendRequest_Button();
		Verifying_ConfrimationPage();
		startOver_Btn.click();
		fnWaitForPageLoad(driver);
	}


	/**
	 * @author eshravan
	 * @throws Exception
	 * Method to terminate member end to end
	 */

	public void terminateMember() throws Exception
	{
		fnSwitchToFrame(contentIframePHS, driver);
		terminationFormButton.click();
		fnWaitForPageLoad(driver);
		fnSelectByValue("CA", termStateSelection_DDN);
		termBenefitAdminName_Input.sendKeys("testbene");
		termSubscriberPhoneAreaCOde_Input.sendKeys("234");
		termSubscriberPhonePrefix_Input.sendKeys("848");
		termSubscriberPhoneThird_Input.sendKeys("8383");
		termSubscriberEmailAddrss_Input.sendKeys("shravani_embadi@optum.com");
		termSubscriberGrpNo_Input.sendKeys("894848");
		termSubscriberGrpName_Input.sendKeys("testgroupname");
		termSubscriberSSNfirst_Input.sendKeys("345");
		termSubscriberSNScnd_Input.sendKeys("46");
		termSubscriberSSNThird_Input.sendKeys("9868");
		termSubscriberLastName_Input.sendKeys("Test");
		termSubscriberFstName_Input.sendKeys("test");
		termSubscriberDate_Input.sendKeys("06/01/2017");
		fnSelectByValue("1",termNoOfDep_DDN);
		Thread.sleep(3000);
		termDepToBeTerm_Input.sendKeys("test");
		System.out.println();
		termSndRequest_Btn.click();
		fnWaitForPageLoad(driver);

	}


	/**
	 * @author eshravan
	 * @throws InterruptedException
	 */

	public void requestChange() throws InterruptedException{
		fnSwitchToFrame(contentIframePHS, driver);
		rqstChangeFormButton.click();
		fnWaitForPageLoad(driver);
		fnSelectByValue("CA",rqstChangeStateSelction_DDN);
		rqstChangeBeneftAdminName_Input.sendKeys("testbene");
		rqstChangePhnAreaCode_Input.sendKeys("234");
		rqstChangePhnPrefixCode_Input.sendKeys("222");
		rqstChangePhnPhoneNumber_Input.sendKeys("9282");
		rqstChangeEmailAddrss_Input.sendKeys("shravani_embadi@optum.com");
		rqstChangeSubscriberGrpNo_Input.sendKeys("9383983");
		rqstChangeSubscriberGrpName_Input.sendKeys("testgroup");
		rqstChangeSubscriberSSNFrst_Input.sendKeys("898");
		rqstChangeSubscriberSSNScnd_Input.sendKeys("87");
		rqstChangeSubscriberSSNThird_Input.sendKeys("8984");
		rqstChangeSubscriberLastName_Input.sendKeys("test");
		rqstChangeSubscriberFstName_Input.sendKeys("test");
		fnSelectByValue("Address Change",rqstChange_DDN );
		Thread.sleep(2000);
		describeChangesReq_Input.sendKeys("test");
		rqstChngsubscriberStreetAddrss_Input.sendKeys("test");
		rqstChangesSubscriberCity_Input.sendKeys("test");
		fnSelectByValue("MD", rqstChngeState_DDN);
		rqstChngeZip_Input.sendKeys("20701");
		rqstChangeSendRequest_Btn.click();
		Thread.sleep(2000);
		fnWaitForPageLoad(driver);

	}







}
