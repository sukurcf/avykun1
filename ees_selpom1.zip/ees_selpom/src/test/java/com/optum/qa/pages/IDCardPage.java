package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.optum.qa.eesFunctionalApp.EesAppBase;


/**
 * 
 * @author eshravan
 *This represents the ID card Page of the EES application which will comes after clicking on Medical ID card link
 * */
public class IDCardPage extends EesAppBase {

	private WebDriver driver;
	
	@FindBy(id="requestIdCardBtn")
	private WebElement RequestIDCardButton;

	@FindBy(xpath="(.//*[@class='checkbox']/input)[2]")
	private WebElement Dep1RadioButn;
	
	@FindBy(xpath=".//*[@id='message-box']//p[contains(text(),'ID Card Successfully requested for:')]")
	private WebElement IDCardSuccssflMsg;
	
	public IDCardPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(this.driver, this);

	}


/**
 * 
 * @throws Exception
 * Method to Click on RequestIDCard button on IDCardPage
 */
public void clickOnRequestIDCard()throws Exception{
	Thread.sleep(10000);
	RequestIDCardButton.click();
	fnWaitForPageLoad(driver);
	
}

/**
 * 
 * @throws Exception
 * Method to Click on Radio button for selecting Dependent on IDCardPage
 */
public void click_Dep1_RadioButn()throws Exception{
	
	Dep1RadioButn.click();
	fnWaitForPageLoad(driver);
}

/**
 * 
 * @throws Exception
 * Method to validate IDCard successful message on IDCardPage
 */

public void Verify_IDCard_SucsfulMsg()throws Exception{
	
	fnWaitForElement(driver,IDCardSuccssflMsg,5);
	fnWaitForPageLoad(driver);
}
	
	
}