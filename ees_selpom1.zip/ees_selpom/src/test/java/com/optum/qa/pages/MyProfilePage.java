package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.qa.eesFunctionalApp.EesAppBase;

import junit.framework.Assert;

public class MyProfilePage extends EesAppBase{

	public Logger log = LoggerFactory.getLogger(this.getClass());
	
	//my profile
	@FindBy(xpath="//*[@id='firstName']")
	private WebElement firstName;

	@FindBy(xpath="//*[@id='middleInitial']")
	private WebElement MiddleIntial;


	@FindBy(xpath="//*[@id='lastName']")
	private WebElement lastName;
	
	@FindBy(xpath=".//*[@id='phoneAreaCode']")
	private WebElement phonefield1;
	
	@FindBy(xpath=".//*[@id='phoneExchange']")
	private WebElement phonefield2;
	
	@FindBy(xpath=".//*[@id='phoneNumber']")
	private WebElement phonefield3;
	
	@FindBy(xpath=".//*[@id='phoneExtension']")
	private WebElement phonefield4;


	@FindBy(xpath="//*[@id='emailAddress']")
	private WebElement email;
	
	@FindBy(xpath="//*[@class='recaptcha-checkbox-checkmark']")
	private WebElement robot_checkbox;
    
	@FindBy(xpath="//*[@id='myProfile-saveButton']")
	private WebElement saveButton;
	
	//Security Questions
	
	@FindBy(xpath=".//*[@id='tab-link-securityQuestions']")
	private WebElement SecurityQuestionlnk;
	
	@FindBy(xpath=".//*[@id='securityAnswer-5']")
	private WebElement securityanswer1;
	
	@FindBy(xpath=".//*[@id='securityConfirmAnswer-5']")
	private WebElement securityanswerconfirm1;
	
	@FindBy(xpath=".//*[@id='securityAnswer-6']")
	private WebElement securityanswer2;
	
	@FindBy(xpath=".//*[@id='securityConfirmAnswer-6']")
	private WebElement securityanswerconfirm2;
	
	@FindBy(xpath=".//*[@id='securityAnswer-7']")
	private WebElement securityanswer3;
	
	@FindBy(xpath=".//*[@id='securityConfirmAnswer-7']")
	private WebElement securityanswerconfirm3;
	
	@FindBy(xpath=".//*[@id='securityAnswer-8']")
	private WebElement securityanswer4;
	
	@FindBy(xpath=".//*[@id='securityConfirmAnswer-8']")
	private WebElement securityanswerconfirm4;
	
	@FindBy(xpath=".//*[@id='recaptcha-anchor']/div[5]")
	private WebElement robot_checkbox_security;
	
	@FindBy(xpath=".//*[@id='myProfile-link']")
	private WebElement MyProfileLnk;
	
	//change password tab
	
	@FindBy(xpath=".//*[@id='tab-link-changePassword']")
	private WebElement ChangePasswordLnk;
	
	@FindBy(xpath=".//*[@id='passwordForm.password']")
	private WebElement CurrentPassword;
	
	@FindBy(xpath=".//*[@id='passwordForm.newPassword']")
	private WebElement NewPassword;
	
	@FindBy(xpath=".//*[@id='passwordForm.confirmPassword']")
	private WebElement VerifyNewPassword;
	
	@FindBy(xpath="//p[contains(text(),'Your profile has been successfully updated')]")
	private WebElement PasswordSuccessMsg;
	
	@FindBy(xpath=".//*[@id='tab-link-defaultGroup']")
	private WebElement DefaultGroupTab;

	@FindBy(xpath=".//*[@id='defaultGroupForm']/p")
	private WebElement DefaultGroupPageSiteCopy;

	@FindBy(xpath=".//*[@id='groupSearch-results']")
	private WebElement ListBox;

	@FindBy(xpath=".//*[@id='defaultGroupForm']/div[3]")
	private WebElement DefaultGroupLabel;


	//@FindBy(xpath=".//*[@id='defaultGroupForm']/div[3]/label")
	//private WebElement GroupTextBox;

	@FindBy(xpath=".//*[@id='myProfile-saveButton']")
	private WebElement SaveButton;

	@FindBy(xpath=".//*[@id='myProfile-cancelLink']")
	private WebElement DefaultGroupCancel;

	@FindBy(xpath="//p[contains(text(),'Your profile has been successfully updated.')]")
	private WebElement DefaultGroupDropdownSuccessfulMessage;

	private WebDriver driver;

	public MyProfilePage(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	public void MyProfileDetails() throws Exception {
		 firstName.clear();
		 firstName.sendKeys("Divyani");
		 lastName.clear();
		 lastName.sendKeys("Pandey");
		 phonefield1.clear();
		 phonefield1.sendKeys("456");
		 phonefield2.clear();
		 phonefield2.sendKeys("234");
		 phonefield3.clear();
		 phonefield3.sendKeys("1234");
		 phonefield4.clear();
		 phonefield4.sendKeys("12345");
		 email.clear();
		 email.sendKeys("divyani_pandey@optum.com");
		 driver.switchTo().frame(0);
		 robot_checkbox.click();
		 Thread.sleep(5000);
		 fnWaitForPageLoad(driver);
	 }
	
	public void Validate_MyProfile_Page() throws Exception {
		
		fnIsDisplayed(ChangePasswordLnk);
		fnIsDisplayed(SecurityQuestionlnk);
        fnIsDisplayed(MyProfileLnk);		
		fnIsDisplayed(SaveButton);
		
		
	}
	public void UpdateSecurityQuestions() throws Exception {
		 
		 SecurityQuestionlnk.click();
		 securityanswer1.clear();
		 securityanswer1.sendKeys("friend");
		 securityanswerconfirm1.clear();
		 securityanswerconfirm1.sendKeys("friend");
		 securityanswer2.clear();
		 securityanswer2.sendKeys("grade");
		 securityanswerconfirm2.clear();
		 securityanswerconfirm2.sendKeys("grade");
		 securityanswer3.clear();
		 securityanswer3.sendKeys("job");
		 securityanswerconfirm3.clear();
		 securityanswerconfirm3.sendKeys("job");
		 securityanswer4.clear();
		 securityanswer4.sendKeys("car");
		 securityanswerconfirm4.clear();
		 securityanswerconfirm4.sendKeys("car");
		 driver.switchTo().frame(0);
		 Thread.sleep(5000);
		 robot_checkbox_security.click();
		 fnWaitForPageLoad(driver);
	  
	}
	 
	 public void ChangePassword() throws Exception {
		 
		 ChangePasswordLnk.click();
		 Thread.sleep(2000);
		 CurrentPassword.sendKeys("Password!1");
		 NewPassword.sendKeys("Password!11");
		 VerifyNewPassword.sendKeys("Password!11");
		 fnWaitForPageLoad(driver);
		 saveButton.click();
		 Thread.sleep(5000);
		 fnWaitForPageLoad(driver);
		 fnIsDisplayed(PasswordSuccessMsg);
		 
	 }
	 public void validateText_DefaultGroupTab() throws Exception{

			Assert.assertTrue(DefaultGroupTab.isEnabled());
			Assert.assertEquals("FAILED - Default Group Name is not matching", "Default Group", DefaultGroupTab.getText());
		}
		public void validateTab_DefaultGroup(){

			DefaultGroupTab.click();
			fnWaitForPageLoad(driver);
			Assert.assertEquals("FAILED - Default Group SiteCopy is not matching", "Set this group as my default group.", DefaultGroupPageSiteCopy.getText());
			Assert.assertEquals("FAILED - Default Group name Label is not matching", "Default Group", DefaultGroupLabel.getText());
			Assert.assertEquals("FAILED - Save button label is not matching", "Save", SaveButton.getText());
			Assert.assertEquals("FAILED - Default Group Page Cancel button Name is not matching", "Cancel", DefaultGroupCancel.getText());
		}

		public void validate_EnableListBox() throws Exception{

			Assert.assertTrue(ListBox.isEnabled());
			fnSelectByPartialVisibleText("- Select Group -", ListBox);
			Assert.assertEquals("FAILED", "- Select Group -", fnGetFirstSelectedOption(driver, ListBox));

		
		}		

		public void validateDropdown_SelectedText(){

			fnSelectByPartialVisibleText("PT_PRIME_BRMS_0250 06U9529", ListBox);
			saveButton.click();
			fnWaitForElement(driver,DefaultGroupDropdownSuccessfulMessage, 20);
			fnVerifyElementText(DefaultGroupDropdownSuccessfulMessage, "Your profile has been successfully updated.");

		}

		public void validate_DisableListBox() throws Exception{

			Assert.assertFalse(ListBox.isEnabled());
			fnSelectByPartialVisibleText("TRINITY INDUSTRIES, INC. 0039810", ListBox);
		
		}
}
