package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.optum.qa.eesFunctionalApp.EesAppBase;

public class ManageAccessPage extends EesAppBase {

	private WebDriver driver;
	
	//clients

	@FindBy(xpath = ".//input[@name='clientName']")
	private WebElement ClientNameInput;
	
	
	@FindBy(xpath = ".//input[@name='policy']")
	private WebElement policyOrDivInput;
	
	
	@FindBy(xpath = ".//input[(@value='Search By Policy')and(@type='submit')]")
	private WebElement SearchByPolicyBtn;
	
	//superuser Group
	@FindBy(xpath = ".//a[@rel='superuserGroups']")
	private WebElement SuperUsrGroupsTab;
	
	//add 
	@FindBy(xpath = "//*[contains(text(),'Add A New Client')]")
	private WebElement add_a_new_client ;
	
	///client info
	
	@FindBy(xpath = ".//*[(@name='clientType') and(@value='1')]")
	private WebElement type_employer_radiobtn ;
	
	@FindBy(xpath = ".//input[@name='clientName']")
	private WebElement clientNameInput ;
	
	@FindBy(xpath = ".//input[@name='address1']")
	private WebElement streetaddrs1Input ;
	
	@FindBy(xpath = ".//input[@name='city']")
	private WebElement cityInput ;
	
	@FindBy(xpath = ".//*[@name='state']")
	private WebElement statedrpdwn ;
	
	@FindBy(xpath = ".//*[@name='zip']")
	private WebElement zip1Input ;
	
	
	@FindBy(xpath = ".//*[@name='zip4']")
	private WebElement zip2Input ;
	
	@FindBy(xpath=".//*[@id='formTable']/tbody/tr[5]/td/table/tbody/tr[10]/td[2]/table/tbody/tr[1]/td[2]/input")
	private WebElement uhgsmallbusiness_chkbx;
	
	@FindBy(xpath = ".//*[(@name='reportingType')and(@value='0')]")
	private WebElement reporting_no_radio ;
	//buttons
	
	
	@FindBy(xpath = ".//*[(@value='Submit & Assign Permissions')]")
	private WebElement submitAssignBtn ;
	
	@FindBy(xpath = ".//*[@value='Submit']")
	private WebElement submitBtn ;
	
	@FindBy(xpath = ".//*[@value='Submit & Add More']")
	private WebElement submitAddmoreBtn;
	
	@FindBy(xpath = ".//*[@id='tab-link-superuserGroups']")
	private WebElement superuserGroupsTab ;
	
	
	@FindBy(xpath = ".//*[@id='tab-link-internalGroups']")
	private WebElement InternalGroupsTab ;
	
	//plans client
	@FindBy(xpath = ".//*[@name='platform[0]']")
	private WebElement platformDrpdwn1 ;
	
	@FindBy(xpath = ".//*[@name='policy[0]']")
	private WebElement policyInput1;
	
	@FindBy(xpath = ".//*[@name='custNumber[0]']")
	private WebElement custmerNmbr1 ;
	
	
	//add new group
	@FindBy(xpath = ".//*[contains(text(),'Add New Group')]")
	private WebElement addNewGrpLnk;
	
	//create superuser group
	
	
	
	@FindBy(xpath = ".//*[@name='superGroupType']")
	private WebElement superuserTypeDrpdwn;
	
	@FindBy(xpath = ".//*[@name='contentProfile']")
	private WebElement contentprofileDrpdwn;
	
	@FindBy(xpath = ".//input[@name='phoneAreaCode']")
	private WebElement phone1;
	
	@FindBy(xpath = ".//input[@name='phoneExchange']")
	private WebElement phone2;
	
	@FindBy(xpath = ".//input[@name='phoneNo']")
	private WebElement phone3;
	
	@FindBy(xpath = ".//input[@name='phoneExt']")
	private WebElement phone4;
	
	
	@FindBy(xpath = ".//input[@name='email']")
	private WebElement email;
	
	@FindBy(xpath = ".//input[@name='lastName']")
	private WebElement lastName;
	
	@FindBy(xpath = ".//input[@name='firstName']")
	private WebElement frstName;
	
	@FindBy(xpath = ".//input[@name='groupName']")
	private WebElement groupName;
	
	@FindBy(xpath = "..//*[@name='role']")
	private WebElement groupRole;
	
	@FindBy(xpath = ".//*[@name='viewClient']")
	private WebElement viewchkbx;
	
	@FindBy(xpath = ".//*[@name='resetPasswordUser']")
	private WebElement resetPswdchkbx;
	
	
	@FindBy(xpath = ".//*[@name='viewUser']")
	private WebElement viewuserchkbx;
	
	
	@FindBy(xpath = ".//*[@name='platform']")
	private WebElement HostsystemDrpdwn;
	
	@FindBy(xpath = ".//*[@name='sharedArrangement']")
	private WebElement sharedAgmntDrpdwn;
	
	@FindBy(xpath = ".//*[@name='obligorId']")
	private WebElement obligatorID_drpdwn;
	
	@FindBy(xpath = ".//*[@name='leadPartner']")
	private WebElement leadpartnerDrpdwn;
	
	@FindBy(xpath = ".//*[@name='division']")
	private WebElement BusinessSegmentDrpdwn;
	
	@FindBy(xpath = ".//*[@name='addrule']")
	private WebElement addruleBtn;
	
	//do more link
	@FindBy(xpath = "//*[contains(text(),'Do More')]")
	private WebElement DoMoreLnk;
	
	//adduser
	@FindBy(xpath = "//*[contains(text(),'Add User')]")
	private WebElement AddUserLnk;
	
	@FindBy(xpath = "//*[contains(text(),'Add A New Superuser User')]")
	private WebElement addNewSuperUseruser;
	
	@FindBy(xpath = "//*[contains(text(),'Add A New Internal User')]")
	private WebElement addNewInternaluser;
	
	@FindBy(xpath = "//*[contains(text(),'AAdd A New Client')]")
	private WebElement AddaNewClientLnk;
	
	//update user profile
	@FindBy(xpath = "//*[contains(text(),'Update User Profile')]")
	private WebElement updateUserProfile_Lnk;
	
	
	public ManageAccessPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	public void clientSearchByPolicy(String policy) throws Exception
	{
		fnWaitAndSwitchToFrame("manageAccessIframe", driver);
		policyOrDivInput.clear();
		policyOrDivInput.sendKeys(policy);
		Thread.sleep(6000);
		SearchByPolicyBtn.click();
		Thread.sleep(6000);
		fnWaitForPageLoad(driver);
		
		
	}
	public void click_superUserGroups() throws Exception
	{
		SuperUsrGroupsTab.click();
		app_SpinnerInvisible(driver);
		
		
	}
	public void click_add_a_new_client() throws Exception
	{
		add_a_new_client.click();
		app_SpinnerInvisible(driver);
		
		
	}
	
	public void create_client_profile(String policy) throws Exception
	{
		type_employer_radiobtn.click();
		clientNameInput.clear();
		clientNameInput.sendKeys(generateAddressFields());
		streetaddrs1Input.clear();
		streetaddrs1Input.sendKeys(generateAddressFields());
		cityInput.sendKeys(generateAddressFields());
		fnSelectByText("AB", statedrpdwn);
		zip1Input.sendKeys("56789");
		zip2Input.sendKeys("6666");
		uhgsmallbusiness_chkbx.click();
		reporting_no_radio.click();
		click_submitAssignBtn();
		fnSelectByText("COSMOS",platformDrpdwn1);
		policyInput1.clear();
		policyInput1.sendKeys(policy);
		custmerNmbr1.clear();
		custmerNmbr1.sendKeys("456789");
		submitBtn.click();
		fnWaitForElement(driver, DoMoreLnk, shortTimeout);
		fnWaitForElement(driver, updateUserProfile_Lnk, shortTimeout);
		Thread.sleep(6000);

		
		
	}

	public void click_submitAssignBtn()
	{
		submitAssignBtn.click();
		fnWaitForPageLoad(driver);
	}
	public void click_submit()
	{
		submitBtn.click();
		fnWaitForPageLoad(driver);
	}
	public void click_superuserGroup() throws Exception
	{
		superuserGroupsTab.click();
		app_SpinnerInvisible(driver);
	}
	public void create_superuserGroup() throws Exception
	{
		superuserGroupsTab.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(1000);
		fnWaitAndSwitchToFrame("manageAccessIframe", driver);
		addNewGrpLnk.click();
		fnWaitForPageLoad(driver);
		groupName.sendKeys(generatetext());
		frstName.clear();
		frstName.sendKeys(generatetext());
		lastName.clear();
		lastName.sendKeys(generatetext());
		phone1.clear();
		phone1.sendKeys("234");
		phone2.clear();
		phone2.sendKeys("345");
		phone3.clear();
		phone3.sendKeys("6789");
		phone4.clear();
		phone4.sendKeys("98765");
		email.clear();
		email.sendKeys("suresh_itha@optum.com");
		Thread.sleep(2000);
		fnSelectByText("UHG/Profile AB Broker - Joint Venture (UHG)", contentprofileDrpdwn);
		Thread.sleep(2000);
		fnSelectByText("Manage Access", superuserTypeDrpdwn);
		Thread.sleep(2000);
		//check box
		viewchkbx.click();
		resetPswdchkbx.click();
		viewuserchkbx.click();
		//data segmentation rules
		fnSelectByText("(ALL)", HostsystemDrpdwn);
		fnSelectByText("00", sharedAgmntDrpdwn);
		fnSelectByText("(ALL)", obligatorID_drpdwn);
		fnSelectByText("UHG", leadpartnerDrpdwn);
		fnSelectByText("Small Business", BusinessSegmentDrpdwn);
		addruleBtn.click();
		Thread.sleep(1000);
		submitBtn.click();
		fnWaitForPageLoad(driver);
		
	}
	
	public void create_internaluserGroup() throws Exception
	{
           InternalGroupsTab.click();
		app_SpinnerInvisible(driver);
		Thread.sleep(1000);
		fnWaitAndSwitchToFrame("manageAccessIframe", driver);
		addNewGrpLnk.click();
		fnWaitForPageLoad(driver);
		groupName.sendKeys(generatetext());
		fnSelectByText("OBS Registrar", groupRole);
		frstName.clear();
		frstName.sendKeys(generatetext());
		lastName.clear();
		lastName.sendKeys(generatetext());
		phone1.clear();
		phone1.sendKeys("234");
		phone2.clear();
		phone2.sendKeys("345");
		phone3.clear();
		phone3.sendKeys("6789");
		phone4.clear();
		phone4.sendKeys("98765");
		email.clear();
		email.sendKeys("suresh_itha@optum.com");
		Thread.sleep(2000);
	
		//check box
		viewchkbx.click();
		resetPswdchkbx.click();
		viewuserchkbx.click();
		/*//data segmentation rules
		fnSelectByText("(ALL)", HostsystemDrpdwn);
		fnSelectByText("00", sharedAgmntDrpdwn);
		fnSelectByText("(ALL)", obligatorID_drpdwn);
		fnSelectByText("UHG", leadpartnerDrpdwn);
		fnSelectByText("Small Business", BusinessSegmentDrpdwn);
		addruleBtn.click();*/
		Thread.sleep(1000);
		submitBtn.click();
		fnWaitForPageLoad(driver);
		
	}
	public void click_DoMoreLnk() throws Exception
	{
		DoMoreLnk.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(3000);
	}
	public void click_adduserLnk() throws Exception
	{
		AddUserLnk.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(2000);
	}
	public void click_addNewSuperUseruserLnk() throws Exception
	{
		addNewSuperUseruser.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(3000);
	}
	public void click_addNewClientLnk() throws Exception
	{
		add_a_new_client.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(3000);
	}
	public void click_addNewInternalLnk() throws Exception
	{
		addNewInternaluser.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(3000);
	}
	public void create_superuser_user_profile() throws Exception
	{ fnWaitAndSwitchToFrame("manageAccessIframe", driver);
	
		frstName.sendKeys("suresh");
		lastName.sendKeys("itha");
		phone1.sendKeys("234");
		phone2.sendKeys("345");
		phone3.sendKeys("3456");
		phone4.sendKeys("11111");
		email.sendKeys("suresh_itha@optum.com");
		submitBtn.click();
		fnWaitForPageLoad(driver);
		fnWaitForElement(driver, updateUserProfile_Lnk, shortTimeout);
		Thread.sleep(6000);
		
	}
	public void create_internal_user_profile() throws Exception
	{ fnWaitAndSwitchToFrame("manageAccessIframe", driver);
	
		frstName.sendKeys("suresh");
		lastName.sendKeys("itha");
		phone1.sendKeys("234");
		phone2.sendKeys("345");
		phone3.sendKeys("3456");
		phone4.sendKeys("11111");
		email.sendKeys("suresh_itha@optum.com");
		submitBtn.click();
		fnWaitForPageLoad(driver);
		fnWaitForElement(driver, updateUserProfile_Lnk, shortTimeout);
		Thread.sleep(6000);
		
	}
	public void click_superuserGrpTab()
	{
		superuserGroupsTab.click();
	}
	
	
}
