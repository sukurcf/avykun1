package com.optum.qa.eesFunctionalApp;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optum.qa.pages.AddEmpDemographicsPage;
import com.optum.qa.pages.AssignPlansPage;
import com.optum.qa.pages.HomePage;
import com.optum.qa.pages.LoginPage;
import com.optum.qa.pages.ManageEmployeesPage;
import com.optum.qa.pages.ReviewAndSubmitPage;

public class EesWorkFlows extends EesAppBase {

	private WebDriver driver;
	public Logger log = LoggerFactory.getLogger(this.getClass());


	public void Enroll_Employee_prime_withoutDpdnt(String grpname) throws Exception
	{	
		RemoteWebDriver driver = getWebDriver();
		HomePage homepage=new HomePage(driver);
		homepage.searchForPolicy(grpname);

		homepage.click_addNewEmp();

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_prime();
		addempdemographicPage.click_nextButton();
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_prime();
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
		//TODO: need to add remaining two pages details
	}
	public void Enroll_Employee_cosmos_withoutDpdnt(String policyNumbr) throws Exception
	{	
		RemoteWebDriver driver = getWebDriver();
		HomePage homepage=new HomePage(driver);
		homepage.searchForPolicy(policyNumbr);

		homepage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_cosmos();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_cosmos();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();

	}

	public void Enroll_Employee_CDB_withoutDpdnt(String policyNumbr) throws Exception
	{	
		RemoteWebDriver driver = getWebDriver();
		HomePage homepage=new HomePage(driver);
		homepage.searchForPolicy(policyNumbr);

		homepage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB();
		log.info("entered demographic details");
		addempdemographicPage.click_nextButton();
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
	}

	public void Enroll_Employee_CDB_with_Dependent(String policyNumbr) throws Exception
	{	
		RemoteWebDriver driver = getWebDriver();
		HomePage homepage=new HomePage(driver);
		homepage.searchForPolicy(policyNumbr);

		homepage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demo graphaphics page");
		AddEmpDemographicsPage addempdemographicPage=new AddEmpDemographicsPage(driver);
		addempdemographicPage.demographics_details_CDB_with_Dependent();
		addempdemographicPage.click_nextButton();


		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_dependent();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
	}

	public void Enroll_Employee_CDB_MEDICA_withoutDpdnt(String policyNumbr, String SSN) throws Exception
	{
		RemoteWebDriver driver = getWebDriver();
		HomePage homePage=new HomePage(driver);
		homePage.searchForPolicy(policyNumbr);

		homePage.click_addNewEmp();
		Thread.sleep(8000);

		fnWaitForPageLoad(driver);
		//app_SpinnerInvisible(driver);
		log.info("moving to demographics page");
		AddEmpDemographicsPage addempdemographicsPage=new AddEmpDemographicsPage(driver);
		addempdemographicsPage.demographics_details_CDB_MEDICA(SSN);
		log.info("completed demographics details");
		AssignPlansPage assignplans=new AssignPlansPage(driver);
		assignplans.plans_CDB_MEDICA();
		log.info("completed Assign plans details");
		ReviewAndSubmitPage reviewpage=new ReviewAndSubmitPage(driver);
		reviewpage.click_submit();
		log.info("Submit button is clicked");
		ManageEmployeesPage manageEmpPage=new ManageEmployeesPage(driver);
		manageEmpPage.Validate_enrollment_complete();
	}

    public void navigate_inquirePage(String user,String policy, String EmpidorLastName ) throws Exception
    {
    	log.info(" *** Execution Started");
		RemoteWebDriver driver = getWebDriver();

		log.info("Step1: Login to EES Site");

		LoginPage loginPage = new LoginPage(driver);
		HomePage homePage = loginPage.doLogin(user);
		
		log.info("Step2: Search for Policy on the Home Page");
		homePage.searchForPolicy(policy);

		log.info("Step3: Search for Employee using the altid");
		homePage.searchForEmployee(EmpidorLastName);

		log.info("Step4: Click on EmpInquire LInk on the homePage");
		homePage.Click_InquireEmployee_link();
		
		homePage.Validate_Inquire_EmmployeeSection();
		log.info("validate employee inquire section");
	}

}
