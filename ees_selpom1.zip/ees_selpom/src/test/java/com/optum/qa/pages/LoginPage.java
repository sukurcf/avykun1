package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.qa.eesFunctionalApp.EesAppBase;

/**
 * 
 * @author jsahoo10
 * This page represents the LoginPage in the EES application
 *
 */
public class LoginPage extends EesAppBase{

	public Logger log = LoggerFactory.getLogger(this.getClass());

	@FindBy(name="passwordForm.userId")
	private WebElement userName;

	@FindBy(name="passwordForm.password")
	private WebElement password;


	@FindBy(id="login")
	private WebElement loginButton;


	@FindBy(id="oo_never_show")
	private WebElement neverAskAgain;


	private WebDriver driver;

	public LoginPage(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	/**
	 * 
	 * @param loginuser
	 * @return
	 * @throws InterruptedException
	 * It will do the login and return Home Page
	 */
	public HomePage doLogin(String loginuser) throws InterruptedException{
		driver.get(eESAppUrl);
		String un =eesProperties.getProperty(loginuser + ".username." + profile);
		String pwd =eesProperties.getProperty(loginuser + ".password." + profile);
		userName.sendKeys(un);
		password.sendKeys(pwd);
		loginButton.click();
		app_SpinnerInvisible(driver);
		handleAdvertisementPopup();
		fnWaitForPageLoad(driver);

		return new HomePage(driver);

	}
	/**
	 * Method to handle unwanted Advertisement popup coming after login
	 */
	private void handleAdvertisementPopup(){
		try{
			neverAskAgain.click();
		}
		catch(Exception e){
			log.info("No Advertisement present");
		}
	}

}
