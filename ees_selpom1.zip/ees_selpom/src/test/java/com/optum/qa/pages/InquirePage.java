package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.optum.qa.eesFunctionalApp.EesAppBase;

public class InquirePage extends EesAppBase {

	private WebDriver driver;


	@FindBy(linkText="Print Record")
	private WebElement PrintRecord_button;

	@FindBy(id="editInquireEmpDemo")
	private WebElement EditEmpDemo_button;

	@FindBy(id="editInquireEmpPlans")
	private WebElement EditEmpPlan_button;

	@FindBy(linkText="Plan Details")
	private WebElement PlanDetails_link;

	@FindBy(id="terminateInquireEmp")
	private WebElement TerminateEMp_button;

	@FindBy(linkText="Expand All")
	private WebElement ExpandAll_link;

	@FindBy(linkText="Medical ID Cards")
	private WebElement MedicalIDCrd_link;

	@FindBy(linkText="Claims")
	private WebElement Claims_link;

	public InquirePage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(this.driver, this);

	}
	/**
	 * 
	 * @throws Exception
	 * Method to Click on IDCardLink on HomePage
	 */

	public void click_IDCard_Link()throws Exception{
		MedicalIDCrd_link.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(10000);
	}
		
	
	}


