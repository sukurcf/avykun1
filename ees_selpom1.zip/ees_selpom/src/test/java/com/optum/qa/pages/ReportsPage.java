package com.optum.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.optum.qa.eesFunctionalApp.EesAppBase;

public class ReportsPage extends EesAppBase {
	
	
	private WebDriver driver;

   //Banking
	@FindBy(xpath=".//*[contains(text(),'Daily Banking Reports')]")
	private WebElement DailyBankingReports_txt ;
	
	@FindBy(xpath=".//*[contains(text(),'Monthly Banking Reports')]")
	private WebElement MonthlyBankingReports_txt ;
	
	@FindBy(xpath=".//*[contains(text(),'Historical Banking Reports')]")
	private WebElement HistoricalBankingReports_txt ;
	
	@FindBy(id="historicalReportType")
	private WebElement reports_drpdwn;
	
	@FindBy(xpath="//*[@id='historicalReportDateRange']")
	private WebElement Datedrpdwn;
	
	@FindBy(xpath="//*[@id='historicalReportFormat']")
	private WebElement Formatdrpdwn;
	
	@FindBy(xpath=".//*[@id='historicalShowReports']")
	private WebElement ShowReports_btn;
	
	@FindBy(xpath="//*[@id='daily-table']/tbody/tr[2]/td[1]/a")
	private WebElement chrgedClaimActivity_link;
	
	
	//under cost and utilization link
	@FindBy(xpath="//*[contains(text(),'Visit the UHC Cost & Utilization Site')]")
	private WebElement Visit_UHC_costAndUtilizationSite_lnk;
	
	
	@FindBy(xpath="//*[contains(text(),'Reports Home')]")
	private WebElement eCR_ReportsHome;
	
	@FindBy(xpath="//*[contains(text(),'Logout')]")
	private WebElement eCR_LogoutLnk;
	
	
	
	
	
	
	
	public ReportsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	

	
	public void verify_reportsPage()
	{
		fnIsElementPresent(DailyBankingReports_txt);
		fnIsElementPresent(MonthlyBankingReports_txt);
		fnIsElementPresent(HistoricalBankingReports_txt);
		
		
	}
	
	public void select_historicalBankingReport(String reportName,String Date) throws Exception
	{
		fnSelectByText(reportName, reports_drpdwn);
		Thread.sleep(2000);
		fnSelectByText(Date, Datedrpdwn);
		Thread.sleep(4000);
		//fnClickElementByJS(driver, ShowReports_btn);
		ShowReports_btn.click();
		Thread.sleep(10000);
		
	}
	
	public void click_chrgedclaimActivity_lnk() throws Exception
	{
		chrgedClaimActivity_link.click();
		Thread.sleep(6000);
		
	}
	public void click_Visit_UHC_costAndUtilizationSite_lnk() throws Exception
	{
		Visit_UHC_costAndUtilizationSite_lnk.click();
		fnWaitForPageLoad(driver);
		Thread.sleep(8000);
	}
	
	public void validate_eCR_functionality() throws Exception
	{
		Thread.sleep(3000);
		Assert.assertTrue(eCR_ReportsHome.isDisplayed());
		Assert.assertTrue(eCR_LogoutLnk.isDisplayed());
		eCR_LogoutLnk.click();
		driver.close();
	}
	

}
